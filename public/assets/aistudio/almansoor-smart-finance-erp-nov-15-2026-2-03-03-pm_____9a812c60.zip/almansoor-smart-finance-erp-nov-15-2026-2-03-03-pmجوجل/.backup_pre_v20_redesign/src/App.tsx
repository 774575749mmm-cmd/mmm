/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * ALMANSOOR SMART FINANCE ERP - Main Application Entrypoint
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  loadDatabase,
  loadDatabaseFromIDB,
  saveDatabase,
  resetToDemoDatabase,
  generateNextDocNumber,
  ERPDatabase,
} from './services/storageService';
import {
  createSalesInvoiceJournalEntry,
  createPurchaseInvoiceJournalEntry,
  createVoucherJournalEntry,
  createExpenseJournalEntry,
  createStocktakingJournalEntry,
  createReversalJournalEntry,
} from './services/accountingEngine';
import {
  executeInventoryTransfer,
  reverseInventoryTransfer,
  applyStocktakingAdjustments,
  updateWarehouseStock,
} from './services/inventoryEngine';
import {
  Invoice,
  Customer,
  Vendor,
  InventoryItem,
  PaymentVoucher,
  ExpenseRecord,
  Employee,
  PayrollRun,
  FixedAsset,
  Branch,
  Warehouse,
  UnitOfMeasure,
  Currency,
  User,
  TaskAlert,
  InventoryTransfer,
  TreasuryAccount,
  TreasuryTransfer,
  SystemSettings,
  JournalEntry,
  WarehouseDocument,
  PhysicalStocktaking,
  DispatchLogEntry,
  CustomLedgerBook,
  CustomLedgerEntry,
  TableColumnPref,
} from './types/erp';

// Layout & Common
import { Header } from './components/layout/Header';
import { Sidebar, ERPModuleId } from './components/layout/Sidebar';
import { HelpModal, HelpTopic } from './components/common/HelpModal';
import { PrintModal, PrintableDocumentData } from './components/common/PrintModal';
import { ToastBanner, ToastMessage } from './components/common/ToastBanner';
import { ConfirmModal } from './components/common/ConfirmModal';

// Modules
import { DashboardModule } from './components/modules/dashboard/DashboardModule';
import { DailyManagementReportModule } from './components/modules/dailyReport/DailyManagementReportModule';
import { UnifiedDocumentsModule } from './components/modules/documents/UnifiedDocumentsModule';
import { ScheduledDispatchModule } from './components/modules/dispatch/ScheduledDispatchModule';
import { CustomersModule } from './components/modules/customers/CustomersModule';
import { VendorsModule } from './components/modules/vendors/VendorsModule';
import { SalesModule } from './components/modules/sales/SalesModule';
import { PurchasesModule } from './components/modules/purchases/PurchasesModule';
import { InventoryModule } from './components/modules/inventory/InventoryModule';
import { AccountingModule } from './components/modules/accounting/AccountingModule';
import { TreasuryModule } from './components/modules/treasury/TreasuryModule';
import { ExpensesModule } from './components/modules/expenses/ExpensesModule';
import { HrPayrollModule } from './components/modules/hr/HrPayrollModule';
import { FixedAssetsModule } from './components/modules/assets/FixedAssetsModule';
import { ReportsHubModule } from './components/modules/reports/ReportsHubModule';
import { TasksAlertsModule } from './components/modules/tasks/TasksAlertsModule';
import { SettingsModule } from './components/modules/settings/SettingsModule';

export default function App() {
  const [db, setDb] = useState<ERPDatabase>(() => loadDatabase());
  const [activeModule, setActiveModule] = useState<ERPModuleId>('dashboard');
  const [focusedRecordId, setFocusedRecordId] = useState<string | undefined>(undefined);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Active Contextual State
  const [currentBranch, setCurrentBranch] = useState<Branch>(() => db.branches[0]);
  const [currentCurrency, setCurrentCurrency] = useState<Currency>(() => db.currencies[0]);
  const [currentUser, setCurrentUser] = useState<User>(() => db.users[0]);

  // Modals & Toasts
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [printableDoc, setPrintableDoc] = useState<PrintableDocumentData | null>(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);

  const notify = useCallback((type: 'success' | 'error' | 'info', message: string) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setToasts((prev) => [...prev.slice(-3), { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  }, []);

  // Hydrate from IndexedDB if a large dataset (>5MB) was persisted there
  useEffect(() => {
    let active = true;
    loadDatabaseFromIDB().then((idbData) => {
      if (active && idbData) {
        setDb(idbData);
        if (idbData.branches[0]) setCurrentBranch(idbData.branches[0]);
        if (idbData.currencies[0]) setCurrentCurrency(idbData.currencies[0]);
        if (idbData.users[0]) setCurrentUser(idbData.users[0]);
      }
    });
    return () => {
      active = false;
    };
  }, []);

  // Persist DB on changes
  useEffect(() => {
    saveDatabase(db);
  }, [db]);

  // Apply UI fontSize preference dynamically
  useEffect(() => {
    const size = db.settings.uiPreferences?.fontSize || 14;
    document.documentElement.style.fontSize = `${size}px`;
  }, [db.settings.uiPreferences?.fontSize]);

  const navigateToRecord = useCallback((moduleName: string, recordId?: string) => {
    const validModules: ERPModuleId[] = [
      'dashboard',
      'daily_report',
      'unified_docs',
      'scheduled_dispatch',
      'customers',
      'vendors',
      'sales',
      'purchases',
      'inventory',
      'accounting',
      'treasury',
      'expenses',
      'hr',
      'assets',
      'reports',
      'tasks',
      'settings',
    ];
    const target = validModules.includes(moduleName as ERPModuleId)
      ? (moduleName as ERPModuleId)
      : 'unified_docs';
    setFocusedRecordId(recordId);
    setActiveModule(target);
  }, []);

  const getCurrencyRate = (code: string): number => {
    return db.currencies.find((c) => c.code === code)?.exchangeRate || 1;
  };

  // Help topic lookup based on active module
  const helpTopics: Record<ERPModuleId, HelpTopic> = {
    dashboard: {
      title: 'لوحة القيادة والمؤشرات المالية والتشغيلية',
      purpose: 'منح الإدارة العليا نظرة فورية شاملة عن المبيعات، الأرباح، رصيد الخزينة، والمخزون.',
      responsibleRole: 'المالك، المدير العام، المدير المالي',
      operationalSteps: [
        'متابعة أداء المبيعات والأرباح المحققة مقارنة بالفترات السابقة.',
        'مراقبة توازن الميزانية العمومية والتحقق من عدم وجود أي فروقات محاسبية.',
        'الضغط على أي بطاقة مؤشر للوصول إلى تفاصيل السجلات المكونة لها.',
      ],
      accountingImpact: 'تعرض نتائج قيود اليومية وميزان المراجعة وقائمتي الدخل والمركز المالي لحظياً.',
      inventoryImpact: 'حساب القيمة الإجمالية للمخزون بمتوسط التكلفة المرجح لجميع المستودعات.',
      commonMistakes: ['الاعتماد على التقارير دون ترحيل الفواتير وسندات الصرف والقبض.'],
      bestPractices: 'التحقق الدوري من سلامة التوازن المحاسبي في بداية ونهاية كل أسبوع عمل.',
    },
    daily_report: {
      title: 'التقرير الإداري اليومي الشامل (22 مؤشراً)',
      purpose: 'تزويد الإدارة العليا والملاك بنظرة شاملة ونهائية عن المبيعات، المشتريات، السيولة، النقدية، والمخزون.',
      responsibleRole: 'المدير العام، المدير المالي، المراجع الداخلي',
      operationalSteps: [
        'اختيار تاريخ اليوم والفرع المراد مراجعة عملياته.',
        'استعراض الـ 22 مؤشراً مقسمة حسب المبيعات والمشتريات والسيولة والائتمان والضغط على أي مؤشر للانتقال لسجله.',
        'تصدير التقرير لـ PDF حقيقي أو Excel أو إرساله عبر الواتساب للإدارة.',
      ],
      accountingImpact: 'يعكس الأثر الفعلي لجميع قيود اليومية النقدية والآجلة المنفذة خلال اليوم.',
      inventoryImpact: 'يقيس تكلفة البضاعة المباعة COGS، حركات الوارد والمنصرف، وقيمة المخزون بنهاية اليوم.',
      commonMistakes: ['إغلاق اليوم دون التأكد من مطابقة الخزائن النقدية مع رصيد السندات.'],
      bestPractices: 'اعتماد التقرير وتوزيعه يومياً في موعد الإغلاق المحدد.',
    },
    unified_docs: {
      title: 'مركز المستندات الموحد',
      purpose: 'محرك بحث وتدقيق مركزي يغطي الفواتير والسندات والقيود والأذون والمناقلات والجرد والمصروفات.',
      responsibleRole: 'المراجع الداخلي، المحاسب العام، مدير النظام',
      operationalSteps: [
        'البحث برقم المستند أو اسم الطرف أو المبلغ أو نوع المستند.',
        'النقر على أي مستند لمعاينته أو التنقل بالسابق/التالي أو فتحه في وحدته الأصلية.',
        'تصدير النتائج إلى PDF أو Excel بضغطة زر واحدة.',
      ],
      accountingImpact: 'إمكانية فحص سلامة القيد المحاسبي المزدوج المتوازن لكل مستند في النظام.',
      inventoryImpact: 'تتبع السلسلة المخزنية الكاملة من التوريد إلى الصرف والمناقلة والجرد.',
      commonMistakes: ['عدم فحص القيود المحاسبية التلقائية للفواتير.'],
      bestPractices: 'استخدام المركز للمراجعة الدورية واكتشاف أي مستندات ملغية أو معلقة.',
    },
    scheduled_dispatch: {
      title: 'مركز الإرسال والتقارير المجدولة',
      purpose: 'إرسال كشوف الحسابات للعملاء والتقارير اليومية للإدارة وتتبع سجل التسليم.',
      responsibleRole: 'مسؤول التحصيل، مدير العمليات، مسؤول تقنية المعلومات',
      operationalSteps: [
        'ضبط ساعة الإرسال اليومية ورقم واتساب الإدارة وتخصيص القوالب.',
        'تجهيز وإرسال كشوف الحسابات للعملاء الذين عليهم مديونيات.',
        'متابعة سجل الإرسال مع إمكانية إعادة الإرسال عند الحاجة.',
      ],
      accountingImpact: 'مطابقة أرصدة العملاء اليومية وتقليل مخاطر تأخر التحصيل.',
      inventoryImpact: 'إشعار الإدارة بالتغيرات الحرجة في الأرصدة والمخزون بنهاية اليوم.',
      commonMistakes: ['إهمال فحص أرقام الهواتف الدولية قبل الإرسال.'],
      bestPractices: 'مراجعة أرقام هواتف العملاء وتحديثها دورياً.',
    },
    customers: {
      title: 'إدارة العملاء والتسلسل الإقليمي',
      purpose: 'إدارة بيانات العملاء، الحدود الائتمانية، تتبع المديونيات، وكشوف الحسابات.',
      responsibleRole: 'مسؤول المبيعات، المحاسب، مسؤول التحصيل',
      operationalSteps: [
        'إضافة العميل وتحديد تصنيفه وربطه بالهيكل الإقليمي.',
        'تحديد الحد الائتماني وفترة السداد الممنوحة للعميل.',
        'متابعة كشف الحساب التراكمي وإرسال إشعارات السداد عبر الواتساب أو تصديرها PDF.',
      ],
      accountingImpact: 'يرتبط رصيد العميل بحساب الذمم المدينة (114) في الأصول المتداولة.',
      inventoryImpact: 'يؤثر على حركة الصرف المباشر من المستودعات عند إصدار فواتير المبيعات.',
      commonMistakes: ['تجاوز الحد الائتماني دون موافقة الإدارة المالية.'],
      bestPractices: 'مطابقة كشوف الحسابات شهرياً مع العملاء.',
    },
    sales: {
      title: 'المبيعات وفواتير العملاء',
      purpose: 'إصدار فواتير ومرتجعات المبيعات النقدية والآجلة، حفظ المسودات، وإلغاء الفواتير بعكس القيود.',
      responsibleRole: 'مسؤول المبيعات، الكاشير، المحاسب',
      operationalSteps: [
        'اختيار العميل والمستودع والعملة وطريقة السداد.',
        'إضافة الأصناف بالكمية والكمية المجانية والخصم مع التحقق الآلي من توفر الرصيد.',
        'ترحيل الفاتورة أو حفظها كمسودة، مع إمكانية الإلغاء وعكس الأثر عند الحاجة.',
      ],
      accountingImpact: 'إنشاء قيد آلي مزدوج للإيراد والضريبة وتكلفة البضاعة المباعة.',
      inventoryImpact: 'خصم فوري للكميات المباعة وتسجيل حركة منصرف بالمستودع.',
      commonMistakes: ['محاولة البيع بالسالب عند نفاد رصيد الصنف بالمستودع.'],
      bestPractices: 'استخراج نسخة PDF الموثقة وتسليمها للمشتري.',
    },
    vendors: {
      title: 'إدارة الموردين والشركات الموردة',
      purpose: 'تتبع بيانات الموردين، الأرصدة المستحقة، فواتير التوريد، وسندات الصرف.',
      responsibleRole: 'مسؤول المشتريات، المحاسب',
      operationalSteps: [
        'تعريف الموردين وشروط السداد والائتمان التجاري.',
        'متابعة الذمم الدائنة واستحقاقات فواتير المشتريات.',
        'استخراج كشوف الحسابات المعتمدة للموردين لمطابقة الدفعات.',
      ],
      accountingImpact: 'يرتبط بحساب الذمم الدائنة (2110) ضمن الخصوم المتداولة.',
      inventoryImpact: 'المصدر الرئيسي لتدفق البضائع وزيادة الأرصدة المخزنية.',
      commonMistakes: ['تأخير تسجيل فواتير المشتريات مما يظهر أرصدة غير واقعية للمخزون.'],
      bestPractices: 'تسجيل الفاتورة فور استلام البضاعة في المستودع.',
    },
    purchases: {
      title: 'المشتريات والتوريدات المخزنية',
      purpose: 'إثبات مشتريات ومرتجعات البضائع، استلامها بالمستودعات، وتحديث متوسط التكلفة المرجح.',
      responsibleRole: 'مسؤول المشتريات، أمين المستودع، المحاسب',
      operationalSteps: [
        'اختيار المورد والمستودع المستلم والعملة.',
        'إدخال الأصناف والكميات المستلمة وأسعار الشراء الفعلية.',
        'ترحيل الفاتورة لزيادة رصيد المستودع وتحديث متوسط التكلفة المرجح.',
      ],
      accountingImpact: 'قيد آلي: من ح/ المخزون السلعي إلى ح/ المورد أو الصندوق.',
      inventoryImpact: 'إضافة فورية للكميات بالمستودع المستلم وتحديث بطاقة الصنف.',
      commonMistakes: ['إدخال أسعار شراء خاطئة مما يشوه حسابات التكلفة.'],
      bestPractices: 'مطابقة أمر الشراء مع إذن الاستلام وفاتورة المورد قبل الترحيل.',
    },
    inventory: {
      title: 'المخزون والمستودعات والتحويلات والجرد',
      purpose: 'مراقبة أرصدة الأصناف، التحويل بين الفروع، الجرد الفعلي بـ 4 نطاقات، وأذون المستودعات.',
      responsibleRole: 'مسؤول المخزون، أمناء المستودعات',
      operationalSteps: [
        'تعريف الأصناف ببياناتها ووحدات القياس وحدود إعادة الطلب.',
        'إجراء التحويلات بين المستودعات مع إمكانية عكس التحويل عند الحاجة.',
        'إنشاء جلسات الجرد الفعلي واعتمادها لتسوية الكميات وترحيل قيد الفائض/العجز.',
      ],
      accountingImpact: 'اعتماد الجرد يولد قيداً آلياً متوازناً بين حساب المخزون وحسابات الفائض والعجز.',
      inventoryImpact: 'التحكم الكامل بأرصدة جميع المستودعات ومنع التناقضات المخزنية.',
      commonMistakes: ['إغلاق جلسة الجرد كمسودة دون الضغط على اعتماد الجرد الفعلي.'],
      bestPractices: 'مراجعة تقرير النواقص أسبوعياً وتنفيذ الجرد الدوري.',
    },
    accounting: {
      title: 'المحاسبة العامة، الدفاتر المخصصة، والقيود',
      purpose: 'إدارة دليل الحسابات، قيود اليومية اليدوية والآلية والعكس، الدفاتر المخصصة، والقوائم الختامية.',
      responsibleRole: 'المدير المالي، المحاسب القانوني',
      operationalSteps: [
        'إنشاء قيود اليومية اليدوية مع التحقق الإجباري من تساوي المدين مع الدائن.',
        'استخدام الدفاتر المساعدة المخصصة للتسجيل المرن متعدد الصفوف.',
        'استعراض دفتر الأستاذ وميزان المراجعة وقوائم الدخل والمركز المالي والتدفقات النقدية.',
      ],
      accountingImpact: 'النواة المالية للنظام وفق معايير المحاسبة الدولية.',
      inventoryImpact: 'مطابقة ح/ المخزون بالدليل مع التقييم الفعلي لبضاعة المستودعات.',
      commonMistakes: ['تعديل قيد مرحل مباشرة بدلاً من استخدام قيد عكسي.'],
      bestPractices: 'مراجعة ميزان المراجعة وقائمة التدفقات النقدية بصفة دورية.',
    },
    treasury: {
      title: 'الخزينة والصناديق والبنوك والسندات',
      purpose: 'إدارة الصناديق والبنوك والمحافظ، سندات القبض والصرف الفردية والجماعية، والتحويلات النقدية.',
      responsibleRole: 'أمين الصندوق، المحاسب، المدير المالي',
      operationalSteps: [
        'إصدار سند قبض أو صرف فردي أو جماعي متعدد الصفوف والعملات.',
        'إدارة حسابات الصناديق والبنوك وتنفيذ التحويلات مع احتساب الرسوم.',
        'إلغاء أي سند غير صحيح لعكس أثره المالي تلقائياً.',
      ],
      accountingImpact: 'كل سند أو تحويل يولد قيداً محاسبياً متوازناً بالعملة المحلية.',
      inventoryImpact: 'لا يؤثر في المخزون مباشرة، بل يدير السيولة والذمم.',
      commonMistakes: ['عدم مطابقة عملة الصندوق مع عملة السند بدون الانتباه لسعر الصرف.'],
      bestPractices: 'مطابقة الرصيد الفعلي للصندوق مع الرصيد الدفتري نهاية كل وردية.',
    },
    expenses: {
      title: 'المصروفات التشغيلية ومراكز التكلفة',
      purpose: 'إثبات النفقات اليومية وتوزيعها على مراكز التكلفة ومتابعة بنود المصروفات.',
      responsibleRole: 'المحاسب، المدير المالي',
      operationalSteps: [
        'اختيار بند المصروف ومركز التكلفة المستفيد.',
        'تحديد الصندوق أو البنك المنفذ للصرف وترحيل القيد آلياً.',
      ],
      accountingImpact: 'قيد آلي: مدين ح/ المصروف، دائن ح/ الصندوق أو البنك.',
      inventoryImpact: 'لا يؤثر في المخزون مباشرة.',
      commonMistakes: ['تسجيل مصروف بدون تحديد مركز التكلفة الصحيح.'],
      bestPractices: 'مراقبة تقرير المصروفات شهرياً حسب مركز التكلفة.',
    },
    hr: {
      title: 'الموارد البشرية والرواتب',
      purpose: 'إدارة ملفات الموظفين ومسيرات الرواتب الشهرية وصرف المستحقات.',
      responsibleRole: 'مسؤول الموارد البشرية، المدير المالي',
      operationalSteps: [
        'تعريف الموظف والراتب الأساسي والبدلات المقررة.',
        'اعتماد وصرف مسير الرواتب الشهري وتوليد قيده المحاسبي تلقائياً.',
      ],
      accountingImpact: 'قيد آلي من ح/ مصروف الرواتب (5210) إلى ح/ الصندوق وح/ الاستقطاعات.',
      inventoryImpact: 'لا يوجد أثر مباشر على المخزون.',
      commonMistakes: ['صرف المسير دون مراجعة بدلات وحالة الموظفين.'],
      bestPractices: 'اعتماد مسير الرواتب قبل نهاية الشهر لترتيب السيولة.',
    },
    assets: {
      title: 'الأصول الثابتة والإهلاك',
      purpose: 'تسجيل الأصول الثابتة، احتساب العمر الإنتاجي، وترحيل قيود الإهلاك الدورية.',
      responsibleRole: 'المحاسب العام، المدير المالي',
      operationalSteps: [
        'تسجيل الأصل بتكلفته وقيمته التخريدية وعمره الإنتاجي بالأشهر.',
        'تشغيل احتساب الإهلاك الشهري بالقسط الثابت بنقرة واحدة.',
      ],
      accountingImpact: 'قيد آلي شهري من ح/ مصروف الإهلاك (5410) إلى ح/ مجمع الإهلاك (1290).',
      inventoryImpact: 'الأصول الثابتة أصول تشغيلية غير معدة للبيع.',
      commonMistakes: ['إهمال ترحيل الإهلاك الشهري مما يضخم الأرباح الدفترية.'],
      bestPractices: 'مراجعة القيمة الدفترية للأصول بصفة دورية.',
    },
    reports: {
      title: 'مركز التقارير والتحليلات الشاملة (22 تقريراً)',
      purpose: 'استخراج 22 تقريراً تفاعلياً مع الفلترة بالتاريخ والمستودع والطرف، وتصدير PDF حقيقي وExcel.',
      responsibleRole: 'المالك، الإدارة العليا، المدراء ورؤساء الأقسام',
      operationalSteps: [
        'اختيار التقرير المطلوب من المجموعات الأربع.',
        'ضبط فلاتر التاريخ والمستودع والطرف والحساب، والضغط على أي سجل للانتقال لتفاصيله.',
        'تصدير التقرير بصيغة PDF ثنائي أو Excel أو طباعته أو مشاركته عبر واتساب.',
      ],
      accountingImpact: 'تعتمد التقارير الختامية على القيود المرحلة في دفتر اليومية.',
      inventoryImpact: 'تقارير التقييم والحركة والجرد توضح وضع المستودعات الفعلي.',
      commonMistakes: ['نسيان مسح الفلاتر عند استعراض تقارير أخرى.'],
      bestPractices: 'حفظ نسخ PDF و Excel للتقارير الشهرية والختامية.',
    },
    tasks: {
      title: 'المهام والتنبيهات والمراسلات',
      purpose: 'متابعة التنبيهات الحرجة للمديونيات والنواقص، وتجهيز رسائل واتساب للعملاء والموردين.',
      responsibleRole: 'فريق المبيعات، المحصلين، الإدارة',
      operationalSteps: [
        'متابعة التنبيهات والانتقال المباشر للسجل المرتبط.',
        'تجهيز رسائل واتساب بالقوالب المعتمدة والتحقق من صيغة الهاتف.',
      ],
      accountingImpact: 'تسريع دورة التحصيل وتقليل الديون المتأخرة.',
      inventoryImpact: 'تنبيهات عند وصول أي صنف لحد إعادة الطلب.',
      commonMistakes: ['إرسال رسائل دون التحقق من رمز الدولة للرقم.'],
      bestPractices: 'المتابعة اليومية للتنبيهات غير المنجزة.',
    },
    settings: {
      title: 'مركز الإعدادات والتخصيص المؤسسي',
      purpose: 'تخصيص المؤسسة، الفروع، المستودعات، الوحدات، العملات، قوالب واتساب، تخصيص الواجهة، والصلاحيات.',
      responsibleRole: 'مدير النظام، مالك المؤسسة',
      operationalSteps: [
        'إدارة بيانات المؤسسة والسياسات وحسابات تسوية الجرد.',
        'تعديل أسعار الصرف وإضافة الفروع والمستودعات ووحدات القياس.',
        'تخصيص حجم الخط والسمة وإخفاء/إظهار القوائم الجانبية وأخذ نسخ احتياطية JSON.',
      ],
      accountingImpact: 'يتحكم في الضوابط المحاسبية وأسعار الصرف وحسابات الجرد.',
      inventoryImpact: 'تطبيق سياسة حظر البيع بالسالب وتعريف المستودعات والوحدات.',
      commonMistakes: ['استعادة نسخة غير مفحوصة أو تنفيذ إعادة ضبط دون أخذ نسخة احتياطية.'],
      bestPractices: 'الاحتفاظ بنسخة احتياطية JSON دورياً.',
    },
  };

  // ==========================================
  // TRANSACTIONAL OPERATIONAL BUSINESS LOGIC
  // ==========================================

  // 1. Save Draft Invoice (Sales or Purchases)
  const handleSaveDraftInvoice = (invoice: Invoice) => {
    const draftInv: Invoice = { ...invoice, status: 'draft' };
    const exists = db.invoices.some((i) => i.id === draftInv.id);
    const updatedInvoices = exists
      ? db.invoices.map((i) => (i.id === draftInv.id ? draftInv : i))
      : [...db.invoices, draftInv];

    setDb({
      ...db,
      invoices: updatedInvoices,
      auditLogs: [
        {
          id: `log-draft-${Date.now()}`,
          timestamp: new Date().toISOString(),
          userId: currentUser.id,
          userName: currentUser.fullName,
          action: exists ? 'تعديل' : 'إنشاء',
          module: draftInv.type.includes('مشتريات') ? 'المشتريات' : 'المبيعات',
          details: `حفظ مسودة فاتورة ${draftInv.type} رقم ${draftInv.invoiceNumber}`,
          entityId: draftInv.id,
        },
        ...db.auditLogs,
      ],
    });
  };

  // 2. Post Sales Invoice (or Return) — upserts drafts cleanly & handles multi-currency
  const handlePostSalesInvoice = (invoice: Invoice) => {
    const existing = db.invoices.find((i) => i.id === invoice.id);
    if (existing && existing.status !== 'draft') {
      notify('error', `الفاتورة رقم ${invoice.invoiceNumber} مرحلة مسبقاً.`);
      return;
    }

    const isReturn = invoice.type === 'مرتجع_مبيعات';
    const rate = invoice.exchangeRate || getCurrencyRate(invoice.currency);

    let updatedStocks = [...db.warehouseStock];
    const newMovements = [...db.stockMovements];

    for (const line of invoice.items) {
      const totalShippedQty = line.quantity + (line.bonusQuantity || 0);
      const qtyDelta = isReturn ? totalShippedQty : -totalShippedQty;
      updatedStocks = updateWarehouseStock(
        updatedStocks,
        line.itemId,
        invoice.warehouseId,
        qtyDelta,
        line.unitCost
      );

      newMovements.push({
        id: `sm-${Date.now()}-${line.itemId}-${Math.random().toString(36).slice(2, 6)}`,
        itemId: line.itemId,
        warehouseId: invoice.warehouseId,
        documentType: isReturn ? 'مرتجع_مبيعات' : 'فاتورة_مبيعات',
        documentNumber: invoice.invoiceNumber,
        documentId: invoice.id,
        movementDate: invoice.date,
        quantityChange: qtyDelta,
        unitCost: line.unitCost,
        totalCost: line.unitCost * totalShippedQty,
        runningBalance: 0,
        notes: line.bonusQuantity ? `بونص مجاني: ${line.bonusQuantity}` : line.notes,
        performedBy: currentUser.fullName,
      });
    }

    const existingJeNums = db.journalEntries.map((j) => j.entryNumber);
    const journalEntry = createSalesInvoiceJournalEntry(
      { ...invoice, exchangeRate: rate },
      db.chartOfAccounts,
      currentUser.fullName,
      existingJeNums
    );
    const updatedJournalEntries = [...db.journalEntries, journalEntry];

    const remainingBase = (invoice.remainingAmount || 0) * rate;
    const paidBase = (invoice.paidAmount || 0) * rate;
    const balanceDelta = isReturn ? -remainingBase : remainingBase;

    const targetCustomer = db.customers.find((c) => c.id === invoice.entityId);
    const prevCustomerBalance =
      invoice.previousBalanceSnapshot !== undefined
        ? invoice.previousBalanceSnapshot
        : targetCustomer?.currentBalance ?? 0;
    const newCustomerBalance = prevCustomerBalance + balanceDelta;

    const updatedCustomers = db.customers.map((c) =>
      c.id === invoice.entityId
        ? { ...c, currentBalance: c.currentBalance + balanceDelta }
        : c
    );

    let updatedTreasuries = [...db.treasuryAccounts];
    if (invoice.paidAmount > 0 && invoice.treasuryAccountId) {
      updatedTreasuries = updatedTreasuries.map((t) => {
        if (t.id === invoice.treasuryAccountId) {
          const tRate = getCurrencyRate(t.currency);
          const amtInTreasury = t.currency === invoice.currency ? invoice.paidAmount : paidBase / tRate;
          return {
            ...t,
            balance: isReturn ? t.balance - amtInTreasury : t.balance + amtInTreasury,
          };
        }
        return t;
      });
    }

    const enrichedInvoice: Invoice = {
      ...invoice,
      exchangeRate: rate,
      status: invoice.status === 'draft' ? (invoice.remainingAmount === 0 ? 'paid' : invoice.paidAmount > 0 ? 'partial' : 'posted') : invoice.status,
      previousBalanceSnapshot: prevCustomerBalance,
      newBalanceSnapshot: newCustomerBalance,
      journalEntryId: journalEntry.id,
    };

    const nextInvoices = existing
      ? db.invoices.map((i) => (i.id === existing.id ? enrichedInvoice : i))
      : [...db.invoices, enrichedInvoice];

    const newAuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: currentUser.id,
      userName: currentUser.fullName,
      action: 'ترحيل' as const,
      module: 'المبيعات' as const,
      details: `ترحيل ${invoice.type} رقم ${invoice.invoiceNumber} بقيمة (${invoice.grandTotal.toLocaleString()} ${invoice.currency})`,
      entityId: invoice.id,
    };

    setDb({
      ...db,
      invoices: nextInvoices,
      warehouseStock: updatedStocks,
      stockMovements: newMovements,
      journalEntries: updatedJournalEntries,
      customers: updatedCustomers,
      treasuryAccounts: updatedTreasuries,
      auditLogs: [newAuditLog, ...db.auditLogs],
    });
  };

  // 3. Post Purchase Invoice (or Return) — upserts drafts cleanly & handles multi-currency
  const handlePostPurchaseInvoice = (invoice: Invoice) => {
    const existing = db.invoices.find((i) => i.id === invoice.id);
    if (existing && existing.status !== 'draft') {
      notify('error', `الفاتورة رقم ${invoice.invoiceNumber} مرحلة مسبقاً.`);
      return;
    }

    const isReturn = invoice.type === 'مرتجع_مشتريات';
    const rate = invoice.exchangeRate || getCurrencyRate(invoice.currency);

    let updatedStocks = [...db.warehouseStock];
    const newMovements = [...db.stockMovements];

    for (const line of invoice.items) {
      const totalReceivedQty = line.quantity + (line.bonusQuantity || 0);
      const effectiveUnitCost =
        totalReceivedQty > 0 ? (line.unitCost * line.quantity) / totalReceivedQty : line.unitCost;
      const qtyDelta = isReturn ? -totalReceivedQty : totalReceivedQty;

      updatedStocks = updateWarehouseStock(
        updatedStocks,
        line.itemId,
        invoice.warehouseId,
        qtyDelta,
        effectiveUnitCost
      );

      newMovements.push({
        id: `sm-pur-${Date.now()}-${line.itemId}-${Math.random().toString(36).slice(2, 6)}`,
        itemId: line.itemId,
        warehouseId: invoice.warehouseId,
        documentType: isReturn ? 'مرتجع_مشتريات' : 'فاتورة_مشتريات',
        documentNumber: invoice.invoiceNumber,
        documentId: invoice.id,
        movementDate: invoice.date,
        quantityChange: qtyDelta,
        unitCost: effectiveUnitCost,
        totalCost: line.unitCost * line.quantity,
        runningBalance: 0,
        notes: line.bonusQuantity ? `بونص توريد مجاني: ${line.bonusQuantity}` : line.notes,
        performedBy: currentUser.fullName,
      });
    }

    const existingJeNums = db.journalEntries.map((j) => j.entryNumber);
    const journalEntry = createPurchaseInvoiceJournalEntry(
      { ...invoice, exchangeRate: rate },
      db.chartOfAccounts,
      currentUser.fullName,
      existingJeNums
    );
    const updatedJournalEntries = [...db.journalEntries, journalEntry];

    const remainingBase = (invoice.remainingAmount || 0) * rate;
    const paidBase = (invoice.paidAmount || 0) * rate;
    const balanceDelta = isReturn ? -remainingBase : remainingBase;

    const targetVendor = db.vendors.find((v) => v.id === invoice.entityId);
    const prevVendorBalance =
      invoice.previousBalanceSnapshot !== undefined
        ? invoice.previousBalanceSnapshot
        : targetVendor?.currentBalance ?? 0;
    const newVendorBalance = prevVendorBalance + balanceDelta;

    const updatedVendors = db.vendors.map((v) =>
      v.id === invoice.entityId
        ? { ...v, currentBalance: v.currentBalance + balanceDelta }
        : v
    );

    let updatedTreasuries = [...db.treasuryAccounts];
    if (invoice.paidAmount > 0 && invoice.treasuryAccountId) {
      updatedTreasuries = updatedTreasuries.map((t) => {
        if (t.id === invoice.treasuryAccountId) {
          const tRate = getCurrencyRate(t.currency);
          const amtInTreasury = t.currency === invoice.currency ? invoice.paidAmount : paidBase / tRate;
          return {
            ...t,
            balance: isReturn ? t.balance + amtInTreasury : t.balance - amtInTreasury,
          };
        }
        return t;
      });
    }

    const enrichedInvoice: Invoice = {
      ...invoice,
      exchangeRate: rate,
      status: invoice.status === 'draft' ? (invoice.remainingAmount === 0 ? 'paid' : invoice.paidAmount > 0 ? 'partial' : 'posted') : invoice.status,
      previousBalanceSnapshot: prevVendorBalance,
      newBalanceSnapshot: newVendorBalance,
      journalEntryId: journalEntry.id,
    };

    const nextInvoices = existing
      ? db.invoices.map((i) => (i.id === existing.id ? enrichedInvoice : i))
      : [...db.invoices, enrichedInvoice];

    const newAuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: currentUser.id,
      userName: currentUser.fullName,
      action: 'ترحيل' as const,
      module: 'المشتريات' as const,
      details: `ترحيل ${invoice.type} رقم ${invoice.invoiceNumber} بقيمة (${invoice.grandTotal.toLocaleString()} ${invoice.currency})`,
      entityId: invoice.id,
    };

    setDb({
      ...db,
      invoices: nextInvoices,
      warehouseStock: updatedStocks,
      stockMovements: newMovements,
      journalEntries: updatedJournalEntries,
      vendors: updatedVendors,
      treasuryAccounts: updatedTreasuries,
      auditLogs: [newAuditLog, ...db.auditLogs],
    });
  };

  // 3b. Cancel Posted/Draft Invoice (Idempotent with Stock, Balance, Treasury & Reversal JE)
  const handleCancelInvoice = (invoiceId: string) => {
    const inv = db.invoices.find((i) => i.id === invoiceId);
    if (!inv || inv.status === 'cancelled') {
      notify('info', 'الفاتورة ملغاة مسبقاً أو غير موجودة.');
      return;
    }

    const wasDraft = inv.status === 'draft';
    let updatedStocks = [...db.warehouseStock];
    const newMovements = [...db.stockMovements];
    let updatedCustomers = [...db.customers];
    let updatedVendors = [...db.vendors];
    let updatedTreasuries = [...db.treasuryAccounts];
    let updatedJEs = [...db.journalEntries];

    if (!wasDraft) {
      const rate = inv.exchangeRate || getCurrencyRate(inv.currency);
      const isSalesSide = inv.type === 'مبيعات' || inv.type === 'مرتجع_مبيعات';
      const wasStockDeducted = inv.type === 'مبيعات' || inv.type === 'مرتجع_مشتريات';

      for (const line of inv.items) {
        const qty = line.quantity + (line.bonusQuantity || 0);
        const reverseDelta = wasStockDeducted ? qty : -qty;
        updatedStocks = updateWarehouseStock(
          updatedStocks,
          line.itemId,
          inv.warehouseId,
          reverseDelta,
          line.unitCost
        );
        newMovements.push({
          id: `sm-can-${Date.now()}-${line.itemId}-${Math.random().toString(36).slice(2, 6)}`,
          itemId: line.itemId,
          warehouseId: inv.warehouseId,
          documentType: wasStockDeducted ? 'مرتجع_مبيعات' : 'مرتجع_مشتريات',
          documentNumber: `${inv.invoiceNumber}-CANCEL`,
          documentId: inv.id,
          movementDate: new Date().toISOString().split('T')[0],
          quantityChange: reverseDelta,
          unitCost: line.unitCost,
          totalCost: line.unitCost * qty,
          runningBalance: 0,
          notes: `عكس مخزون نتيجة إلغاء فاتورة ${inv.invoiceNumber}`,
          performedBy: currentUser.fullName,
        });
      }

      const remainingBase = (inv.remainingAmount || 0) * rate;
      const paidBase = (inv.paidAmount || 0) * rate;

      if (isSalesSide) {
        const sign = inv.type === 'مبيعات' ? -1 : 1;
        updatedCustomers = updatedCustomers.map((c) =>
          c.id === inv.entityId ? { ...c, currentBalance: c.currentBalance + sign * remainingBase } : c
        );
      } else {
        const sign = inv.type === 'مشتريات' ? -1 : 1;
        updatedVendors = updatedVendors.map((v) =>
          v.id === inv.entityId ? { ...v, currentBalance: v.currentBalance + sign * remainingBase } : v
        );
      }

      if (inv.paidAmount > 0 && inv.treasuryAccountId) {
        const treasurySign = inv.type === 'مبيعات' || inv.type === 'مرتجع_مشتريات' ? -1 : 1;
        updatedTreasuries = updatedTreasuries.map((t) => {
          if (t.id === inv.treasuryAccountId) {
            const tRate = getCurrencyRate(t.currency);
            const amtInTreasury = t.currency === inv.currency ? inv.paidAmount : paidBase / tRate;
            return { ...t, balance: t.balance + treasurySign * amtInTreasury };
          }
          return t;
        });
      }

      if (inv.journalEntryId) {
        const origJe = updatedJEs.find((j) => j.id === inv.journalEntryId && j.status === 'posted');
        if (origJe) {
          const revJe = createReversalJournalEntry(
            origJe,
            `إلغاء فاتورة ${inv.invoiceNumber}`,
            currentUser.fullName,
            updatedJEs.map((j) => j.entryNumber)
          );
          updatedJEs = updatedJEs.map((j) =>
            j.id === origJe.id ? { ...j, status: 'reversed' } : j
          );
          updatedJEs.push(revJe);
        }
      }
    }

    const updatedInvoices = db.invoices.map((i) =>
      i.id === inv.id ? { ...i, status: 'cancelled' as const } : i
    );

    setDb({
      ...db,
      invoices: updatedInvoices,
      warehouseStock: updatedStocks,
      stockMovements: newMovements,
      customers: updatedCustomers,
      vendors: updatedVendors,
      treasuryAccounts: updatedTreasuries,
      journalEntries: updatedJEs,
      auditLogs: [
        {
          id: `log-can-${Date.now()}`,
          timestamp: new Date().toISOString(),
          userId: currentUser.id,
          userName: currentUser.fullName,
          action: 'إلغاء',
          module: inv.type.includes('مشتريات') ? 'المشتريات' : 'المبيعات',
          details: `إلغاء ${wasDraft ? 'مسودة' : 'فاتورة'} رقم ${inv.invoiceNumber}${wasDraft ? '' : ' وعكس القيد والمخزون والأرصدة'}`,
          entityId: inv.id,
        },
        ...db.auditLogs,
      ],
    });
    notify('success', `تم إلغاء الفاتورة ${inv.invoiceNumber} وعكس أثرها بالكامل.`);
  };

  // 4. Post Receipt or Payment Voucher (with proper multi-currency conversion)
  const handlePostVoucher = (voucher: PaymentVoucher) => {
    const rate = voucher.exchangeRate || getCurrencyRate(voucher.currency);
    const baseAmt = voucher.baseAmount || voucher.amount * rate;
    const normalizedVoucher: PaymentVoucher = { ...voucher, exchangeRate: rate, baseAmount: baseAmt };

    const journalEntry = createVoucherJournalEntry(
      normalizedVoucher,
      db.chartOfAccounts,
      currentUser.fullName,
      db.journalEntries.map((j) => j.entryNumber)
    );

    const updatedTreasuries = db.treasuryAccounts.map((t) => {
      if (t.id === voucher.treasuryAccountId) {
        const tRate = getCurrencyRate(t.currency);
        const amtInTreasury = t.currency === voucher.currency ? voucher.amount : baseAmt / tRate;
        return {
          ...t,
          balance: voucher.type === 'قبض' ? t.balance + amtInTreasury : t.balance - amtInTreasury,
        };
      }
      return t;
    });

    let updatedCustomers = [...db.customers];
    if (voucher.entityType === 'عميل' && voucher.entityId) {
      updatedCustomers = updatedCustomers.map((c) => {
        if (c.id === voucher.entityId) {
          return {
            ...c,
            currentBalance:
              voucher.type === 'قبض' ? c.currentBalance - baseAmt : c.currentBalance + baseAmt,
          };
        }
        return c;
      });
    }

    let updatedVendors = [...db.vendors];
    if (voucher.entityType === 'مورد' && voucher.entityId) {
      updatedVendors = updatedVendors.map((v) => {
        if (v.id === voucher.entityId) {
          return {
            ...v,
            currentBalance:
              voucher.type === 'صرف' ? v.currentBalance - baseAmt : v.currentBalance + baseAmt,
          };
        }
        return v;
      });
    }

    const newAuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: currentUser.id,
      userName: currentUser.fullName,
      action: 'إنشاء' as const,
      module: 'الخزينة' as const,
      details: `ترحيل ${voucher.type === 'قبض' ? 'سند قبض' : 'سند صرف'} رقم ${voucher.voucherNumber} بمبلغ (${voucher.amount.toLocaleString()} ${voucher.currency})`,
      entityId: voucher.id,
    };

    setDb({
      ...db,
      paymentVouchers: [...db.paymentVouchers, { ...normalizedVoucher, journalEntryId: journalEntry.id }],
      journalEntries: [...db.journalEntries, journalEntry],
      treasuryAccounts: updatedTreasuries,
      customers: updatedCustomers,
      vendors: updatedVendors,
      auditLogs: [newAuditLog, ...db.auditLogs],
    });
  };

  // 4b. Atomic Batch Post Vouchers (with proper multi-currency conversion)
  const handleBatchPostVouchers = (vouchers: PaymentVoucher[]) => {
    let updatedTreasuries = [...db.treasuryAccounts];
    let updatedCustomers = [...db.customers];
    let updatedVendors = [...db.vendors];
    const newJournalEntries: JournalEntry[] = [];
    const newVouchers: PaymentVoucher[] = [];
    const newAuditLogs: ERPDatabase['auditLogs'] = [];
    const runningJeNums = db.journalEntries.map((j) => j.entryNumber);

    vouchers.forEach((voucher) => {
      const rate = voucher.exchangeRate || getCurrencyRate(voucher.currency);
      const baseAmt = voucher.baseAmount || voucher.amount * rate;
      const norm: PaymentVoucher = { ...voucher, exchangeRate: rate, baseAmount: baseAmt };

      const journalEntry = createVoucherJournalEntry(
        norm,
        db.chartOfAccounts,
        currentUser.fullName,
        runningJeNums
      );
      runningJeNums.push(journalEntry.entryNumber);
      newJournalEntries.push(journalEntry);
      newVouchers.push({ ...norm, journalEntryId: journalEntry.id });

      updatedTreasuries = updatedTreasuries.map((t) => {
        if (t.id === voucher.treasuryAccountId) {
          const tRate = getCurrencyRate(t.currency);
          const amtInTreasury = t.currency === voucher.currency ? voucher.amount : baseAmt / tRate;
          return {
            ...t,
            balance: voucher.type === 'قبض' ? t.balance + amtInTreasury : t.balance - amtInTreasury,
          };
        }
        return t;
      });

      if (voucher.entityType === 'عميل' && voucher.entityId) {
        updatedCustomers = updatedCustomers.map((c) =>
          c.id === voucher.entityId
            ? { ...c, currentBalance: voucher.type === 'قبض' ? c.currentBalance - baseAmt : c.currentBalance + baseAmt }
            : c
        );
      }

      if (voucher.entityType === 'مورد' && voucher.entityId) {
        updatedVendors = updatedVendors.map((v) =>
          v.id === voucher.entityId
            ? { ...v, currentBalance: voucher.type === 'صرف' ? v.currentBalance - baseAmt : v.currentBalance + baseAmt }
            : v
        );
      }

      newAuditLogs.push({
        id: `log-${Date.now()}-${voucher.id}`,
        timestamp: new Date().toISOString(),
        userId: currentUser.id,
        userName: currentUser.fullName,
        action: 'إنشاء',
        module: 'الخزينة',
        details: `ترحيل جماعي ${voucher.type === 'قبض' ? 'سند قبض' : 'سند صرف'} رقم ${voucher.voucherNumber} بمبلغ (${voucher.amount.toLocaleString()} ${voucher.currency})`,
        entityId: voucher.id,
      });
    });

    setDb({
      ...db,
      paymentVouchers: [...db.paymentVouchers, ...newVouchers],
      journalEntries: [...db.journalEntries, ...newJournalEntries],
      treasuryAccounts: updatedTreasuries,
      customers: updatedCustomers,
      vendors: updatedVendors,
      auditLogs: [...newAuditLogs, ...db.auditLogs],
    });
  };

  // 4c. Cancel Voucher (Idempotent + Reversal)
  const handleCancelVoucher = (voucherId: string) => {
    const v = db.paymentVouchers.find((x) => x.id === voucherId);
    if (!v || v.status === 'cancelled') {
      notify('info', 'السند ملغى مسبقاً أو غير موجود.');
      return;
    }

    const rate = v.exchangeRate || getCurrencyRate(v.currency);
    const baseAmt = v.baseAmount || v.amount * rate;

    const updatedTreasuries = db.treasuryAccounts.map((t) => {
      if (t.id === v.treasuryAccountId) {
        const tRate = getCurrencyRate(t.currency);
        const amtInTreasury = t.currency === v.currency ? v.amount : baseAmt / tRate;
        return {
          ...t,
          balance: v.type === 'قبض' ? t.balance - amtInTreasury : t.balance + amtInTreasury,
        };
      }
      return t;
    });

    const updatedCustomers =
      v.entityType === 'عميل' && v.entityId
        ? db.customers.map((c) =>
            c.id === v.entityId
              ? { ...c, currentBalance: v.type === 'قبض' ? c.currentBalance + baseAmt : c.currentBalance - baseAmt }
              : c
          )
        : db.customers;

    const updatedVendors =
      v.entityType === 'مورد' && v.entityId
        ? db.vendors.map((vnd) =>
            vnd.id === v.entityId
              ? { ...vnd, currentBalance: v.type === 'صرف' ? vnd.currentBalance + baseAmt : vnd.currentBalance - baseAmt }
              : vnd
          )
        : db.vendors;

    let updatedJEs = [...db.journalEntries];
    if (v.journalEntryId) {
      const origJe = updatedJEs.find((j) => j.id === v.journalEntryId && j.status === 'posted');
      if (origJe) {
        const revJe = createReversalJournalEntry(
          origJe,
          `إلغاء سند ${v.voucherNumber}`,
          currentUser.fullName,
          updatedJEs.map((j) => j.entryNumber)
        );
        updatedJEs = updatedJEs.map((j) => (j.id === origJe.id ? { ...j, status: 'reversed' } : j));
        updatedJEs.push(revJe);
      }
    }

    setDb({
      ...db,
      paymentVouchers: db.paymentVouchers.map((x) =>
        x.id === v.id ? { ...x, status: 'cancelled' as const } : x
      ),
      treasuryAccounts: updatedTreasuries,
      customers: updatedCustomers,
      vendors: updatedVendors,
      journalEntries: updatedJEs,
      auditLogs: [
        {
          id: `log-vcan-${Date.now()}`,
          timestamp: new Date().toISOString(),
          userId: currentUser.id,
          userName: currentUser.fullName,
          action: 'إلغاء',
          module: 'الخزينة',
          details: `إلغاء سند ${v.type} رقم ${v.voucherNumber} وعكس القيد والأرصدة`,
          entityId: v.id,
        },
        ...db.auditLogs,
      ],
    });
    notify('success', `تم إلغاء السند ${v.voucherNumber} وعكس أثره بنجاح.`);
  };

  // 4d. Save Treasury Account
  const handleSaveTreasuryAccount = (account: TreasuryAccount) => {
    const exists = db.treasuryAccounts.some((t) => t.id === account.id);
    const updated = exists
      ? db.treasuryAccounts.map((t) => (t.id === account.id ? account : t))
      : [...db.treasuryAccounts, account];

    setDb({
      ...db,
      treasuryAccounts: updated,
      auditLogs: [
        {
          id: `log-tr-${Date.now()}`,
          timestamp: new Date().toISOString(),
          userId: currentUser.id,
          userName: currentUser.fullName,
          action: exists ? 'تعديل' : 'إنشاء',
          module: 'الخزينة',
          details: `${exists ? 'تحديث' : 'إضافة'} حساب خزينة: ${account.nameAr} (${account.currency})`,
          entityId: account.id,
        },
        ...db.auditLogs,
      ],
    });
  };

  // 4e. Execute Treasury Transfer with Balanced Journal Entry
  const handleTreasuryTransfer = (transfer: TreasuryTransfer) => {
    const fromTr = db.treasuryAccounts.find((t) => t.id === transfer.fromTreasuryId);
    const toTr = db.treasuryAccounts.find((t) => t.id === transfer.toTreasuryId);
    if (!fromTr || !toTr || fromTr.id === toTr.id || transfer.amount <= 0) {
      notify('error', 'بيانات التحويل بين الصناديق غير صالحة.');
      return;
    }

    const rate = getCurrencyRate(transfer.currency);
    const baseAmt = transfer.amount * rate;
    const baseFee = (transfer.feeAmount || 0) * rate;

    const updatedTreasuries = db.treasuryAccounts.map((t) => {
      const tRate = getCurrencyRate(t.currency);
      if (t.id === fromTr.id) {
        const deductAmt = t.currency === transfer.currency ? transfer.amount + (transfer.feeAmount || 0) : (baseAmt + baseFee) / tRate;
        return { ...t, balance: t.balance - deductAmt };
      }
      if (t.id === toTr.id) {
        const addAmt = t.currency === transfer.currency ? transfer.amount : baseAmt / tRate;
        return { ...t, balance: t.balance + addAmt };
      }
      return t;
    });

    const accFrom =
      db.chartOfAccounts.find((a) => a.id === fromTr.generalLedgerAccountId) ||
      db.chartOfAccounts.find((a) => a.code === '1111')!;
    const accTo =
      db.chartOfAccounts.find((a) => a.id === toTr.generalLedgerAccountId) ||
      db.chartOfAccounts.find((a) => a.code === '1121') ||
      accFrom;
    const accBankFees =
      db.chartOfAccounts.find((a) => a.code === '5340') ||
      db.chartOfAccounts.find((a) => a.category === 'مصروفات' && a.isLeaf)!;

    const entryNumber = generateNextDocNumber(
      `JV-${new Date().getFullYear()}-`,
      db.journalEntries.map((j) => j.entryNumber),
      4
    );

    const jeLines = [
      {
        id: `jl-t1-${Date.now()}`,
        accountId: accTo.id,
        accountCode: accTo.code,
        accountName: `${accTo.nameAr} (${toTr.nameAr})`,
        debit: baseAmt,
        credit: 0,
        currency: transfer.currency,
        exchangeRate: rate,
        memo: `استلام تحويل نقدي ${transfer.transferNumber}`,
      },
      ...(baseFee > 0
        ? [
            {
              id: `jl-t2-${Date.now()}`,
              accountId: accBankFees.id,
              accountCode: accBankFees.code,
              accountName: accBankFees.nameAr,
              debit: baseFee,
              credit: 0,
              currency: transfer.currency,
              exchangeRate: rate,
              memo: `رسوم تحويل بنكي ${transfer.transferNumber}`,
            },
          ]
        : []),
      {
        id: `jl-t3-${Date.now()}`,
        accountId: accFrom.id,
        accountCode: accFrom.code,
        accountName: `${accFrom.nameAr} (${fromTr.nameAr})`,
        debit: 0,
        credit: baseAmt + baseFee,
        currency: transfer.currency,
        exchangeRate: rate,
        memo: `صرف تحويل نقدي إلى ${toTr.nameAr}`,
      },
    ];

    const je: JournalEntry = {
      id: `je-tr-${Date.now()}`,
      entryNumber,
      date: transfer.date,
      branchId: currentBranch.id,
      referenceType: 'تحويل_نقدية',
      referenceNumber: transfer.transferNumber,
      referenceId: transfer.id,
      description: `تحويل نقدي من ${fromTr.nameAr} إلى ${toTr.nameAr}`,
      lines: jeLines,
      totalDebit: baseAmt + baseFee,
      totalCredit: baseAmt + baseFee,
      status: 'posted',
      createdBy: currentUser.fullName,
      createdAt: new Date().toISOString(),
    };

    setDb({
      ...db,
      treasuryAccounts: updatedTreasuries,
      treasuryTransfers: [{ ...transfer, journalEntryId: je.id }, ...(db.treasuryTransfers || [])],
      journalEntries: [...db.journalEntries, je],
      auditLogs: [
        {
          id: `log-ttr-${Date.now()}`,
          timestamp: new Date().toISOString(),
          userId: currentUser.id,
          userName: currentUser.fullName,
          action: 'إنشاء',
          module: 'الخزينة',
          details: `تحويل نقدي رقم ${transfer.transferNumber} من (${fromTr.nameAr}) إلى (${toTr.nameAr}) بمبلغ ${transfer.amount.toLocaleString()} ${transfer.currency}`,
          entityId: transfer.id,
        },
        ...db.auditLogs,
      ],
    });
  };

  // 5. Post Expense Record
  const handlePostExpense = (expense: ExpenseRecord) => {
    const journalEntry = createExpenseJournalEntry(
      expense,
      db.chartOfAccounts,
      currentUser.fullName,
      db.journalEntries.map((j) => j.entryNumber)
    );

    const updatedTreasuries = db.treasuryAccounts.map((t) =>
      t.id === expense.treasuryAccountId ? { ...t, balance: t.balance - expense.total } : t
    );

    const newAuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: currentUser.id,
      userName: currentUser.fullName,
      action: 'إنشاء' as const,
      module: 'المصروفات' as const,
      details: `تسجيل مصروف رقم ${expense.expenseNumber} بقيمة (${expense.total.toLocaleString()} ${expense.currency}) - ${expense.statement}`,
      entityId: expense.id,
    };

    setDb({
      ...db,
      expenseRecords: [...db.expenseRecords, { ...expense, journalEntryId: journalEntry.id }],
      journalEntries: [...db.journalEntries, journalEntry],
      treasuryAccounts: updatedTreasuries,
      auditLogs: [newAuditLog, ...db.auditLogs],
    });
  };

  // 6. Post & Reverse Journal Entry & Custom Ledgers
  const handlePostManualEntry = (entry: JournalEntry) => {
    const newAuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: currentUser.id,
      userName: currentUser.fullName,
      action: 'ترحيل' as const,
      module: 'المحاسبة' as const,
      details: `ترحيل قيد يومية يدوي رقم ${entry.entryNumber} بقيمة متوازنة (${entry.totalDebit.toLocaleString()} ${currentCurrency.symbol})`,
      entityId: entry.id,
    };

    setDb({
      ...db,
      journalEntries: [...db.journalEntries, entry],
      auditLogs: [newAuditLog, ...db.auditLogs],
    });
  };

  const handleReverseJournalEntry = (entryId: string, reason: string) => {
    const orig = db.journalEntries.find((j) => j.id === entryId);
    if (!orig || orig.status === 'reversed') {
      notify('error', 'هذا القيد معكوس مسبقاً أو غير موجود.');
      return;
    }
    const rev = createReversalJournalEntry(
      orig,
      reason,
      currentUser.fullName,
      db.journalEntries.map((j) => j.entryNumber)
    );
    const updatedJEs = db.journalEntries.map((j) =>
      j.id === orig.id ? { ...j, status: 'reversed' as const } : j
    );
    setDb({
      ...db,
      journalEntries: [...updatedJEs, rev],
      auditLogs: [
        {
          id: `log-rev-${Date.now()}`,
          timestamp: new Date().toISOString(),
          userId: currentUser.id,
          userName: currentUser.fullName,
          action: 'إلغاء',
          module: 'المحاسبة',
          details: `عكس القيد المحاسبي ${orig.entryNumber} بالقيد العكسي ${rev.entryNumber} - السبب: ${reason}`,
          entityId: rev.id,
        },
        ...db.auditLogs,
      ],
    });
    notify('success', `تم إنشاء القيد العكسي ${rev.entryNumber} بنجاح.`);
  };

  const handleSaveCustomBook = (book: CustomLedgerBook) => {
    const existing = db.customBooks || [];
    const exists = existing.some((b) => b.id === book.id);
    const updated = exists ? existing.map((b) => (b.id === book.id ? book : b)) : [...existing, book];
    setDb({ ...db, customBooks: updated });
  };

  const handleSaveCustomBookEntry = (entry: CustomLedgerEntry) => {
    const existing = db.customBookEntries || [];
    const exists = existing.some((e) => e.id === entry.id);
    const updated = exists ? existing.map((e) => (e.id === entry.id ? entry : e)) : [entry, ...existing];
    setDb({ ...db, customBookEntries: updated });
  };

  // 7. Warehouse Stock Transfer & Reversal
  const handleExecuteTransfer = (transfer: InventoryTransfer) => {
    const res = executeInventoryTransfer(db.warehouseStock, transfer, currentUser.fullName);
    if (!res.success) {
      notify('error', res.error || 'تعذر تنفيذ التحويل المخزني.');
      return;
    }

    const completedTransfer: InventoryTransfer = { ...transfer, status: 'completed' };
    setDb({
      ...db,
      warehouseStock: res.newStocks,
      stockMovements: [...db.stockMovements, ...res.movements],
      inventoryTransfers: [...db.inventoryTransfers, completedTransfer],
      auditLogs: [
        {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          userId: currentUser.id,
          userName: currentUser.fullName,
          action: 'إنشاء',
          module: 'المخزون',
          details: `تنفيذ تحويل مخزني رقم ${transfer.transferNumber} من مستودع ${transfer.fromWarehouseId} إلى ${transfer.toWarehouseId}`,
          entityId: transfer.id,
        },
        ...db.auditLogs,
      ],
    });
    notify('success', `تم تنفيذ التحويل المخزني ${transfer.transferNumber} وتحديث أرصدة المستودعات.`);
  };

  const handleReverseTransfer = (transfer: InventoryTransfer) => {
    const res = reverseInventoryTransfer(db.warehouseStock, transfer, currentUser.fullName);
    if (!res.success) {
      notify('error', res.error || 'تعذر عكس التحويل المخزني.');
      return;
    }
    setDb({
      ...db,
      warehouseStock: res.newStocks,
      stockMovements: [...db.stockMovements, ...res.movements],
      inventoryTransfers: db.inventoryTransfers.map((t) =>
        t.id === transfer.id ? { ...t, status: 'cancelled' as const } : t
      ),
      auditLogs: [
        {
          id: `log-revtr-${Date.now()}`,
          timestamp: new Date().toISOString(),
          userId: currentUser.id,
          userName: currentUser.fullName,
          action: 'إلغاء',
          module: 'المخزون',
          details: `عكس وإلغاء التحويل المخزني رقم ${transfer.transferNumber}`,
          entityId: transfer.id,
        },
        ...db.auditLogs,
      ],
    });
    notify('success', `تم عكس التحويل المخزني ${transfer.transferNumber} واسترداد الكميات.`);
  };

  // 8. Legacy single adjust handler + Persistent Stocktaking Save Draft & Approve
  const handleAdjustStock = (itemId: string, warehouseId: string, diff: number, reason: string) => {
    const it = db.inventoryItems.find((i) => i.id === itemId);
    const unitCost = it ? it.purchasePrice : 10000;
    const updatedStocks = updateWarehouseStock(db.warehouseStock, itemId, warehouseId, diff, unitCost);
    setDb({
      ...db,
      warehouseStock: updatedStocks,
      stockMovements: [
        ...db.stockMovements,
        {
          id: `sm-adj-${Date.now()}`,
          itemId,
          warehouseId,
          documentType: diff > 0 ? 'تسوية_زيادة' : 'تسوية_عجز',
          documentNumber: `ADJ-${Date.now().toString().slice(-4)}`,
          documentId: `adj-${Date.now()}`,
          movementDate: new Date().toISOString().split('T')[0],
          quantityChange: diff,
          unitCost,
          totalCost: Math.abs(diff * unitCost),
          runningBalance: 0,
          notes: reason,
          performedBy: currentUser.fullName,
        },
      ],
      auditLogs: [
        {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          userId: currentUser.id,
          userName: currentUser.fullName,
          action: 'تعديل',
          module: 'المخزون',
          details: `تسوية جرد للصنف ${it?.nameAr} بمقدار (${diff > 0 ? `+${diff}` : diff}) لسبب: ${reason}`,
        },
        ...db.auditLogs,
      ],
    });
  };

  const handleSaveStocktaking = (stocktake: PhysicalStocktaking) => {
    const existing = db.stocktakings.find((s) => s.id === stocktake.id);
    if (existing?.status === 'approved') {
      notify('error', 'لا يمكن تعديل محضر جرد معتمد مسبقاً.');
      return;
    }
    const nextStocktakings = existing
      ? db.stocktakings.map((s) => (s.id === stocktake.id ? stocktake : s))
      : [stocktake, ...db.stocktakings];
    setDb({ ...db, stocktakings: nextStocktakings });
    notify('success', `تم حفظ مسودة الجرد ${stocktake.stocktakeNumber}.`);
  };

  const handleApproveStocktaking = (stocktake: PhysicalStocktaking) => {
    const existing = db.stocktakings.find((s) => s.id === stocktake.id);
    if (existing?.status === 'approved') {
      notify('error', `محضر الجرد ${stocktake.stocktakeNumber} معتمد مسبقاً.`);
      return;
    }

    const res = applyStocktakingAdjustments(db.warehouseStock, stocktake, currentUser.fullName);
    if (!res.success) {
      notify('error', res.error || 'تعذر اعتماد محضر الجرد.');
      return;
    }

    const je = createStocktakingJournalEntry(
      stocktake,
      db.chartOfAccounts,
      db.settings.stocktakeSurplusAccountCode || '4190',
      db.settings.stocktakeShortageAccountCode || '5390',
      currentUser.fullName,
      db.journalEntries.map((j) => j.entryNumber)
    );

    const approvedStocktake: PhysicalStocktaking = {
      ...stocktake,
      status: 'approved',
      approvedBy: currentUser.fullName,
      approvedAt: new Date().toISOString(),
      adjustmentJournalEntryId: je?.id,
    };

    const nextStocktakings = existing
      ? db.stocktakings.map((s) => (s.id === stocktake.id ? approvedStocktake : s))
      : [approvedStocktake, ...db.stocktakings];

    setDb({
      ...db,
      stocktakings: nextStocktakings,
      warehouseStock: res.newStocks,
      stockMovements: [...db.stockMovements, ...res.movements],
      journalEntries: je ? [...db.journalEntries, je] : db.journalEntries,
      auditLogs: [
        {
          id: `log-st-${Date.now()}`,
          timestamp: new Date().toISOString(),
          userId: currentUser.id,
          userName: currentUser.fullName,
          action: 'ترحيل',
          module: 'المخزون',
          details: `اعتماد محضر جرد مخزني رقم ${stocktake.stocktakeNumber} وترحيل ${res.movements.length} تسوية مخزنية${je ? ` والقيد ${je.entryNumber}` : ''}`,
          entityId: stocktake.id,
        },
        ...db.auditLogs,
      ],
    });
    notify('success', `تم اعتماد محضر الجرد ${stocktake.stocktakeNumber} وتحديث المخزون والقيود بنجاح.`);
  };

  // 9. Payroll & Fixed Assets
  const handleDisbursePayroll = (payroll: PayrollRun) => {
    const updatedTreasuries = db.treasuryAccounts.map((t) =>
      t.id === payroll.disbursementTreasuryId ? { ...t, balance: t.balance - payroll.totalNet } : t
    );

    const accSalaries = db.chartOfAccounts.find((a) => a.code === '5210')!;
    const accTreasury = db.chartOfAccounts.find((a) => a.code === '1111')!;
    const accDeductions = db.chartOfAccounts.find((a) => a.code === '2130')!;

    const entryNumber = generateNextDocNumber(
      `JV-${new Date().getFullYear()}-`,
      db.journalEntries.map((j) => j.entryNumber),
      4
    );

    const payrollEntry: JournalEntry = {
      id: `je-pay-${Date.now()}`,
      entryNumber,
      date: payroll.disbursedDate || new Date().toISOString().split('T')[0],
      branchId: currentBranch.id,
      referenceType: 'رواتب',
      referenceNumber: payroll.payrollNumber,
      referenceId: payroll.id,
      description: `قيد إثبات وصرف رواتب شهر ${payroll.month}`,
      lines: [
        {
          id: `jl-p1-${Date.now()}`,
          accountId: accSalaries.id,
          accountCode: accSalaries.code,
          accountName: accSalaries.nameAr,
          debit: payroll.totalGross,
          credit: 0,
          currency: 'YER',
          exchangeRate: 1,
          memo: `إجمالي استحقاق رواتب شهر ${payroll.month}`,
        },
        {
          id: `jl-p2-${Date.now()}`,
          accountId: accTreasury.id,
          accountCode: accTreasury.code,
          accountName: accTreasury.nameAr,
          debit: 0,
          credit: payroll.totalNet,
          currency: 'YER',
          exchangeRate: 1,
          memo: `صرف صافي الرواتب للموظفين`,
        },
        {
          id: `jl-p3-${Date.now()}`,
          accountId: accDeductions.id,
          accountCode: accDeductions.code,
          accountName: accDeductions.nameAr,
          debit: 0,
          credit: payroll.totalDeductions,
          currency: 'YER',
          exchangeRate: 1,
          memo: `استقطاعات السلف والتأمينات`,
        },
      ],
      totalDebit: payroll.totalGross,
      totalCredit: payroll.totalGross,
      status: 'posted',
      createdBy: currentUser.fullName,
      createdAt: new Date().toISOString(),
    };

    setDb({
      ...db,
      payrollRuns: [...db.payrollRuns, { ...payroll, journalEntryId: payrollEntry.id }],
      journalEntries: [...db.journalEntries, payrollEntry],
      treasuryAccounts: updatedTreasuries,
      auditLogs: [
        {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          userId: currentUser.id,
          userName: currentUser.fullName,
          action: 'ترحيل',
          module: 'الرواتب',
          details: `صرف مسير رواتب شهر ${payroll.month} بإجمالي صافي (${payroll.totalNet.toLocaleString()} ${currentCurrency.symbol})`,
          entityId: payroll.id,
        },
        ...db.auditLogs,
      ],
    });
  };

  const handleRunDepreciation = (totalDepr: number) => {
    const accExpense = db.chartOfAccounts.find((a) => a.code === '5410')!;
    const accAccDepr = db.chartOfAccounts.find((a) => a.code === '1290')!;

    const entryNumber = generateNextDocNumber(
      `JV-${new Date().getFullYear()}-`,
      db.journalEntries.map((j) => j.entryNumber),
      4
    );

    const deprEntry: JournalEntry = {
      id: `je-depr-${Date.now()}`,
      entryNumber,
      date: new Date().toISOString().split('T')[0],
      branchId: currentBranch.id,
      referenceType: 'إهلاك',
      referenceNumber: `DEPR-${Date.now().toString().slice(-4)}`,
      description: 'قيد إثبات إهلاك الأصول الثابتة الدوري (القسط الثابت)',
      lines: [
        {
          id: `jl-d1-${Date.now()}`,
          accountId: accExpense.id,
          accountCode: accExpense.code,
          accountName: accExpense.nameAr,
          debit: totalDepr,
          credit: 0,
          currency: 'YER',
          exchangeRate: 1,
          memo: 'مصروف إهلاك أصول الشهر الحالي',
        },
        {
          id: `jl-d2-${Date.now()}`,
          accountId: accAccDepr.id,
          accountCode: accAccDepr.code,
          accountName: accAccDepr.nameAr,
          debit: 0,
          credit: totalDepr,
          currency: 'YER',
          exchangeRate: 1,
          memo: 'مجمع إهلاك الأصول الثابتة',
        },
      ],
      totalDebit: totalDepr,
      totalCredit: totalDepr,
      status: 'posted',
      createdBy: currentUser.fullName,
      createdAt: new Date().toISOString(),
    };

    const updatedAssets = db.fixedAssets.map((a) => {
      if (a.status !== 'active' || a.currentBookValue <= a.salvageValue) return a;
      const monthly = Math.min(
        a.currentBookValue - a.salvageValue,
        Math.round((a.purchaseCost - a.salvageValue) / (a.usefulLifeMonths || 48))
      );
      return {
        ...a,
        totalAccumulatedDepreciation: a.totalAccumulatedDepreciation + monthly,
        currentBookValue: Math.max(a.salvageValue, a.currentBookValue - monthly),
      };
    });

    setDb({
      ...db,
      fixedAssets: updatedAssets,
      journalEntries: [...db.journalEntries, deprEntry],
      auditLogs: [
        {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          userId: currentUser.id,
          userName: currentUser.fullName,
          action: 'ترحيل',
          module: 'الأصول',
          details: `احتساب وترحيل قيد إهلاك الأصول الثابتة بمبلغ (${totalDepr.toLocaleString()} ${currentCurrency.symbol})`,
        },
        ...db.auditLogs,
      ],
    });
  };

  // 10. Reset & Restore & Settings CRUD
  const executeResetDatabase = () => {
    const pristine = resetToDemoDatabase();
    setDb(pristine);
    if (pristine.branches[0]) setCurrentBranch(pristine.branches[0]);
    if (pristine.currencies[0]) setCurrentCurrency(pristine.currencies[0]);
    if (pristine.users[0]) setCurrentUser(pristine.users[0]);
    setIsResetConfirmOpen(false);
    notify('success', 'تمت إعادة ضبط النظام إلى بيانات المصنع التجريبية بنجاح.');
  };

  const handleSaveColumnPrefs = useCallback((tableId: string, prefs: TableColumnPref[]) => {
    setDb((prev) => {
      const currentUi = prev.settings.uiPreferences || {
        fontSize: 14,
        accentPreset: 'amber',
        hiddenModules: [],
        tableColumnPrefs: {},
      };
      return {
        ...prev,
        settings: {
          ...prev.settings,
          uiPreferences: {
            ...currentUi,
            tableColumnPrefs: {
              ...(currentUi.tableColumnPrefs || {}),
              [tableId]: prefs,
            },
          },
        },
      };
    });
  }, []);

  const savedColPrefsMap = db.settings.uiPreferences?.tableColumnPrefs || {};

  return (
    <div
      className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500/20 selection:text-amber-300"
      dir="rtl"
    >
      {/* Top Application Header */}
      <Header
        currentBranch={currentBranch}
        branches={db.branches}
        onSelectBranch={setCurrentBranch}
        currentCurrency={currentCurrency}
        currencies={db.currencies}
        onSelectCurrency={setCurrentCurrency}
        currentUser={currentUser}
        users={db.users}
        onSwitchUser={setCurrentUser}
        onOpenQuickNewModal={() => setActiveModule('sales')}
        onOpenHelp={() => setIsHelpOpen(true)}
        onResetData={() => setIsResetConfirmOpen(true)}
        unreadAlertsCount={db.taskAlerts.filter((t) => !t.isCompleted).length}
        onOpenAlerts={() => setActiveModule('tasks')}
        isSidebarOpen={isSidebarOpen}
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
      />

      {/* Main Layout Area */}
      <div className="flex-1 flex overflow-hidden">
        <Sidebar
          activeModule={activeModule}
          onSelectModule={(mod) => {
            setFocusedRecordId(undefined);
            setActiveModule(mod);
          }}
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
          userRole={currentUser.role}
          hiddenModules={db.settings.uiPreferences?.hiddenModules || []}
        />

        {/* Content Viewport */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 max-w-[1600px] w-full mx-auto">
          {activeModule === 'dashboard' && (
            <DashboardModule
              db={db}
              onNavigate={(mod) => {
                setFocusedRecordId(undefined);
                setActiveModule(mod);
              }}
              onOpenQuickNew={() => setActiveModule('sales')}
              currencySymbol={currentCurrency.symbol}
            />
          )}

          {activeModule === 'daily_report' && (
            <DailyManagementReportModule
              db={db}
              onOpenDocument={(_docType, _docId) => setActiveModule('unified_docs')}
              onNavigateToRecord={navigateToRecord}
              onNotify={notify}
            />
          )}

          {activeModule === 'unified_docs' && (
            <UnifiedDocumentsModule
              db={db}
              onOpenPrintModal={setPrintableDoc}
              savedColumnPrefs={savedColPrefsMap['unified-documents']}
              onSaveColumnPrefs={handleSaveColumnPrefs}
              onNavigateToRecord={navigateToRecord}
              onNotify={notify}
            />
          )}

          {activeModule === 'scheduled_dispatch' && (
            <ScheduledDispatchModule
              db={db}
              onUpdateSettings={(s) => setDb({ ...db, settings: s })}
              onAddDispatchLog={(log: DispatchLogEntry) =>
                setDb({ ...db, dispatchLogs: [log, ...(db.dispatchLogs || [])] })
              }
              onRetryDispatch={(logId) =>
                setDb({
                  ...db,
                  dispatchLogs: (db.dispatchLogs || []).map((l) =>
                    l.id === logId ? { ...l, status: 'sent' as const, retryCount: l.retryCount + 1 } : l
                  ),
                })
              }
              savedColumnPrefs={savedColPrefsMap['dispatch-logs']}
              onSaveColumnPrefs={handleSaveColumnPrefs}
              onNotify={notify}
            />
          )}

          {activeModule === 'customers' && (
            <CustomersModule
              customers={db.customers}
              regionalAreas={db.regionalAreas}
              invoices={db.invoices}
              paymentVouchers={db.paymentVouchers}
              journalEntries={db.journalEntries}
              currentBranch={currentBranch}
              company={db.company}
              currencySymbol={currentCurrency.symbol}
              whatsappTemplates={db.settings.whatsappTemplates}
              savedColumnPrefs={savedColPrefsMap['customers-list']}
              onSaveColumnPrefs={handleSaveColumnPrefs}
              focusedRecordId={focusedRecordId}
              onSaveCustomer={(c: Customer) => {
                const exists = db.customers.some((item) => item.id === c.id);
                setDb({
                  ...db,
                  customers: exists
                    ? db.customers.map((item) => (item.id === c.id ? c : item))
                    : [c, ...db.customers],
                });
              }}
              onOpenPrintModal={setPrintableDoc}
              onNotify={notify}
            />
          )}

          {activeModule === 'sales' && (
            <SalesModule
              invoices={db.invoices}
              customers={db.customers}
              warehouses={db.warehouses}
              inventoryItems={db.inventoryItems}
              warehouseStock={db.warehouseStock}
              treasuryAccounts={db.treasuryAccounts}
              currencies={db.currencies}
              currentBranch={currentBranch}
              currencySymbol={currentCurrency.symbol}
              allowNegativeStock={db.settings.allowNegativeStock}
              canPostEntries={currentUser.canPostEntries}
              company={db.company}
              autoDownloadInvoices={db.settings.autoDownloadInvoices}
              whatsappTemplates={db.settings.whatsappTemplates}
              savedColumnPrefs={savedColPrefsMap['sales-invoices']}
              onSaveColumnPrefs={handleSaveColumnPrefs}
              focusedRecordId={focusedRecordId}
              onPostSalesInvoice={handlePostSalesInvoice}
              onSaveDraftInvoice={handleSaveDraftInvoice}
              onCancelInvoice={handleCancelInvoice}
              onOpenPrintModal={setPrintableDoc}
              onNotify={notify}
            />
          )}

          {activeModule === 'vendors' && (
            <VendorsModule
              vendors={db.vendors}
              invoices={db.invoices}
              paymentVouchers={db.paymentVouchers}
              journalEntries={db.journalEntries}
              currentBranch={currentBranch}
              company={db.company}
              currencySymbol={currentCurrency.symbol}
              whatsappTemplates={db.settings.whatsappTemplates}
              savedColumnPrefs={savedColPrefsMap['vendors-list']}
              onSaveColumnPrefs={handleSaveColumnPrefs}
              focusedRecordId={focusedRecordId}
              onSaveVendor={(v: Vendor) => {
                const exists = db.vendors.some((item) => item.id === v.id);
                setDb({
                  ...db,
                  vendors: exists
                    ? db.vendors.map((item) => (item.id === v.id ? v : item))
                    : [v, ...db.vendors],
                });
              }}
              onOpenPrintModal={setPrintableDoc}
              onNotify={notify}
            />
          )}

          {activeModule === 'purchases' && (
            <PurchasesModule
              invoices={db.invoices}
              vendors={db.vendors}
              warehouses={db.warehouses}
              inventoryItems={db.inventoryItems}
              treasuryAccounts={db.treasuryAccounts}
              currencies={db.currencies}
              currentBranch={currentBranch}
              company={db.company}
              currencySymbol={currentCurrency.symbol}
              canPostEntries={currentUser.canPostEntries}
              whatsappTemplates={db.settings.whatsappTemplates}
              savedColumnPrefs={savedColPrefsMap['purchase-invoices']}
              onSaveColumnPrefs={handleSaveColumnPrefs}
              focusedRecordId={focusedRecordId}
              onPostPurchaseInvoice={handlePostPurchaseInvoice}
              onSaveDraftInvoice={handleSaveDraftInvoice}
              onCancelInvoice={handleCancelInvoice}
              onOpenPrintModal={setPrintableDoc}
              onNotify={notify}
            />
          )}

          {activeModule === 'inventory' && (
            <InventoryModule
              items={db.inventoryItems}
              warehouses={db.warehouses}
              warehouseStock={db.warehouseStock}
              stockMovements={db.stockMovements}
              inventoryTransfers={db.inventoryTransfers}
              stocktakings={db.stocktakings}
              currencySymbol={currentCurrency.symbol}
              warehouseDocuments={db.warehouseDocuments || []}
              canAdjustInventory={currentUser.canAdjustInventory}
              unitsOfMeasure={db.unitsOfMeasure}
              company={db.company}
              branch={currentBranch}
              savedColumnPrefs={savedColPrefsMap}
              onSaveColumnPrefs={handleSaveColumnPrefs}
              focusedRecordId={focusedRecordId}
              onSaveItem={(item: InventoryItem) => {
                const exists = db.inventoryItems.some((i) => i.id === item.id);
                setDb({
                  ...db,
                  inventoryItems: exists
                    ? db.inventoryItems.map((i) => (i.id === item.id ? item : i))
                    : [item, ...db.inventoryItems],
                });
              }}
              onExecuteTransfer={handleExecuteTransfer}
              onReverseTransfer={handleReverseTransfer}
              onAdjustStock={handleAdjustStock}
              onSaveWarehouseDoc={(doc: WarehouseDocument) =>
                setDb({
                  ...db,
                  warehouseDocuments: [doc, ...(db.warehouseDocuments || [])],
                  auditLogs: [
                    {
                      id: `log-${Date.now()}`,
                      timestamp: new Date().toISOString(),
                      userId: currentUser.id,
                      userName: currentUser.fullName,
                      action: 'إنشاء',
                      module: 'المخزون',
                      details: `إصدار ${doc.type} رقم ${doc.documentNumber} للمستودع`,
                      entityId: doc.id,
                    },
                    ...db.auditLogs,
                  ],
                })
              }
              onSaveStocktaking={handleSaveStocktaking}
              onApproveStocktaking={handleApproveStocktaking}
              onNotify={notify}
            />
          )}

          {activeModule === 'accounting' && (
            <AccountingModule
              chartOfAccounts={db.chartOfAccounts}
              journalEntries={db.journalEntries}
              costCenters={db.costCenters}
              invoices={db.invoices}
              paymentVouchers={db.paymentVouchers}
              expenseRecords={db.expenseRecords}
              customBooks={db.customBooks}
              customBookEntries={db.customBookEntries}
              currentBranch={currentBranch}
              company={db.company}
              currencySymbol={currentCurrency.symbol}
              canPostEntries={currentUser.canPostEntries}
              focusedRecordId={focusedRecordId}
              onPostManualEntry={handlePostManualEntry}
              onReverseJournalEntry={handleReverseJournalEntry}
              onSaveCustomBook={handleSaveCustomBook}
              onSaveCustomBookEntry={handleSaveCustomBookEntry}
              onOpenPrintModal={setPrintableDoc}
              onNotify={notify}
            />
          )}

          {activeModule === 'treasury' && (
            <TreasuryModule
              treasuryAccounts={db.treasuryAccounts}
              treasuryTransfers={db.treasuryTransfers}
              paymentVouchers={db.paymentVouchers}
              customers={db.customers}
              vendors={db.vendors}
              currencies={db.currencies}
              chartOfAccounts={db.chartOfAccounts}
              paymentMethods={db.settings.paymentMethods}
              currentBranch={currentBranch}
              company={db.company}
              currencySymbol={currentCurrency.symbol}
              canPostEntries={currentUser.canPostEntries}
              whatsappTemplates={db.settings.whatsappTemplates}
              savedColumnPrefs={savedColPrefsMap['treasury-vouchers']}
              onSaveColumnPrefs={handleSaveColumnPrefs}
              focusedRecordId={focusedRecordId}
              onPostVoucher={handlePostVoucher}
              onBatchPostVouchers={handleBatchPostVouchers}
              onCancelVoucher={handleCancelVoucher}
              onSaveTreasuryAccount={handleSaveTreasuryAccount}
              onTreasuryTransfer={handleTreasuryTransfer}
              onOpenPrintModal={setPrintableDoc}
              onNotify={notify}
            />
          )}

          {activeModule === 'expenses' && (
            <ExpensesModule
              expenses={db.expenseRecords}
              categories={db.expenseCategories}
              costCenters={db.costCenters}
              treasuryAccounts={db.treasuryAccounts}
              currentBranch={currentBranch}
              company={db.company}
              currencySymbol={currentCurrency.symbol}
              canPostEntries={currentUser.canPostEntries}
              savedColumnPrefs={savedColPrefsMap['expenses-records']}
              onSaveColumnPrefs={handleSaveColumnPrefs}
              focusedRecordId={focusedRecordId}
              onPostExpense={handlePostExpense}
              onNotify={notify}
            />
          )}

          {activeModule === 'hr' && (
            <HrPayrollModule
              employees={db.employees}
              payrollRuns={db.payrollRuns}
              treasuryAccounts={db.treasuryAccounts}
              currentBranch={currentBranch}
              company={db.company}
              currencySymbol={currentCurrency.symbol}
              canPostEntries={currentUser.canPostEntries}
              savedColumnPrefs={savedColPrefsMap}
              onSaveColumnPrefs={handleSaveColumnPrefs}
              onSaveEmployee={(emp: Employee) => setDb({ ...db, employees: [emp, ...db.employees] })}
              onDisbursePayroll={handleDisbursePayroll}
              onNotify={notify}
            />
          )}

          {activeModule === 'assets' && (
            <FixedAssetsModule
              fixedAssets={db.fixedAssets}
              currentBranch={currentBranch}
              company={db.company}
              currencySymbol={currentCurrency.symbol}
              canPostEntries={currentUser.canPostEntries}
              savedColumnPrefs={savedColPrefsMap['fixed-assets']}
              onSaveColumnPrefs={handleSaveColumnPrefs}
              onSaveAsset={(asset: FixedAsset) =>
                setDb({ ...db, fixedAssets: [asset, ...db.fixedAssets] })
              }
              onRunDepreciation={handleRunDepreciation}
              onNotify={notify}
            />
          )}

          {activeModule === 'reports' && (
            <ReportsHubModule
              db={db}
              currencySymbol={currentCurrency.symbol}
              onOpenPrintModal={setPrintableDoc}
              savedColumnPrefs={savedColPrefsMap}
              onSaveColumnPrefs={handleSaveColumnPrefs}
              onNavigateToRecord={navigateToRecord}
              onNotify={notify}
            />
          )}

          {activeModule === 'tasks' && (
            <TasksAlertsModule
              taskAlerts={db.taskAlerts}
              customers={db.customers}
              vendors={db.vendors}
              currencySymbol={currentCurrency.symbol}
              companyName={db.company.nameAr}
              whatsappTemplates={db.settings.whatsappTemplates}
              onAddTask={(task: TaskAlert) =>
                setDb({ ...db, taskAlerts: [task, ...db.taskAlerts] })
              }
              onToggleTaskComplete={(taskId) =>
                setDb({
                  ...db,
                  taskAlerts: db.taskAlerts.map((t) =>
                    t.id === taskId ? { ...t, isCompleted: !t.isCompleted } : t
                  ),
                })
              }
              onNavigateToRecord={navigateToRecord}
              onNotify={notify}
            />
          )}

          {activeModule === 'settings' && (
            <SettingsModule
              db={db}
              currentUser={currentUser}
              onUpdateCompany={(c) => setDb({ ...db, company: c })}
              onUpdateSettings={(s) => setDb({ ...db, settings: s })}
              onSaveBranch={(b: Branch) =>
                setDb({
                  ...db,
                  branches: db.branches.some((x) => x.id === b.id)
                    ? db.branches.map((x) => (x.id === b.id ? b : x))
                    : [...db.branches, b],
                })
              }
              onSaveWarehouse={(w: Warehouse) =>
                setDb({
                  ...db,
                  warehouses: db.warehouses.some((x) => x.id === w.id)
                    ? db.warehouses.map((x) => (x.id === w.id ? w : x))
                    : [...db.warehouses, w],
                })
              }
              onSaveUnitOfMeasure={(u: UnitOfMeasure) => {
                const list = db.unitsOfMeasure || [];
                setDb({
                  ...db,
                  unitsOfMeasure: list.some((x) => x.id === u.id)
                    ? list.map((x) => (x.id === u.id ? u : x))
                    : [...list, u],
                });
              }}
              onUpdateCurrencies={(currencies) => {
                setDb({ ...db, currencies });
                const updatedCurr = currencies.find((c) => c.code === currentCurrency.code);
                if (updatedCurr) setCurrentCurrency(updatedCurr);
              }}
              onUpdateUserPermissions={(u) => {
                const updatedUsers = db.users.map((usr) => (usr.id === u.id ? u : usr));
                setDb({ ...db, users: updatedUsers });
                if (currentUser.id === u.id) setCurrentUser(u);
              }}
              onResetDatabase={executeResetDatabase}
              onRestoreDatabase={(restored) => {
                setDb(restored);
                if (restored.branches[0]) setCurrentBranch(restored.branches[0]);
                const baseCurr = restored.currencies.find((c) => c.isBase) || restored.currencies[0];
                if (baseCurr) setCurrentCurrency(baseCurr);
                if (restored.users[0]) setCurrentUser(restored.users[0]);
              }}
              onNotify={notify}
            />
          )}
        </main>
      </div>

      {/* Contextual Operational & Accounting Help Modal */}
      <HelpModal
        isOpen={isHelpOpen}
        onClose={() => setIsHelpOpen(false)}
        topic={helpTopics[activeModule]}
      />

      {/* Printable Document Modal (A4 Official Output) */}
      {printableDoc && (
        <PrintModal
          isOpen={Boolean(printableDoc)}
          onClose={() => setPrintableDoc(null)}
          document={printableDoc}
          company={db.company}
          branch={currentBranch}
        />
      )}

      {/* Global Reset Confirm Modal */}
      <ConfirmModal
        isOpen={isResetConfirmOpen}
        title="إعادة ضبط قاعدة البيانات التجريبية"
        variant="danger"
        message="هل أنت متأكد من رغبتك في إعادة ضبط النظام إلى البيانات التجريبية الأولية؟ سيتم مسح أي فواتير أو قيود أو حركات جديدة غير محفوظة في نسخة احتياطية."
        confirmLabel="تأكيد إعادة الضبط"
        onConfirm={executeResetDatabase}
        onCancel={() => setIsResetConfirmOpen(false)}
      />

      {/* Global Non-blocking Toast Banner */}
      <ToastBanner
        toasts={toasts}
        onDismiss={(id) => setToasts((prev) => prev.filter((t) => t.id !== id))}
      />
    </div>
  );
}
