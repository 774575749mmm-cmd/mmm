/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * ALMANSOOR SMART FINANCE ERP - Professional Printable Document Template
 */

import React, { useState } from 'react';
import { Printer, X, ShieldCheck, Bluetooth, CheckCircle2, AlertTriangle } from 'lucide-react';
import { Company, Branch } from '../../types/erp';

export interface PrintableDocumentData {
  title: string;
  documentNumber: string;
  date: string;
  dueDate?: string;
  entityName: string;
  entityPhone?: string;
  entityAddress?: string;
  entityTaxNumber?: string;
  statement?: string;
  currencySymbol: string;
  previousBalance?: number;
  newBalance?: number;
  items?: {
    index: number;
    description: string;
    unit: string;
    quantity: number;
    bonusQuantity?: number;
    unitPrice: number;
    discount?: number;
    tax?: number;
    total: number;
    notes?: string;
  }[];
  totals: {
    subtotal: number;
    discountTotal: number;
    taxTotal: number;
    grandTotal: number;
    paidAmount?: number;
    remainingAmount?: number;
  };
  notes?: string;
  amountInWords?: string;
}

interface PrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  document: PrintableDocumentData;
  company: Company;
  branch: Branch;
}

export const PrintModal: React.FC<PrintModalProps> = ({
  isOpen,
  onClose,
  document: doc,
  company,
  branch,
}) => {
  const [btStatus, setBtStatus] = useState<{ type: 'idle' | 'ok' | 'err'; msg: string }>({
    type: 'idle',
    msg: '',
  });
  const [isPrintingBt, setIsPrintingBt] = useState(false);

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleBluetoothPrint = async () => {
    setBtStatus({ type: 'idle', msg: '' });
    const nav = navigator as any;
    if (!nav.bluetooth) {
      setBtStatus({
        type: 'err',
        msg: 'متصفحك الحالي لا يدعم Web Bluetooth. استخدم Chrome أو Edge على Android/Windows أو اطبع عبر الزر الرسمي (Ctrl+P).',
      });
      return;
    }

    setIsPrintingBt(true);
    try {
      const device = await nav.bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: [
          '000018f0-0000-1000-8000-00805f9b34fb',
          '0000ff00-0000-1000-8000-00805f9b34fb',
          '49535343-fe7d-4ae5-8fa9-9fafd205e455',
        ],
      });

      const server = await device.gatt?.connect();
      if (!server) throw new Error('تعذر الاتصال بخدمة GATT للطابعة');

      const services = await server.getPrimaryServices();
      let writableChar: any = null;
      for (const svc of services) {
        const chars = await svc.getCharacteristics();
        for (const ch of chars) {
          if (ch.properties?.write || ch.properties?.writeWithoutResponse) {
            writableChar = ch;
            break;
          }
        }
        if (writableChar) break;
      }

      if (!writableChar) {
        throw new Error('لم يتم العثور على قناة كتابة ESC/POS متوافقة في الطابعة المختارة');
      }

      const sep = '--------------------------------';
      const lines: string[] = [
        company.nameAr,
        doc.title,
        sep,
        `Doc#: ${doc.documentNumber}`,
        `Date: ${doc.date}`,
        `Party: ${doc.entityName}`,
        sep,
      ];

      if (doc.items && doc.items.length > 0) {
        doc.items.forEach((it) => {
          const bonusStr = it.bonusQuantity ? ` (+${it.bonusQuantity})` : '';
          lines.push(`${it.index}. ${it.description}`);
          lines.push(
            `   ${it.quantity}${bonusStr} x ${it.unitPrice.toLocaleString()} = ${it.total.toLocaleString()} ${doc.currencySymbol}`
          );
        });
        lines.push(sep);
      }

      lines.push(`Total: ${doc.totals.grandTotal.toLocaleString()} ${doc.currencySymbol}`);
      if (doc.totals.paidAmount !== undefined) {
        lines.push(`Paid:  ${doc.totals.paidAmount.toLocaleString()} ${doc.currencySymbol}`);
      }
      if (doc.totals.remainingAmount !== undefined) {
        lines.push(`Rem:   ${doc.totals.remainingAmount.toLocaleString()} ${doc.currencySymbol}`);
      }
      if (doc.previousBalance !== undefined) {
        lines.push(`Prev Bal: ${doc.previousBalance.toLocaleString()} ${doc.currencySymbol}`);
      }
      if (doc.newBalance !== undefined) {
        lines.push(`New Bal:  ${doc.newBalance.toLocaleString()} ${doc.currencySymbol}`);
      }
      lines.push(sep);
      lines.push('Thank you / شكراً لتعاملكم');
      lines.push('\n\n\n');

      const payloadText = lines.join('\n');
      const encoder = new TextEncoder();
      const textBytes = encoder.encode(payloadText);
      const initCmd = new Uint8Array([0x1b, 0x40]); // ESC @ Initialize printer
      const cutCmd = new Uint8Array([0x1d, 0x56, 0x42, 0x00]); // GS V B Cut

      const fullBytes = new Uint8Array(initCmd.length + textBytes.length + cutCmd.length);
      fullBytes.set(initCmd, 0);
      fullBytes.set(textBytes, initCmd.length);
      fullBytes.set(cutCmd, initCmd.length + textBytes.length);

      // Chunk writes (BLE MTU safe 100 bytes)
      for (let i = 0; i < fullBytes.length; i += 100) {
        const chunk = fullBytes.slice(i, i + 100);
        if (writableChar.properties.writeWithoutResponse) {
          await writableChar.writeValueWithoutResponse(chunk);
        } else {
          await writableChar.writeValue(chunk);
        }
      }

      setBtStatus({
        type: 'ok',
        msg: `تم إرسال الإيصال بنجاح إلى الطابعة الحرارية (${device.name || 'Bluetooth Printer'}).`,
      });
    } catch (err: any) {
      if (err?.name === 'NotFoundError') {
        setBtStatus({ type: 'err', msg: 'تم إلغاء اختيار طابعة البلوتوث.' });
      } else {
        setBtStatus({
          type: 'err',
          msg: err?.message || 'تعذر الاتصال بالطابعة الحرارية عبر البلوتوث.',
        });
      }
    } finally {
      setIsPrintingBt(false);
    }
  };

  const hasBonusCol = Boolean(doc.items?.some((i) => (i.bonusQuantity || 0) > 0));
  const hasDiscountCol = Boolean(doc.items?.some((i) => (i.discount || 0) > 0));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm no-print">
      <div className="bg-white text-slate-900 rounded-2xl w-full max-w-4xl max-h-[92vh] overflow-y-auto shadow-2xl flex flex-col">
        {/* Modal Controls Toolbar (Hidden during print) */}
        <div className="flex flex-wrap items-center justify-between gap-2 p-4 bg-slate-900 text-slate-100 rounded-t-2xl no-print">
          <div className="flex items-center gap-2">
            <Printer className="w-5 h-5 text-amber-400" />
            <span className="font-bold text-sm">معاينة الطباعة الرسمية - {doc.title}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleBluetoothPrint}
              disabled={isPrintingBt}
              className="flex items-center gap-1.5 px-3 py-2 bg-sky-600 hover:bg-sky-500 disabled:opacity-60 text-white font-bold text-xs rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              <Bluetooth className="w-4 h-4" />
              <span>{isPrintingBt ? 'جاري الاتصال...' : 'طباعة حرارية بلوتوث'}</span>
            </button>
            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              طباعة A4 / حفظ PDF (Ctrl+P)
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Bluetooth Status Banner (Hidden during print) */}
        {btStatus.type !== 'idle' && (
          <div
            className={`px-4 py-2.5 text-xs flex items-center justify-between no-print ${
              btStatus.type === 'ok'
                ? 'bg-emerald-50 text-emerald-800 border-b border-emerald-200'
                : 'bg-rose-50 text-rose-800 border-b border-rose-200'
            }`}
          >
            <div className="flex items-center gap-2 font-semibold">
              {btStatus.type === 'ok' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              )}
              <span>{btStatus.msg}</span>
            </div>
            <button
              type="button"
              onClick={() => setBtStatus({ type: 'idle', msg: '' })}
              className="text-slate-500 hover:text-slate-800 font-bold cursor-pointer"
            >
              إغلاق
            </button>
          </div>
        )}

        {/* Printable Document Sheet (A4 Layout) */}
        <div className="p-8 md:p-12 space-y-6 printable-document bg-white">
          {/* Optional Full Header Banner Image (Uploaded in Settings) */}
          {company.logoUrl && (
            <div className="mb-3 border border-slate-200 rounded-xl overflow-hidden bg-white">
              <img
                src={company.logoUrl}
                alt={company.nameAr}
                className="w-full max-h-36 object-contain mx-auto"
              />
            </div>
          )}

          {/* Header */}
          <div className="border-b-2 border-slate-900 pb-6 flex items-start justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                {!company.logoUrl && (
                  <div className="w-8 h-8 rounded-lg bg-slate-900 text-amber-400 font-black flex items-center justify-center text-sm">
                    {company.nameAr?.trim().charAt(0) || 'م'}
                  </div>
                )}
                <h1 className="text-xl font-black tracking-tight text-slate-900">{company.nameAr}</h1>
              </div>
              <p className="text-xs font-semibold text-slate-600">{company.nameEn}</p>
              <div className="text-xs text-slate-500 space-y-0.5 pt-1">
                <p>س.ت: <span className="font-mono">{company.commercialRecord}</span> · ر.ض: <span className="font-mono">{company.taxNumber}</span></p>
                <p>الفرع: {branch.nameAr} - هاتف: <span className="font-mono">{company.phone}</span></p>
              </div>
            </div>

            {/* Document Title Badge */}
            <div className="text-left flex flex-col items-end">
              <div className="px-4 py-1.5 bg-slate-900 text-amber-400 font-bold text-base rounded-md tracking-wider mb-2">
                {doc.title}
              </div>
              <div className="text-xs text-slate-600 space-y-1">
                <p>رقم المستند: <strong className="font-mono text-slate-900 text-sm">{doc.documentNumber}</strong></p>
                <p>التاريخ: <span className="font-mono">{doc.date}</span></p>
                {doc.dueDate && <p>تاريخ الاستحقاق: <span className="font-mono">{doc.dueDate}</span></p>}
              </div>
            </div>
          </div>

          {/* Entity Information */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 grid grid-cols-2 md:grid-cols-3 gap-4 text-xs">
            <div>
              <span className="text-slate-500 block mb-0.5 font-medium">الطرف المعني:</span>
              <strong className="text-slate-900 text-sm block">{doc.entityName}</strong>
              {doc.entityTaxNumber && <span className="text-slate-600 font-mono">الرقم الضريبي: {doc.entityTaxNumber}</span>}
            </div>
            <div>
              <span className="text-slate-500 block mb-0.5 font-medium">بيانات الاتصال والعنوان:</span>
              <span className="text-slate-800 block">{doc.entityPhone ? `هاتف: ${doc.entityPhone}` : 'غير محدد'}</span>
              <span className="text-slate-600 block">{doc.entityAddress || ''}</span>
            </div>
            {doc.statement && (
              <div className="col-span-2 md:col-span-1">
                <span className="text-slate-500 block mb-0.5 font-medium">البيان / الغرض:</span>
                <span className="text-slate-800">{doc.statement}</span>
              </div>
            )}
          </div>

          {/* Items Table (if present) */}
          {doc.items && doc.items.length > 0 && (
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3 w-10 text-center">#</th>
                    <th className="py-2.5 px-3">الصنف / الوصف</th>
                    <th className="py-2.5 px-3 text-center">الوحدة</th>
                    <th className="py-2.5 px-3 text-center">الكمية</th>
                    {hasBonusCol && <th className="py-2.5 px-3 text-center">بونص</th>}
                    <th className="py-2.5 px-3 text-left">السعر الفردي</th>
                    {hasDiscountCol && <th className="py-2.5 px-3 text-left">الخصم</th>}
                    <th className="py-2.5 px-3 text-left">الإجمالي ({doc.currencySymbol})</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {doc.items.map((item, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50">
                      <td className="py-2.5 px-3 text-center font-mono text-slate-400">{item.index}</td>
                      <td className="py-2.5 px-3 font-semibold text-slate-800">
                        <div>{item.description}</div>
                        {item.notes && (
                          <div className="text-[10px] text-slate-500 font-normal">{item.notes}</div>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-center text-slate-600">{item.unit}</td>
                      <td className="py-2.5 px-3 text-center font-mono font-bold">{item.quantity}</td>
                      {hasBonusCol && (
                        <td className="py-2.5 px-3 text-center font-mono font-semibold text-emerald-700">
                          {item.bonusQuantity ? `+${item.bonusQuantity}` : '-'}
                        </td>
                      )}
                      <td className="py-2.5 px-3 text-left font-mono">{item.unitPrice.toLocaleString()}</td>
                      {hasDiscountCol && (
                        <td className="py-2.5 px-3 text-left font-mono text-rose-600">
                          {item.discount ? item.discount.toLocaleString() : '-'}
                        </td>
                      )}
                      <td className="py-2.5 px-3 text-left font-mono font-bold text-slate-900">
                        {item.total.toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Totals Section */}
          <div className="flex flex-col md:flex-row justify-between items-start gap-6 pt-2">
            {/* Notes & Amount in words */}
            <div className="w-full md:w-1/2 space-y-3 text-xs">
              {doc.notes && (
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="font-bold text-slate-700 block mb-1">ملاحظات وشروط:</span>
                  <p className="text-slate-600 leading-relaxed">{doc.notes}</p>
                </div>
              )}
              <div className="p-3 bg-amber-50/60 rounded-lg border border-amber-200/80 text-amber-900">
                <span className="font-bold block mb-1">المبلغ الإجمالي كتابةً:</span>
                <p className="font-semibold">{doc.amountInWords || `${doc.totals.grandTotal.toLocaleString()} ${doc.currencySymbol} فقط لا غير.`}</p>
              </div>
            </div>

            {/* Calculations Box */}
            <div className="w-full md:w-80 space-y-2 text-xs border border-slate-200 rounded-xl p-4 bg-slate-50">
              <div className="flex justify-between text-slate-600">
                <span>المجموع الفرعي:</span>
                <span className="font-mono font-semibold">{doc.totals.subtotal.toLocaleString()} {doc.currencySymbol}</span>
              </div>
              {doc.totals.discountTotal > 0 && (
                <div className="flex justify-between text-rose-600">
                  <span>إجمالي الخصم:</span>
                  <span className="font-mono font-semibold">-{doc.totals.discountTotal.toLocaleString()} {doc.currencySymbol}</span>
                </div>
              )}
              {doc.totals.taxTotal > 0 && (
                <div className="flex justify-between text-slate-600">
                  <span>ضريبة القيمة المضافة:</span>
                  <span className="font-mono font-semibold">+{doc.totals.taxTotal.toLocaleString()} {doc.currencySymbol}</span>
                </div>
              )}
              <div className="border-t border-slate-300 pt-2 flex justify-between text-sm font-black text-slate-900">
                <span>المبلغ الإجمالي المستحق:</span>
                <span className="font-mono text-base text-slate-900">{doc.totals.grandTotal.toLocaleString()} {doc.currencySymbol}</span>
              </div>
              {doc.totals.paidAmount !== undefined && (
                <div className="border-t border-slate-200 pt-2 space-y-1">
                  <div className="flex justify-between text-emerald-700">
                    <span>المبلغ المسدد:</span>
                    <span className="font-mono font-semibold">{doc.totals.paidAmount.toLocaleString()} {doc.currencySymbol}</span>
                  </div>
                  <div className="flex justify-between text-rose-700 font-bold">
                    <span>المتبقي:</span>
                    <span className="font-mono font-semibold">{(doc.totals.remainingAmount || 0).toLocaleString()} {doc.currencySymbol}</span>
                  </div>
                </div>
              )}

              {/* Previous & New Customer/Vendor Account Balance */}
              {(doc.previousBalance !== undefined || doc.newBalance !== undefined) && (
                <div className="border-t border-slate-300 pt-2 mt-2 space-y-1 bg-white p-2.5 rounded-lg border border-slate-200">
                  {doc.previousBalance !== undefined && (
                    <div className="flex justify-between text-slate-600">
                      <span>الرصيد السابق للحساب:</span>
                      <span className="font-mono font-bold">{doc.previousBalance.toLocaleString()} {doc.currencySymbol}</span>
                    </div>
                  )}
                  {doc.newBalance !== undefined && (
                    <div className="flex justify-between text-slate-900 font-black">
                      <span>الرصيد الحالي بعد الفاتورة:</span>
                      <span className="font-mono text-indigo-700">{doc.newBalance.toLocaleString()} {doc.currencySymbol}</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Signatures & Stamps Footer */}
          <div className="border-t-2 border-slate-200 pt-8 mt-12 grid grid-cols-4 gap-4 text-center text-xs text-slate-600">
            <div>
              <p className="font-bold mb-8 text-slate-800">إعداد / المستخدم</p>
              <div className="border-t border-dashed border-slate-400 pt-1">التوقيع والتاريخ</div>
            </div>
            <div>
              <p className="font-bold mb-8 text-slate-800">المحاسب المسؤول</p>
              <div className="border-t border-dashed border-slate-400 pt-1">التوقيع والتاريخ</div>
            </div>
            <div>
              <p className="font-bold mb-8 text-slate-800">اعتماد الإدارة المالية</p>
              <div className="border-t border-dashed border-slate-400 pt-1">التوقيع والختم</div>
            </div>
            <div>
              <p className="font-bold mb-8 text-slate-800">المستلم / العميل</p>
              <div className="border-t border-dashed border-slate-400 pt-1">الاسم والتوقيع</div>
            </div>
          </div>

          {/* Security & Verification Marker */}
          <div className="text-center text-[10px] text-slate-400 pt-4 flex items-center justify-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>مستند محاسبي رسمي صادر آلياً من نظام المنصور للأنظمة المالية والإدارية الذكية ERP · مشفر ومحمي برقم القيد</span>
          </div>
        </div>
      </div>
    </div>
  );
};
