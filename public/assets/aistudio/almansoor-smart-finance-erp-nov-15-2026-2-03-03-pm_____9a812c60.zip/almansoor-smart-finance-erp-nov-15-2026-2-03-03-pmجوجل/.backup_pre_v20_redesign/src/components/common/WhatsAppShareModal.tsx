/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * ALMANSOOR SMART FINANCE ERP - Unified WhatsApp Share & Templates Modal
 */

import React, { useState, useEffect } from 'react';
import { X, MessageCircle, Copy, Check, ExternalLink, AlertCircle } from 'lucide-react';
import { WhatsAppTemplates } from '../../types/erp';
import {
  buildWhatsAppLink,
  renderWhatsAppTemplate,
  validateWhatsAppPhone,
} from '../../services/exportService';

export type WhatsAppTemplateKey = keyof WhatsAppTemplates;

interface WhatsAppShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  recipientName?: string;
  defaultPhone?: string;
  defaultTemplateKey?: WhatsAppTemplateKey;
  templates?: WhatsAppTemplates;
  templateVars?: Record<string, string | number | undefined>;
  defaultMessage?: string;
  onDispatched?: (details: { phone: string; message: string; channel: 'whatsapp' }) => void;
}

const TEMPLATE_LABELS: Record<WhatsAppTemplateKey, string> = {
  invoice: 'قالب فاتورة مبيعات / مشتريات',
  voucher: 'قالب سند قبض / صرف',
  statement: 'قالب كشف حساب عميل / مورد',
  overdueReminder: 'قالب تذكير مديونية متأخرة',
  paymentConfirmation: 'قالب تأكيد استلام دفعة',
  dailySummary: 'قالب ملخص الإدارة اليومي',
};

export const WhatsAppShareModal: React.FC<WhatsAppShareModalProps> = ({
  isOpen,
  onClose,
  title = 'مشاركة عبر واتساب',
  recipientName,
  defaultPhone = '',
  defaultTemplateKey = 'invoice',
  templates,
  templateVars = {},
  defaultMessage,
  onDispatched,
}) => {
  const [phone, setPhone] = useState(defaultPhone);
  const [selectedTemplate, setSelectedTemplate] = useState<WhatsAppTemplateKey>(defaultTemplateKey);
  const [message, setMessage] = useState(defaultMessage || '');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    setPhone(defaultPhone || '');
    setSelectedTemplate(defaultTemplateKey);
    if (defaultMessage) {
      setMessage(defaultMessage);
    } else if (templates && templates[defaultTemplateKey]) {
      setMessage(renderWhatsAppTemplate(templates[defaultTemplateKey], templateVars));
    }
    setCopied(false);
  }, [isOpen, defaultPhone, defaultTemplateKey, defaultMessage]);

  if (!isOpen) return null;

  const phoneCheck = validateWhatsAppPhone(phone);
  const waLink = phoneCheck.valid && message.trim() ? buildWhatsAppLink(phoneCheck.normalized, message) : '';

  const applyTemplate = (key: WhatsAppTemplateKey) => {
    setSelectedTemplate(key);
    if (templates && templates[key]) {
      setMessage(renderWhatsAppTemplate(templates[key], templateVars));
    }
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback ignored
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-4" dir="rtl">
      <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-lg overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-emerald-500/15 text-emerald-400">
              <MessageCircle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">{title}</h3>
              {recipientName && <p className="text-xs text-slate-400">المستلم: {recipientName}</p>}
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">رقم واتساب المستلم (بصيغة دولية)</label>
            <input
              type="text"
              dir="ltr"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="967770001111"
              className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100 text-sm font-mono focus:border-emerald-500 focus:outline-none"
            />
            {phone && !phoneCheck.valid ? (
              <p className="mt-1.5 text-xs text-rose-400 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{phoneCheck.error}</span>
              </p>
            ) : phoneCheck.valid ? (
              <p className="mt-1 text-[11px] text-emerald-400 font-mono">
                الرقم المعتمد للإرسال: +{phoneCheck.normalized}
              </p>
            ) : null}
          </div>

          {templates && (
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">اختيار قالب رسالة جاهز</label>
              <select
                value={selectedTemplate}
                onChange={(e) => applyTemplate(e.target.value as WhatsAppTemplateKey)}
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100 text-xs focus:border-amber-500 focus:outline-none"
              >
                {(Object.keys(TEMPLATE_LABELS) as WhatsAppTemplateKey[]).map((key) => (
                  <option key={key} value={key}>
                    {TEMPLATE_LABELS[key]}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">نص الرسالة القابل للتعديل</label>
            <textarea
              rows={6}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-lg bg-slate-950 border border-slate-700 text-slate-100 text-xs sm:text-sm leading-relaxed focus:border-emerald-500 focus:outline-none"
            />
          </div>

          <div className="text-[11px] text-slate-400 bg-slate-950/80 border border-slate-800 rounded-lg px-3 py-2">
            ملاحظة: يفتح النظام رابط محادثة واتساب مباشرة عبر المتصفح أو تطبيق واتساب على جهازك بالرسالة الجاهزة للإرسال الفوري.
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 px-5 py-3.5 border-t border-slate-800 bg-slate-950/60">
          <button
            type="button"
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'تم النسخ' : 'نسخ النص'}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 rounded-lg text-xs font-semibold text-slate-300 hover:bg-slate-800"
            >
              إغلاق
            </button>
            {waLink ? (
              <a
                href={waLink}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => {
                  onDispatched?.({ phone: phoneCheck.normalized, message, channel: 'whatsapp' });
                }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>فتح واتساب للإرسال</span>
              </a>
            ) : (
              <button
                type="button"
                disabled
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold bg-emerald-600/30 text-slate-400 cursor-not-allowed"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>أدخل رقماً ونصاً صالحاً</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
