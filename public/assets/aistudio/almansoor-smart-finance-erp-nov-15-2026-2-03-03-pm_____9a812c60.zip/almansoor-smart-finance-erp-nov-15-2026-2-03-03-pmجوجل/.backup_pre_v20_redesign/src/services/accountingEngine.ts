/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * ALMANSOOR SMART FINANCE ERP - Double-Entry Accounting Engine
 */

import {
  Account,
  JournalEntry,
  JournalEntryLine,
  Invoice,
  PaymentVoucher,
  ExpenseRecord,
  PayrollRun,
  FixedAsset,
  Customer,
  Vendor,
  PhysicalStocktaking,
} from '../types/erp';
import { generateNextDocNumber } from './storageService';

export interface DateRangeFilter {
  startDate?: string;
  endDate?: string;
}

export interface CashFlowStatementResult {
  operatingInflows: { label: string; amount: number }[];
  operatingOutflows: { label: string; amount: number }[];
  netOperatingCashFlow: number;
  investingCashFlow: number;
  financingCashFlow: number;
  netCashChange: number;
  openingCashBalance: number;
  closingCashBalance: number;
}

export interface TrialBalanceRow {
  accountId: string;
  accountCode: string;
  accountName: string;
  category: string;
  openingDebit: number;
  openingCredit: number;
  periodDebit: number;
  periodCredit: number;
  endingDebit: number;
  endingCredit: number;
}

export interface IncomeStatementResult {
  revenues: { accountCode: string; accountName: string; amount: number }[];
  totalRevenue: number;
  cogs: { accountCode: string; accountName: string; amount: number }[];
  totalCogs: number;
  grossProfit: number;
  expenses: { accountCode: string; accountName: string; amount: number }[];
  totalExpenses: number;
  netIncome: number;
}

export interface BalanceSheetResult {
  assets: { accountCode: string; accountName: string; balance: number }[];
  totalAssets: number;
  liabilities: { accountCode: string; accountName: string; balance: number }[];
  totalLiabilities: number;
  equity: { accountCode: string; accountName: string; balance: number }[];
  totalEquity: number;
  netProfitCarried: number;
  totalLiabilitiesAndEquity: number;
  isBalanced: boolean;
  variance: number;
}

export interface StatementRow {
  date: string;
  documentType: string;
  documentNumber: string;
  statement: string;
  debit: number;
  credit: number;
  balance: number;
}

/**
 * Validates that debit and credit amounts strictly match
 */
export function validateJournalEntry(lines: JournalEntryLine[]): { isValid: boolean; error?: string; totalDebit: number; totalCredit: number } {
  const totalDebit = lines.reduce((sum, l) => sum + (Number(l.debit) || 0), 0);
  const totalCredit = lines.reduce((sum, l) => sum + (Number(l.credit) || 0), 0);
  
  const diff = Math.abs(totalDebit - totalCredit);
  if (diff > 0.01) {
    return {
      isValid: false,
      error: `القيد المحاسبي غير متوازن! إجمالي المدين (${totalDebit.toLocaleString()}) لا يساوي إجمالي الدائن (${totalCredit.toLocaleString()}). الفارق: ${diff.toLocaleString()}`,
      totalDebit,
      totalCredit,
    };
  }

  if (lines.length < 2) {
    return {
      isValid: false,
      error: 'يجب أن يحتوي القيد المحاسبي على طرفين على الأقل (مدين ودائن).',
      totalDebit,
      totalCredit,
    };
  }

  return { isValid: true, totalDebit, totalCredit };
}

function resolveAccount(
  accounts: Account[],
  preferredCodes: string[],
  category: Account['category'],
  keywords: string[] = []
): Account {
  for (const code of preferredCodes) {
    const exact = accounts.find((a) => a.code === code && a.isLeaf) || accounts.find((a) => a.code === code);
    if (exact) return exact;
  }
  const leaves = accounts.filter((a) => a.isLeaf);
  for (const kw of keywords) {
    const byKw = leaves.find((a) => a.nameAr.includes(kw));
    if (byKw) return byKw;
  }
  const byCat = leaves.find((a) => a.category === category);
  if (byCat) return byCat;
  return (
    leaves[0] ||
    accounts[0] || {
      id: 'acc-fallback',
      code: '0',
      nameAr: 'حساب افتراضي',
      category,
      nature: category === 'أصول' || category === 'مصروفات' ? 'debit' : 'credit',
      level: 1,
      isLeaf: true,
      currentBalance: 0,
    }
  );
}

/**
 * Creates automated balanced Journal Entry for a Sales Invoice
 */
export function createSalesInvoiceJournalEntry(
  invoice: Invoice,
  accounts: Account[],
  userFullName: string,
  existingEntryNumbers: string[] = []
): JournalEntry {
  const lines: JournalEntryLine[] = [];

  // Account references (supports both Almansoor demo COA and Qright COA)
  const accCash =
    accounts.find((a) => a.id === invoice.treasuryAccountId) ||
    resolveAccount(accounts, ['1111', '131'], 'أصول', ['الصندوق']);
  const accReceivable = resolveAccount(accounts, ['114', '121001', '121'], 'أصول', ['الزبائن', 'العملاء']);
  const accSalesRevenue = resolveAccount(accounts, ['4110', '41'], 'إيرادات', ['المبيعات']);
  const accVat = resolveAccount(accounts, ['2120', '801', '802'], 'خصوم', ['ضريبة']);
  const accCogs = accounts.find((a) => a.code === '5110' || a.code === '31');
  const accInventory = accounts.find((a) => a.code === '115' || a.code === '124');

  const grandTotal = invoice.grandTotal;
  const netSales = invoice.subtotal - invoice.discountTotal;
  const vatAmount = invoice.taxTotal;

  // 1. Debit: Cash or Customer Receivable
  if (invoice.paymentType === 'نقدي') {
    lines.push({
      id: `jl-${Date.now()}-1`,
      accountId: accCash.id,
      accountCode: accCash.code,
      accountName: accCash.nameAr,
      debit: grandTotal,
      credit: 0,
      currency: invoice.currency,
      exchangeRate: invoice.exchangeRate,
      memo: `سداد نقدي لفاتورة مبيعات رقم ${invoice.invoiceNumber}`,
    });
  } else if (invoice.paymentType === 'آجل') {
    lines.push({
      id: `jl-${Date.now()}-1`,
      accountId: accReceivable.id,
      accountCode: accReceivable.code,
      accountName: `${accReceivable.nameAr} - ${invoice.entityName}`,
      debit: grandTotal,
      credit: 0,
      currency: invoice.currency,
      exchangeRate: invoice.exchangeRate,
      memo: `استحقاق فاتورة مبيعات آجلة رقم ${invoice.invoiceNumber} - العميل: ${invoice.entityName}`,
    });
  } else {
    // الجزئي
    if (invoice.paidAmount > 0) {
      lines.push({
        id: `jl-${Date.now()}-1`,
        accountId: accCash.id,
        accountCode: accCash.code,
        accountName: accCash.nameAr,
        debit: invoice.paidAmount,
        credit: 0,
        currency: invoice.currency,
        exchangeRate: invoice.exchangeRate,
        memo: `دفعة نقدية لفاتورة مبيعات رقم ${invoice.invoiceNumber}`,
      });
    }
    if (invoice.remainingAmount > 0) {
      lines.push({
        id: `jl-${Date.now()}-2`,
        accountId: accReceivable.id,
        accountCode: accReceivable.code,
        accountName: `${accReceivable.nameAr} - ${invoice.entityName}`,
        debit: invoice.remainingAmount,
        credit: 0,
        currency: invoice.currency,
        exchangeRate: invoice.exchangeRate,
        memo: `المتبقي الآجل لفاتورة مبيعات رقم ${invoice.invoiceNumber}`,
      });
    }
  }

  // 2. Credit: Sales Revenue
  lines.push({
    id: `jl-${Date.now()}-3`,
    accountId: accSalesRevenue.id,
    accountCode: accSalesRevenue.code,
    accountName: accSalesRevenue.nameAr,
    debit: 0,
    credit: netSales,
    currency: invoice.currency,
    exchangeRate: invoice.exchangeRate,
    memo: `إيراد مبيعات فاتورة ${invoice.invoiceNumber}`,
  });

  // 3. Credit: Tax (if applicable)
  if (vatAmount > 0 && accVat) {
    lines.push({
      id: `jl-${Date.now()}-4`,
      accountId: accVat.id,
      accountCode: accVat.code,
      accountName: accVat.nameAr,
      debit: 0,
      credit: vatAmount,
      currency: invoice.currency,
      exchangeRate: invoice.exchangeRate,
      memo: `ضريبة القيمة المضافة المستحقة لفاتورة ${invoice.invoiceNumber}`,
    });
  }

  // 4. Inventory & COGS side (Cost of goods sold including free bonus pieces)
  const totalCost = invoice.items.reduce(
    (sum, it) => sum + it.unitCost * (it.quantity + (it.bonusQuantity || 0)),
    0
  );
  if (totalCost > 0 && accCogs && accInventory) {
    lines.push({
      id: `jl-${Date.now()}-5`,
      accountId: accCogs.id,
      accountCode: accCogs.code,
      accountName: accCogs.nameAr,
      debit: totalCost,
      credit: 0,
      currency: invoice.currency,
      exchangeRate: invoice.exchangeRate,
      memo: `تكلفة البضاعة المباعة لفاتورة ${invoice.invoiceNumber}`,
    });

    lines.push({
      id: `jl-${Date.now()}-6`,
      accountId: accInventory.id,
      accountCode: accInventory.code,
      accountName: accInventory.nameAr,
      debit: 0,
      credit: totalCost,
      currency: invoice.currency,
      exchangeRate: invoice.exchangeRate,
      memo: `صرف مخزون بضاعة مباعة لفاتورة ${invoice.invoiceNumber}`,
    });
  }

  const totalDebit = lines.reduce((s, l) => s + l.debit, 0);
  const totalCredit = lines.reduce((s, l) => s + l.credit, 0);

  const prefix = `JV-${new Date().getFullYear()}-`;
  const entryNumber = generateNextDocNumber(prefix, existingEntryNumbers, 4);

  return {
    id: `je-auto-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    entryNumber,
    date: invoice.date,
    branchId: invoice.branchId,
    referenceType: 'فاتورة_مبيعات',
    referenceNumber: invoice.invoiceNumber,
    referenceId: invoice.id,
    description: `قيد آلي لفاتورة مبيعات ${invoice.invoiceNumber} - العميل: ${invoice.entityName}`,
    lines,
    totalDebit,
    totalCredit,
    status: 'posted',
    createdBy: userFullName,
    createdAt: new Date().toISOString(),
  };
}

/**
 * Creates automated balanced Journal Entry for a Purchase Invoice
 */
export function createPurchaseInvoiceJournalEntry(
  invoice: Invoice,
  accounts: Account[],
  userFullName: string,
  existingEntryNumbers: string[] = []
): JournalEntry {
  const lines: JournalEntryLine[] = [];

  const accCash =
    accounts.find((a) => a.id === invoice.treasuryAccountId) ||
    resolveAccount(accounts, ['1111', '131'], 'أصول', ['الصندوق']);
  const accPayable = resolveAccount(accounts, ['2110', '221001', '221'], 'خصوم', ['المورد']);
  const accInventory = resolveAccount(accounts, ['115', '124', '31'], 'أصول', ['المخزون', 'المشتريات']);

  // 1. Debit Inventory for the purchase net total
  lines.push({
    id: `jl-${Date.now()}-p1`,
    accountId: accInventory.id,
    accountCode: accInventory.code,
    accountName: accInventory.nameAr,
    debit: invoice.grandTotal,
    credit: 0,
    currency: invoice.currency,
    exchangeRate: invoice.exchangeRate,
    memo: `إضافة مخزون مشتريات بموجب فاتورة ${invoice.invoiceNumber}`,
  });

  // 2. Credit Vendor or Cash
  if (invoice.paymentType === 'نقدي') {
    lines.push({
      id: `jl-${Date.now()}-p2`,
      accountId: accCash.id,
      accountCode: accCash.code,
      accountName: accCash.nameAr,
      debit: 0,
      credit: invoice.grandTotal,
      currency: invoice.currency,
      exchangeRate: invoice.exchangeRate,
      memo: `سداد نقدي لفاتورة مشتريات ${invoice.invoiceNumber}`,
    });
  } else if (invoice.paymentType === 'آجل') {
    lines.push({
      id: `jl-${Date.now()}-p2`,
      accountId: accPayable.id,
      accountCode: accPayable.code,
      accountName: `${accPayable.nameAr} - ${invoice.entityName}`,
      debit: 0,
      credit: invoice.grandTotal,
      currency: invoice.currency,
      exchangeRate: invoice.exchangeRate,
      memo: `استحقاق فاتورة مشتريات آجلة ${invoice.invoiceNumber} - المورد: ${invoice.entityName}`,
    });
  } else {
    if (invoice.paidAmount > 0) {
      lines.push({
        id: `jl-${Date.now()}-p2`,
        accountId: accCash.id,
        accountCode: accCash.code,
        accountName: accCash.nameAr,
        debit: 0,
        credit: invoice.paidAmount,
        currency: invoice.currency,
        exchangeRate: invoice.exchangeRate,
        memo: `دفعة نقدية لفاتورة مشتريات ${invoice.invoiceNumber}`,
      });
    }
    if (invoice.remainingAmount > 0) {
      lines.push({
        id: `jl-${Date.now()}-p3`,
        accountId: accPayable.id,
        accountCode: accPayable.code,
        accountName: `${accPayable.nameAr} - ${invoice.entityName}`,
        debit: 0,
        credit: invoice.remainingAmount,
        currency: invoice.currency,
        exchangeRate: invoice.exchangeRate,
        memo: `المتبقي الآجل لفاتورة مشتريات ${invoice.invoiceNumber}`,
      });
    }
  }

  const totalDebit = lines.reduce((s, l) => s + l.debit, 0);
  const totalCredit = lines.reduce((s, l) => s + l.credit, 0);

  const prefix = `JV-${new Date().getFullYear()}-`;
  const entryNumber = generateNextDocNumber(prefix, existingEntryNumbers, 4);

  return {
    id: `je-auto-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    entryNumber,
    date: invoice.date,
    branchId: invoice.branchId,
    referenceType: 'فاتورة_مشتريات',
    referenceNumber: invoice.invoiceNumber,
    referenceId: invoice.id,
    description: `قيد آلي لفاتورة مشتريات ${invoice.invoiceNumber} - المورد: ${invoice.entityName}`,
    lines,
    totalDebit,
    totalCredit,
    status: 'posted',
    createdBy: userFullName,
    createdAt: new Date().toISOString(),
  };
}

/**
 * Creates automated balanced Journal Entry for a Receipt or Payment Voucher
 */
export function createVoucherJournalEntry(
  voucher: PaymentVoucher,
  accounts: Account[],
  userFullName: string,
  existingEntryNumbers: string[] = []
): JournalEntry {
  const lines: JournalEntryLine[] = [];
  
  // Treasury account (Cash/Bank)
  const accTreasury =
    accounts.find((a) => a.id === voucher.treasuryAccountId) ||
    resolveAccount(accounts, ['1111', '131'], 'أصول', ['الصندوق']);

  // Entity account
  let accEntity: Account;
  if (voucher.entityType === 'عميل') {
    accEntity = resolveAccount(accounts, ['114', '121001', '121'], 'أصول', ['الزبائن', 'العملاء']);
  } else if (voucher.entityType === 'مورد') {
    accEntity = resolveAccount(accounts, ['2110', '221001', '221'], 'خصوم', ['المورد']);
  } else if (voucher.entityType === 'موظف') {
    accEntity = resolveAccount(accounts, ['2130', '5210', '516', '501'], 'مصروفات', ['رواتب', 'الموظفين']);
  } else {
    accEntity = resolveAccount(accounts, ['5340', '510', '4120', '601'], 'مصروفات', ['مصاريف متفرقة', 'إيرادات']);
  }

  const baseAmount = voucher.amount * voucher.exchangeRate;

  if (voucher.type === 'قبض') {
    // Receipt: Debit Treasury, Credit Customer / Entity
    lines.push({
      id: `jl-v-${Date.now()}-1`,
      accountId: accTreasury.id,
      accountCode: accTreasury.code,
      accountName: accTreasury.nameAr,
      debit: baseAmount,
      credit: 0,
      currency: voucher.currency,
      exchangeRate: voucher.exchangeRate,
      memo: `سند قبض رقم ${voucher.voucherNumber} - من: ${voucher.entityName}`,
    });
    lines.push({
      id: `jl-v-${Date.now()}-2`,
      accountId: accEntity.id,
      accountCode: accEntity.code,
      accountName: `${accEntity.nameAr} - ${voucher.entityName}`,
      debit: 0,
      credit: baseAmount,
      currency: voucher.currency,
      exchangeRate: voucher.exchangeRate,
      memo: voucher.statement || `تحصيل بموجب سند قبض رقم ${voucher.voucherNumber}`,
    });
  } else {
    // Disbursement: Debit Vendor / Entity, Credit Treasury
    lines.push({
      id: `jl-v-${Date.now()}-1`,
      accountId: accEntity.id,
      accountCode: accEntity.code,
      accountName: `${accEntity.nameAr} - ${voucher.entityName}`,
      debit: baseAmount,
      credit: 0,
      currency: voucher.currency,
      exchangeRate: voucher.exchangeRate,
      memo: voucher.statement || `صرف بموجب سند صرف رقم ${voucher.voucherNumber}`,
    });
    lines.push({
      id: `jl-v-${Date.now()}-2`,
      accountId: accTreasury.id,
      accountCode: accTreasury.code,
      accountName: accTreasury.nameAr,
      debit: 0,
      credit: baseAmount,
      currency: voucher.currency,
      exchangeRate: voucher.exchangeRate,
      memo: `سند صرف رقم ${voucher.voucherNumber} - إلى: ${voucher.entityName}`,
    });
  }

  const prefix = `JV-${new Date().getFullYear()}-`;
  const entryNumber = generateNextDocNumber(prefix, existingEntryNumbers, 4);

  return {
    id: `je-auto-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    entryNumber,
    date: voucher.date,
    branchId: voucher.branchId,
    referenceType: voucher.type === 'قبض' ? 'سند_قبض' : 'سند_صرف',
    referenceNumber: voucher.voucherNumber,
    referenceId: voucher.id,
    description: `قيد آلي لـ ${voucher.type === 'قبض' ? 'سند قبض' : 'سند صرف'} ${voucher.voucherNumber} (${voucher.statement})`,
    lines,
    totalDebit: baseAmount,
    totalCredit: baseAmount,
    status: 'posted',
    createdBy: userFullName,
    createdAt: new Date().toISOString(),
  };
}

/**
 * Creates automated balanced Journal Entry for an Expense Record
 */
export function createExpenseJournalEntry(
  expense: ExpenseRecord,
  accounts: Account[],
  userFullName: string,
  existingEntryNumbers: string[] = []
): JournalEntry {
  const lines: JournalEntryLine[] = [];
  const accTreasury =
    accounts.find((a) => a.id === expense.treasuryAccountId) ||
    resolveAccount(accounts, ['1111', '131'], 'أصول', ['الصندوق']);

  // Find mapped expense account in COA or fallback cleanly
  const accExpense =
    accounts.find((a) => a.id === expense.categoryId || a.nameAr.includes(expense.categoryName)) ||
    resolveAccount(accounts, ['5340', '510'], 'مصروفات', ['مصاريف']);

  lines.push({
    id: `jl-exp-${Date.now()}-1`,
    accountId: accExpense.id,
    accountCode: accExpense.code,
    accountName: accExpense.nameAr,
    debit: expense.total,
    credit: 0,
    currency: expense.currency,
    exchangeRate: 1,
    costCenterId: expense.costCenterId,
    costCenterName: expense.costCenterName,
    memo: `مصروف: ${expense.statement} - المستفيد: ${expense.beneficiary}`,
  });

  lines.push({
    id: `jl-exp-${Date.now()}-2`,
    accountId: accTreasury.id,
    accountCode: accTreasury.code,
    accountName: accTreasury.nameAr,
    debit: 0,
    credit: expense.total,
    currency: expense.currency,
    exchangeRate: 1,
    memo: `سداد مصروف رقم ${expense.expenseNumber} من ${accTreasury.nameAr}`,
  });

  const prefix = `JV-${new Date().getFullYear()}-`;
  const entryNumber = generateNextDocNumber(prefix, existingEntryNumbers, 4);

  return {
    id: `je-auto-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    entryNumber,
    date: expense.date,
    branchId: expense.branchId,
    referenceType: 'دليل_يدوي',
    referenceNumber: expense.expenseNumber,
    referenceId: expense.id,
    description: `قيد إثبات مصروف: ${expense.statement} - ${expense.categoryName}`,
    lines,
    totalDebit: expense.total,
    totalCredit: expense.total,
    status: 'posted',
    createdBy: userFullName,
    createdAt: new Date().toISOString(),
  };
}

/**
 * Creates a strictly balanced Journal Entry when approving a Physical Stocktaking session
 */
export function createStocktakingJournalEntry(
  stocktake: PhysicalStocktaking,
  accounts: Account[],
  surplusAccountCode: string = '4190',
  shortageAccountCode: string = '5390',
  userFullName: string,
  existingEntryNumbers: string[] = []
): JournalEntry | null {
  let totalSurplusValue = 0;
  let totalShortageValue = 0;

  for (const item of stocktake.items) {
    const diff = Number(item.physicalQuantity) - Number(item.bookQuantity);
    const val = Math.abs(diff) * (Number(item.unitCost) || 0);
    if (diff > 0 && val > 0) {
      totalSurplusValue += val;
    } else if (diff < 0 && val > 0) {
      totalShortageValue += val;
    }
  }

  if (totalSurplusValue === 0 && totalShortageValue === 0) {
    return null;
  }

  const accInventory = resolveAccount(accounts, ['115', '124'], 'أصول', ['المخزون']);
  const accSurplus = resolveAccount(
    accounts,
    [surplusAccountCode, '4190', '4120'],
    'إيرادات',
    ['فائض', 'فروقات الجرد']
  );
  const accShortage = resolveAccount(
    accounts,
    [shortageAccountCode, '5390', '5340'],
    'مصروفات',
    ['عجز', 'فروقات الجرد']
  );

  const lines: JournalEntryLine[] = [];
  const ts = Date.now();

  if (totalSurplusValue > 0) {
    lines.push({
      id: `jl-st-${ts}-1`,
      accountId: accInventory.id,
      accountCode: accInventory.code,
      accountName: accInventory.nameAr,
      debit: totalSurplusValue,
      credit: 0,
      currency: 'YER',
      exchangeRate: 1,
      memo: `إثبات زيادة مخزنية لجلسة الجرد ${stocktake.stocktakeNumber}`,
    });
    lines.push({
      id: `jl-st-${ts}-2`,
      accountId: accSurplus.id,
      accountCode: accSurplus.code,
      accountName: accSurplus.nameAr,
      debit: 0,
      credit: totalSurplusValue,
      currency: 'YER',
      exchangeRate: 1,
      memo: `فائض جرد مخزني (${stocktake.stocktakeNumber})`,
    });
  }

  if (totalShortageValue > 0) {
    lines.push({
      id: `jl-st-${ts}-3`,
      accountId: accShortage.id,
      accountCode: accShortage.code,
      accountName: accShortage.nameAr,
      debit: totalShortageValue,
      credit: 0,
      currency: 'YER',
      exchangeRate: 1,
      memo: `عجز وخسائر جرد مخزني (${stocktake.stocktakeNumber})`,
    });
    lines.push({
      id: `jl-st-${ts}-4`,
      accountId: accInventory.id,
      accountCode: accInventory.code,
      accountName: accInventory.nameAr,
      debit: 0,
      credit: totalShortageValue,
      currency: 'YER',
      exchangeRate: 1,
      memo: `تخفيض المخزون بالعجز المثبت في الجرد ${stocktake.stocktakeNumber}`,
    });
  }

  const totalDebit = lines.reduce((s, l) => s + l.debit, 0);
  const totalCredit = lines.reduce((s, l) => s + l.credit, 0);

  const prefix = `JV-${new Date().getFullYear()}-`;
  const entryNumber = generateNextDocNumber(prefix, existingEntryNumbers, 4);

  return {
    id: `je-st-${ts}`,
    entryNumber,
    date: stocktake.date,
    branchId: 'br-01',
    referenceType: 'تسوية_مخزنية',
    referenceNumber: stocktake.stocktakeNumber,
    referenceId: stocktake.id,
    description: `قيد تسوية فروقات الجرد الفعلي رقم ${stocktake.stocktakeNumber}`,
    lines,
    totalDebit,
    totalCredit,
    status: 'posted',
    createdBy: userFullName,
    createdAt: new Date().toISOString(),
  };
}

/**
 * Creates an equal & opposite reversal Journal Entry for any posted Journal Entry
 */
export function createReversalJournalEntry(
  original: JournalEntry,
  reason: string,
  userFullName: string,
  existingEntryNumbers: string[] = []
): JournalEntry {
  const ts = Date.now();
  const prefix = `JV-${new Date().getFullYear()}-`;
  const entryNumber = generateNextDocNumber(prefix, existingEntryNumbers, 4);

  const reversedLines: JournalEntryLine[] = original.lines.map((ln, idx) => ({
    ...ln,
    id: `jl-rev-${ts}-${idx + 1}`,
    debit: ln.credit,
    credit: ln.debit,
    memo: `عكس: ${ln.memo || original.description} (${reason})`,
  }));

  const totalDebit = reversedLines.reduce((s, l) => s + (Number(l.debit) || 0), 0);
  const totalCredit = reversedLines.reduce((s, l) => s + (Number(l.credit) || 0), 0);

  return {
    id: `je-rev-${ts}`,
    entryNumber,
    date: new Date().toISOString().split('T')[0],
    branchId: original.branchId,
    referenceType: original.referenceType,
    referenceNumber: original.entryNumber,
    referenceId: original.id,
    description: `قيد عكسي للقيد رقم ${original.entryNumber} - السبب: ${reason}`,
    lines: reversedLines,
    totalDebit,
    totalCredit,
    status: 'posted',
    reversedEntryId: original.id,
    createdBy: userFullName,
    createdAt: new Date().toISOString(),
  };
}

/**
 * Calculates General Ledger statement for an account with optional date range filtering
 */
export function calculateAccountLedger(
  accountId: string,
  journalEntries: JournalEntry[],
  accounts: Account[],
  dateRange?: DateRangeFilter
): StatementRow[] {
  const rows: StatementRow[] = [];
  const targetAccount = accounts.find(a => a.id === accountId);
  const isDebitNature = targetAccount?.nature !== 'credit';

  let runningBalance = 0;

  // Include opening imported balance if present
  const openingNet = isDebitNature
    ? (Number(targetAccount?.importedDebit) || 0) - (Number(targetAccount?.importedCredit) || 0)
    : (Number(targetAccount?.importedCredit) || 0) - (Number(targetAccount?.importedDebit) || 0);

  if (openingNet !== 0) {
    runningBalance = openingNet;
    rows.push({
      date: dateRange?.startDate || '2026-01-01',
      documentType: 'رصيد_افتتاحي',
      documentNumber: 'OP-BAL',
      statement: 'الرصيد الافتتاحي للحساب',
      debit: Number(targetAccount?.importedDebit) || 0,
      credit: Number(targetAccount?.importedCredit) || 0,
      balance: runningBalance,
    });
  }

  const sortedEntries = [...journalEntries]
    .filter(je => je.status === 'posted')
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  for (const entry of sortedEntries) {
    if (dateRange?.endDate && entry.date > dateRange.endDate) continue;
    const matchingLines = entry.lines.filter(l => l.accountId === accountId);
    for (const line of matchingLines) {
      const debit = Number(line.debit) || 0;
      const credit = Number(line.credit) || 0;

      if (isDebitNature) {
        runningBalance += (debit - credit);
      } else {
        runningBalance += (credit - debit);
      }

      if (dateRange?.startDate && entry.date < dateRange.startDate) {
        continue;
      }

      rows.push({
        date: entry.date,
        documentType: entry.referenceType,
        documentNumber: entry.referenceNumber,
        statement: line.memo || entry.description,
        debit,
        credit,
        balance: runningBalance,
      });
    }
  }

  return rows;
}

/**
 * Generates Full Trial Balance (ميزان المراجعة)
 */
export function generateTrialBalance(
  accounts: Account[],
  journalEntries: JournalEntry[],
  dateRange?: DateRangeFilter
): TrialBalanceRow[] {
  const activeEntries = journalEntries.filter((je) => je.status === 'posted');

  const openingFromEntries = new Map<string, { debit: number; credit: number }>();
  const entryTotalsByAccId = new Map<string, { debit: number; credit: number }>();

  for (const entry of activeEntries) {
    if (dateRange?.endDate && entry.date > dateRange.endDate) continue;

    if (dateRange?.startDate && entry.date < dateRange.startDate) {
      for (const line of entry.lines) {
        const prev = openingFromEntries.get(line.accountId) || { debit: 0, credit: 0 };
        prev.debit += Number(line.debit) || 0;
        prev.credit += Number(line.credit) || 0;
        openingFromEntries.set(line.accountId, prev);
      }
      continue;
    }

    for (const line of entry.lines) {
      const prev = entryTotalsByAccId.get(line.accountId) || { debit: 0, credit: 0 };
      prev.debit += Number(line.debit) || 0;
      prev.credit += Number(line.credit) || 0;
      entryTotalsByAccId.set(line.accountId, prev);
    }
  }

  return accounts
    .filter((a) => a.isLeaf)
    .map((acc) => {
      const preEnt = openingFromEntries.get(acc.id) || { debit: 0, credit: 0 };
      const openingDebit = (Number(acc.importedDebit) || 0) + preEnt.debit;
      const openingCredit = (Number(acc.importedCredit) || 0) + preEnt.credit;
      const fromEntries = entryTotalsByAccId.get(acc.id) || { debit: 0, credit: 0 };

      const periodDebit = openingDebit + fromEntries.debit;
      const periodCredit = openingCredit + fromEntries.credit;

      let endingDebit = 0;
      let endingCredit = 0;

      if (acc.nature === 'debit') {
        const net = periodDebit - periodCredit;
        if (net >= 0) {
          endingDebit = net;
        } else {
          endingCredit = Math.abs(net);
        }
      } else {
        const net = periodCredit - periodDebit;
        if (net >= 0) {
          endingCredit = net;
        } else {
          endingDebit = Math.abs(net);
        }
      }

      return {
        accountId: acc.id,
        accountCode: acc.code,
        accountName: acc.nameAr,
        category: acc.category,
        openingDebit,
        openingCredit,
        periodDebit,
        periodCredit,
        endingDebit,
        endingCredit,
      };
    })
    .sort((a, b) => a.accountCode.localeCompare(b.accountCode));
}

/**
 * Generates Income Statement (قائمة الدخل)
 */
export function generateIncomeStatement(
  accounts: Account[],
  journalEntries: JournalEntry[],
  dateRange?: DateRangeFilter
): IncomeStatementResult {
  const tb = generateTrialBalance(accounts, journalEntries, dateRange);

  const revenues: { accountCode: string; accountName: string; amount: number }[] = [];
  const cogs: { accountCode: string; accountName: string; amount: number }[] = [];
  const expenses: { accountCode: string; accountName: string; amount: number }[] = [];

  for (const row of tb) {
    if (row.category === 'إيرادات') {
      const amount = row.endingCredit - row.endingDebit;
      if (Math.abs(amount) > 0.01) {
        revenues.push({ accountCode: row.accountCode, accountName: row.accountName, amount });
      }
    } else if (row.category === 'مصروفات') {
      const amount = row.endingDebit - row.endingCredit;
      if (Math.abs(amount) > 0.01) {
        if (row.accountCode === '5110' || row.accountCode.startsWith('3')) {
          cogs.push({ accountCode: row.accountCode, accountName: row.accountName, amount });
        } else {
          expenses.push({ accountCode: row.accountCode, accountName: row.accountName, amount });
        }
      }
    }
  }

  const totalRevenue = revenues.reduce((s, r) => s + r.amount, 0);
  const totalCogs = cogs.reduce((s, c) => s + c.amount, 0);
  const grossProfit = totalRevenue - totalCogs;
  const totalExpenses = expenses.reduce((s, e) => s + e.amount, 0);
  const netIncome = grossProfit - totalExpenses;

  return {
    revenues,
    totalRevenue,
    cogs,
    totalCogs,
    grossProfit,
    expenses,
    totalExpenses,
    netIncome,
  };
}

/**
 * Generates Balance Sheet (الميزانية العمومية)
 */
export function generateBalanceSheet(
  accounts: Account[],
  journalEntries: JournalEntry[],
  dateRange?: DateRangeFilter
): BalanceSheetResult {
  const tb = generateTrialBalance(accounts, journalEntries, dateRange);
  const incomeStmt = generateIncomeStatement(accounts, journalEntries, dateRange);

  const assets: { accountCode: string; accountName: string; balance: number }[] = [];
  const liabilities: { accountCode: string; accountName: string; balance: number }[] = [];
  const equity: { accountCode: string; accountName: string; balance: number }[] = [];

  for (const row of tb) {
    if (row.category === 'أصول') {
      const balance = row.endingDebit - row.endingCredit;
      assets.push({ accountCode: row.accountCode, accountName: row.accountName, balance });
    } else if (row.category === 'خصوم') {
      const balance = row.endingCredit - row.endingDebit;
      liabilities.push({ accountCode: row.accountCode, accountName: row.accountName, balance });
    } else if (row.category === 'حقوق_ملكية') {
      const balance = row.endingCredit - row.endingDebit;
      equity.push({ accountCode: row.accountCode, accountName: row.accountName, balance });
    }
  }

  const totalAssets = assets.reduce((s, a) => s + a.balance, 0);
  const totalLiabilities = liabilities.reduce((s, l) => s + l.balance, 0);
  const totalEquityBase = equity.reduce((s, e) => s + e.balance, 0);

  const netProfitCarried = incomeStmt.netIncome;
  const totalEquity = totalEquityBase + netProfitCarried;
  const totalLiabilitiesAndEquity = totalLiabilities + totalEquity;

  const variance = Math.abs(totalAssets - totalLiabilitiesAndEquity);
  const isBalanced = variance < 1;

  return {
    assets,
    totalAssets,
    liabilities,
    totalLiabilities,
    equity,
    totalEquity,
    netProfitCarried,
    totalLiabilitiesAndEquity,
    isBalanced,
    variance,
  };
}

/**
 * Generates Cash Flow Statement (قائمة التدفقات النقدية) from operational documents & COA cash accounts
 */
export function generateCashFlowStatement(
  accounts: Account[],
  invoices: Invoice[],
  vouchers: PaymentVoucher[],
  expenses: ExpenseRecord[],
  dateRange?: DateRangeFilter
): CashFlowStatementResult {
  const inRange = (d: string) => {
    if (dateRange?.startDate && d < dateRange.startDate) return false;
    if (dateRange?.endDate && d > dateRange.endDate) return false;
    return true;
  };

  const cashSales = invoices
    .filter((i) => i.type === 'مبيعات' && i.status !== 'cancelled' && inRange(i.date))
    .reduce((s, i) => s + (i.paidAmount || 0) * (i.exchangeRate || 1), 0);

  const receiptsFromCustomers = vouchers
    .filter((v) => v.type === 'قبض' && v.status === 'posted' && inRange(v.date))
    .reduce((s, v) => s + (v.baseAmount || v.amount * v.exchangeRate), 0);

  const cashPurchases = invoices
    .filter((i) => i.type === 'مشتريات' && i.status !== 'cancelled' && inRange(i.date))
    .reduce((s, i) => s + (i.paidAmount || 0) * (i.exchangeRate || 1), 0);

  const paymentsOut = vouchers
    .filter((v) => v.type === 'صرف' && v.status === 'posted' && inRange(v.date))
    .reduce((s, v) => s + (v.baseAmount || v.amount * v.exchangeRate), 0);

  const operatingExpensesOut = expenses
    .filter((e) => inRange(e.date))
    .reduce((s, e) => s + (e.total || 0), 0);

  const operatingInflows = [
    { label: 'تحصيلات المبيعات النقدية والدفعات الفورية', amount: cashSales },
    { label: 'متحصلات سندات القبض (عملاء وإيرادات)', amount: receiptsFromCustomers },
  ];

  const operatingOutflows = [
    { label: 'مدفوعات المشتريات النقدية', amount: cashPurchases },
    { label: 'مدفوعات سندات الصرف (موردين والتزامات)', amount: paymentsOut },
    { label: 'المصروفات التشغيلية والإدارية المسددة', amount: operatingExpensesOut },
  ];

  const totalIn = operatingInflows.reduce((s, r) => s + r.amount, 0);
  const totalOut = operatingOutflows.reduce((s, r) => s + r.amount, 0);
  const netOperatingCashFlow = totalIn - totalOut;
  const investingCashFlow = 0;
  const financingCashFlow = 0;
  const netCashChange = netOperatingCashFlow + investingCashFlow + financingCashFlow;

  const closingCashBalance = accounts
    .filter((a) => a.isLeaf && (a.code.startsWith('111') || a.code.startsWith('112') || a.code.startsWith('113')))
    .reduce((s, a) => s + (Number(a.currentBalance) || 0), 0);

  const openingCashBalance = closingCashBalance - netCashChange;

  return {
    operatingInflows,
    operatingOutflows,
    netOperatingCashFlow,
    investingCashFlow,
    financingCashFlow,
    netCashChange,
    openingCashBalance,
    closingCashBalance,
  };
}

/**
 * Generates Detailed Statement of Account for a Customer
 */
export function generateCustomerStatement(
  customerId: string,
  customer: Customer,
  invoices: Invoice[],
  vouchers: PaymentVoucher[],
  journalEntries: JournalEntry[] = []
): StatementRow[] {
  const rows: StatementRow[] = [];
  let runningBalance = customer.openingBalance;

  // Opening balance row
  rows.push({
    date: customer.createdAt || '2026-01-01',
    documentType: 'رصيد_افتتاحي',
    documentNumber: 'OP-BAL',
    statement: 'الرصيد الافتتاحي للعميل',
    debit: customer.openingBalance > 0 ? customer.openingBalance : 0,
    credit: customer.openingBalance < 0 ? Math.abs(customer.openingBalance) : 0,
    balance: runningBalance,
  });

  // Collect customer invoices & returns & vouchers
  const customerSalesInvoices = invoices.filter(
    (inv) => inv.entityId === customerId && inv.type === 'مبيعات' && inv.status !== 'cancelled'
  );
  const customerReturns = invoices.filter(
    (inv) => inv.entityId === customerId && inv.type === 'مرتجع_مبيعات' && inv.status !== 'cancelled'
  );
  const customerPurchaseInvoices = invoices.filter(
    (inv) => inv.entityId === customerId && inv.type === 'مشتريات' && inv.status !== 'cancelled'
  );
  const customerPurchaseReturns = invoices.filter(
    (inv) => inv.entityId === customerId && inv.type === 'مرتجع_مشتريات' && inv.status !== 'cancelled'
  );
  const customerVouchers = vouchers.filter(
    (v) => v.entityId === customerId && v.status === 'posted'
  );

  // Track already-covered journalEntryIds so we never double-count bills/vouchers
  const coveredJournalIds = new Set<string>();
  customerSalesInvoices.forEach((i) => i.journalEntryId && coveredJournalIds.add(i.journalEntryId));
  customerReturns.forEach((i) => i.journalEntryId && coveredJournalIds.add(i.journalEntryId));
  customerPurchaseInvoices.forEach((i) => i.journalEntryId && coveredJournalIds.add(i.journalEntryId));
  customerPurchaseReturns.forEach((i) => i.journalEntryId && coveredJournalIds.add(i.journalEntryId));
  customerVouchers.forEach((v) => v.journalEntryId && coveredJournalIds.add(v.journalEntryId));

  const allEvents: { date: string; type: string; number: string; statement: string; debit: number; credit: number }[] = [];

  for (const inv of customerSalesInvoices) {
    const rate = inv.exchangeRate || 1;
    const totalBase = Math.round(inv.grandTotal * rate * 100) / 100;
    const paidBase =
      inv.paymentType === 'نقدي' ? totalBase : Math.round((inv.paidAmount || 0) * rate * 100) / 100;
    allEvents.push({
      date: inv.date,
      type: 'فاتورة مبيعات',
      number: inv.invoiceNumber,
      statement: inv.notes || `فاتورة مبيعات ${inv.paymentType}`,
      debit: totalBase,
      credit: paidBase,
    });
  }

  for (const ret of customerReturns) {
    const rate = ret.exchangeRate || 1;
    const totalBase = Math.round(ret.grandTotal * rate * 100) / 100;
    allEvents.push({
      date: ret.date,
      type: 'مرتجع مبيعات',
      number: ret.invoiceNumber,
      statement: ret.notes || `مرتجع مبيعات بموجب الإشعار الدائن`,
      debit: 0,
      credit: totalBase,
    });
  }

  for (const pinv of customerPurchaseInvoices) {
    const rate = pinv.exchangeRate || 1;
    const totalBase = Math.round(pinv.grandTotal * rate * 100) / 100;
    const paidBase =
      pinv.paymentType === 'نقدي' ? totalBase : Math.round((pinv.paidAmount || 0) * rate * 100) / 100;
    allEvents.push({
      date: pinv.date,
      type: 'فاتورة مشتريات',
      number: pinv.invoiceNumber,
      statement: pinv.notes || `فاتورة مشتريات ${pinv.paymentType}`,
      debit: paidBase,
      credit: totalBase,
    });
  }

  for (const pret of customerPurchaseReturns) {
    const rate = pret.exchangeRate || 1;
    const totalBase = Math.round(pret.grandTotal * rate * 100) / 100;
    allEvents.push({
      date: pret.date,
      type: 'مرتجع مشتريات',
      number: pret.invoiceNumber,
      statement: pret.notes || `مرتجع مشتريات`,
      debit: totalBase,
      credit: 0,
    });
  }

  for (const v of customerVouchers) {
    const baseAmt = v.amount * v.exchangeRate;
    if (v.type === 'قبض') {
      allEvents.push({
        date: v.date,
        type: 'سند قبض',
        number: v.voucherNumber,
        statement: v.statement || 'سند قبض نقدي/بنكي',
        debit: 0,
        credit: baseAmt,
      });
    } else if (v.type === 'صرف') {
      allEvents.push({
        date: v.date,
        type: 'سند صرف',
        number: v.voucherNumber,
        statement: v.statement || 'سند صرف / دفعة على حساب العميل',
        debit: baseAmt,
        credit: 0,
      });
    }
  }

  // Standalone journal entries touching customer's linked account (or referencing customerId)
  if (journalEntries.length > 0) {
    for (const je of journalEntries) {
      if (je.status !== 'posted') continue;
      if (coveredJournalIds.has(je.id)) continue;

      const matchingLines = je.lines.filter(
        (ln) =>
          (customer.linkedAccountId && ln.accountId === customer.linkedAccountId) ||
          (customer.linkedAccountCode && ln.accountCode === customer.linkedAccountCode) ||
          je.referenceId === customerId
      );

      for (const ln of matchingLines) {
        const rate = ln.exchangeRate || 1;
        const debitVal = Math.round((ln.debit || 0) * rate * 100) / 100;
        const creditVal = Math.round((ln.credit || 0) * rate * 100) / 100;
        if (debitVal === 0 && creditVal === 0) continue;
        allEvents.push({
          date: je.date,
          type: je.referenceType === 'دليل_يدوي' ? 'قيد يومية' : je.referenceType.replace(/_/g, ' '),
          number: je.entryNumber,
          statement: ln.memo || je.description || 'حركة قيد محاسبي',
          debit: debitVal,
          credit: creditVal,
        });
      }
    }
  }

  allEvents.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  for (const ev of allEvents) {
    runningBalance += ev.debit - ev.credit;
    rows.push({
      date: ev.date,
      documentType: ev.type,
      documentNumber: ev.number,
      statement: ev.statement,
      debit: ev.debit,
      credit: ev.credit,
      balance: runningBalance,
    });
  }

  return rows;
}

/**
 * Generates Detailed Statement of Account for a Vendor (credit-nature: positive = payable to vendor)
 */
export function generateVendorStatement(
  vendorId: string,
  vendor: Vendor,
  invoices: Invoice[],
  vouchers: PaymentVoucher[],
  journalEntries: JournalEntry[] = []
): StatementRow[] {
  const rows: StatementRow[] = [];
  let runningBalance = vendor.openingBalance;

  rows.push({
    date: vendor.createdAt || '2026-01-01',
    documentType: 'رصيد_افتتاحي',
    documentNumber: 'OP-BAL',
    statement: 'الرصيد الافتتاحي للمورد',
    debit: vendor.openingBalance < 0 ? Math.abs(vendor.openingBalance) : 0,
    credit: vendor.openingBalance > 0 ? vendor.openingBalance : 0,
    balance: runningBalance,
  });

  const vendInvoices = invoices.filter(
    (inv) => inv.entityId === vendorId && inv.status !== 'cancelled'
  );
  const vendVouchers = vouchers.filter(
    (v) => v.entityId === vendorId && v.status === 'posted'
  );

  const coveredJournalIds = new Set<string>();
  vendInvoices.forEach((i) => i.journalEntryId && coveredJournalIds.add(i.journalEntryId));
  vendVouchers.forEach((v) => v.journalEntryId && coveredJournalIds.add(v.journalEntryId));

  const allEvents: { date: string; type: string; number: string; statement: string; debit: number; credit: number }[] = [];

  for (const inv of vendInvoices) {
    const rate = inv.exchangeRate || 1;
    const totalBase = Math.round(inv.grandTotal * rate * 100) / 100;
    const paidBase =
      inv.paymentType === 'نقدي' ? totalBase : Math.round((inv.paidAmount || 0) * rate * 100) / 100;
    if (inv.type === 'مشتريات') {
      allEvents.push({
        date: inv.date,
        type: 'فاتورة مشتريات',
        number: inv.invoiceNumber,
        statement: inv.notes || `فاتورة مشتريات ${inv.paymentType}`,
        debit: paidBase,
        credit: totalBase,
      });
    } else if (inv.type === 'مرتجع_مشتريات') {
      allEvents.push({
        date: inv.date,
        type: 'مرتجع مشتريات',
        number: inv.invoiceNumber,
        statement: inv.notes || 'مرتجع مشتريات',
        debit: totalBase,
        credit: 0,
      });
    } else if (inv.type === 'مبيعات') {
      allEvents.push({
        date: inv.date,
        type: 'فاتورة مبيعات',
        number: inv.invoiceNumber,
        statement: inv.notes || `فاتورة مبيعات`,
        debit: totalBase,
        credit: paidBase,
      });
    } else if (inv.type === 'مرتجع_مبيعات') {
      allEvents.push({
        date: inv.date,
        type: 'مرتجع مبيعات',
        number: inv.invoiceNumber,
        statement: inv.notes || 'مرتجع مبيعات',
        debit: 0,
        credit: totalBase,
      });
    }
  }

  for (const v of vendVouchers) {
    const baseAmt = v.amount * v.exchangeRate;
    if (v.type === 'صرف') {
      allEvents.push({
        date: v.date,
        type: 'سند صرف',
        number: v.voucherNumber,
        statement: v.statement || 'سداد مستحقات للمورد',
        debit: baseAmt,
        credit: 0,
      });
    } else {
      allEvents.push({
        date: v.date,
        type: 'سند قبض',
        number: v.voucherNumber,
        statement: v.statement || 'سند قبض من المورد',
        debit: 0,
        credit: baseAmt,
      });
    }
  }

  for (const je of journalEntries) {
    if (je.status !== 'posted' || coveredJournalIds.has(je.id)) continue;
    const matchingLines = je.lines.filter(
      (ln) =>
        (vendor.linkedAccountId && ln.accountId === vendor.linkedAccountId) ||
        (vendor.linkedAccountCode && ln.accountCode === vendor.linkedAccountCode) ||
        je.referenceId === vendorId
    );
    for (const ln of matchingLines) {
      const rate = ln.exchangeRate || 1;
      const debitVal = Math.round((ln.debit || 0) * rate * 100) / 100;
      const creditVal = Math.round((ln.credit || 0) * rate * 100) / 100;
      if (debitVal === 0 && creditVal === 0) continue;
      allEvents.push({
        date: je.date,
        type: je.referenceType === 'دليل_يدوي' ? 'قيد يومية' : je.referenceType.replace(/_/g, ' '),
        number: je.entryNumber,
        statement: ln.memo || je.description || 'حركة قيد محاسبي',
        debit: debitVal,
        credit: creditVal,
      });
    }
  }

  allEvents.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  for (const ev of allEvents) {
    runningBalance += ev.credit - ev.debit;
    rows.push({
      date: ev.date,
      documentType: ev.type,
      documentNumber: ev.number,
      statement: ev.statement,
      debit: ev.debit,
      credit: ev.credit,
      balance: runningBalance,
    });
  }

  return rows;
}
