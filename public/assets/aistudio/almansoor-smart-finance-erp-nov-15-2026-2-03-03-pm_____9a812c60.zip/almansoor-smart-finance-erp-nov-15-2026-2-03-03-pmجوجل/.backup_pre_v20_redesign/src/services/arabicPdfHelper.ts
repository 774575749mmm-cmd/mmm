/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * ALMANSOOR SMART FINANCE ERP - Genuine Binary PDF Engine with Embedded Cairo TTF,
 * Arabic Contextual Reshaper (Isolated/Initial/Medial/Final + Lam-Alef), and BiDi Visual Reordering
 */

import { jsPDF } from 'jspdf';
import type { Company, Branch, Invoice, PaymentVoucher } from '../types/erp';
import type { ReportPDFOptions } from './exportService';

// [isolated, final, initial, medial] in Unicode Arabic Presentation Forms-B
const ARABIC_FORMS: Record<string, [string, string, string?, string?]> = {
  '\u0621': ['\uFE80', '\uFE80'], // ء
  '\u0622': ['\uFE81', '\uFE82'], // آ
  '\u0623': ['\uFE83', '\uFE84'], // أ
  '\u0624': ['\uFE85', '\uFE86'], // ؤ
  '\u0625': ['\uFE87', '\uFE88'], // إ
  '\u0626': ['\uFE89', '\uFE8A', '\uFE8B', '\uFE8C'], // ئ
  '\u0627': ['\uFE8D', '\uFE8E'], // ا
  '\u0628': ['\uFE8F', '\uFE90', '\uFE91', '\uFE92'], // ب
  '\u0629': ['\uFE93', '\uFE94'], // ة
  '\u062A': ['\uFE95', '\uFE96', '\uFE97', '\uFE98'], // ت
  '\u062B': ['\uFE99', '\uFE9A', '\uFE9B', '\uFE9C'], // ث
  '\u062C': ['\uFE9D', '\uFE9E', '\uFE9F', '\uFEA0'], // ج
  '\u062D': ['\uFEA1', '\uFEA2', '\uFEA3', '\uFEA4'], // ح
  '\u062E': ['\uFEA5', '\uFEA6', '\uFEA7', '\uFEA8'], // خ
  '\u062F': ['\uFEA9', '\uFEAA'], // د
  '\u0630': ['\uFEAB', '\uFEAC'], // ذ
  '\u0631': ['\uFEAD', '\uFEAE'], // ر
  '\u0632': ['\uFEAF', '\uFEB0'], // ز
  '\u0633': ['\uFEB1', '\uFEB2', '\uFEB3', '\uFEB4'], // س
  '\u0634': ['\uFEB5', '\uFEB6', '\uFEB7', '\uFEB8'], // ش
  '\u0635': ['\uFEB9', '\uFEBA', '\uFEBB', '\uFEBC'], // ص
  '\u0636': ['\uFEBD', '\uFEBE', '\uFEBF', '\uFEC0'], // ض
  '\u0637': ['\uFEC1', '\uFEC2', '\uFEC3', '\uFEC4'], // ط
  '\u0638': ['\uFEC5', '\uFEC6', '\uFEC7', '\uFEC8'], // ظ
  '\u0639': ['\uFEC9', '\uFECA', '\uFECB', '\uFECC'], // ع
  '\u063A': ['\uFECD', '\uFECE', '\uFECF', '\uFED0'], // غ
  '\u0640': ['\u0640', '\u0640', '\u0640', '\u0640'], // ـ Tatweel
  '\u0641': ['\uFED1', '\uFED2', '\uFED3', '\uFED4'], // ف
  '\u0642': ['\uFED5', '\uFED6', '\uFED7', '\uFED8'], // ق
  '\u0643': ['\uFED9', '\uFEDA', '\uFEDB', '\uFEDC'], // ك
  '\u0644': ['\uFEDD', '\uFEDE', '\uFEDF', '\uFEE0'], // ل
  '\u0645': ['\uFEE1', '\uFEE2', '\uFEE3', '\uFEE4'], // م
  '\u0646': ['\uFEE5', '\uFEE6', '\uFEE7', '\uFEE8'], // ن
  '\u0647': ['\uFEE9', '\uFEEA', '\uFEEB', '\uFEEC'], // ه
  '\u0648': ['\uFEED', '\uFEEE'], // و
  '\u0649': ['\uFEEF', '\uFEF0'], // ى
  '\u064A': ['\uFEF1', '\uFEF2', '\uFEF3', '\uFEF4'], // ي
};

const LAM_ALEF_LIGATURES: Record<string, [string, string]> = {
  '\u0622': ['\uFEF5', '\uFEF6'], // لآ
  '\u0623': ['\uFEF7', '\uFEF8'], // لأ
  '\u0625': ['\uFEF9', '\uFEFA'], // لإ
  '\u0627': ['\uFEFB', '\uFEFC'], // لا
};

const ARABIC_DIACRITICS_REGEX = /[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]/g;

function canConnectAfter(ch: string | undefined): boolean {
  if (!ch) return false;
  const forms = ARABIC_FORMS[ch];
  return Boolean(forms && forms[2] && forms[3]);
}

function isArabicLetter(ch: string | undefined): boolean {
  if (!ch) return false;
  return Boolean(ARABIC_FORMS[ch]);
}

function mirrorBrackets(str: string): string {
  return str
    .replace(/\(/g, '\u0001')
    .replace(/\)/g, '(')
    .replace(/\u0001/g, ')')
    .replace(/\[/g, '\u0002')
    .replace(/\]/g, '[')
    .replace(/\u0002/g, ']');
}

/**
 * Shapes logical Arabic characters into Presentation Forms-B including Lam-Alef ligatures.
 */
export function shapeArabicLogical(text: string): string {
  const cleaned = (text || '').replace(ARABIC_DIACRITICS_REGEX, '');
  const chars = Array.from(cleaned);
  const out: string[] = [];

  for (let i = 0; i < chars.length; i++) {
    const ch = chars[i];
    if (!isArabicLetter(ch)) {
      out.push(ch);
      continue;
    }

    const prevChar = i > 0 ? chars[i - 1] : undefined;
    const prevConnects = canConnectAfter(prevChar);

    // Handle Lam + Alef ligatures
    if (ch === '\u0644' && i + 1 < chars.length && LAM_ALEF_LIGATURES[chars[i + 1]]) {
      const lig = LAM_ALEF_LIGATURES[chars[i + 1]];
      out.push(prevConnects ? lig[1] : lig[0]);
      i += 1;
      continue;
    }

    const nextChar = i + 1 < chars.length ? chars[i + 1] : undefined;
    const nextIsArabic = isArabicLetter(nextChar);
    const forms = ARABIC_FORMS[ch];
    const hasInitial = Boolean(forms[2]);
    const hasMedial = Boolean(forms[3]);

    if (prevConnects && nextIsArabic && hasMedial) {
      out.push(forms[3]!);
    } else if (prevConnects && forms[1]) {
      out.push(forms[1]);
    } else if (!prevConnects && nextIsArabic && hasInitial) {
      out.push(forms[2]!);
    } else {
      out.push(forms[0]);
    }
  }

  return out.join('');
}

function containsArabic(text: string): boolean {
  return /[\u0600-\u06FF\uFE70-\uFEFC]/.test(text);
}

/**
 * Converts logical Arabic/mixed text into visual LTR glyph order for jsPDF TrueType rendering.
 */
export function prepareArabicPdfText(input: string | number | undefined | null): string {
  if (input === undefined || input === null) return '';
  const str = String(input);
  if (!str) return '';
  if (!containsArabic(str)) return str;

  const shaped = shapeArabicLogical(str);

  // Segment into LTR runs (numbers, Latin, dates/codes) vs RTL runs (Arabic + neutral punctuation/spaces)
  const tokenRegex = /([A-Za-z0-9][A-Za-z0-9.,:/%\-_+]*|[\u0660-\u0669]+(?:[.,:/%\-_+][\u0660-\u0669]+)*)/g;
  const runs: { text: string; isLtr: boolean }[] = [];

  let lastIdx = 0;
  let match: RegExpExecArray | null;
  while ((match = tokenRegex.exec(shaped)) !== null) {
    if (match.index > lastIdx) {
      runs.push({ text: shaped.slice(lastIdx, match.index), isLtr: false });
    }
    runs.push({ text: match[0], isLtr: true });
    lastIdx = match.index + match[0].length;
  }
  if (lastIdx < shaped.length) {
    runs.push({ text: shaped.slice(lastIdx), isLtr: false });
  }

  // Reorder runs visually right-to-left (reversed array for LTR jsPDF placement)
  const visualParts = runs.reverse().map((run) => {
    if (run.isLtr) return run.text;
    const mirrored = mirrorBrackets(run.text);
    return Array.from(mirrored).reverse().join('');
  });

  return visualParts.join('');
}

let cachedCairoBase64: string | null = null;

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  const chunks: string[] = [];
  for (let i = 0; i < bytes.length; i += chunkSize) {
    chunks.push(String.fromCharCode(...bytes.subarray(i, i + chunkSize)));
  }
  if (typeof btoa === 'function') {
    return btoa(chunks.join(''));
  }
  return Buffer.from(bytes).toString('base64');
}

async function loadCairoFontBase64(): Promise<string> {
  if (cachedCairoBase64) return cachedCairoBase64;

  if (typeof window !== 'undefined' && typeof fetch === 'function') {
    const resp = await fetch('/fonts/Cairo.ttf');
    if (!resp.ok) {
      throw new Error(`تعذر تحميل خط Cairo للطباعة العربية (HTTP ${resp.status})`);
    }
    const buf = await resp.arrayBuffer();
    cachedCairoBase64 = arrayBufferToBase64(buf);
    return cachedCairoBase64;
  }

  // Node / Vitest / TSX fallback
  const fsMod = 'node:fs';
  const pathMod = 'node:path';
  const fs = await import(/* @vite-ignore */ fsMod);
  const path = await import(/* @vite-ignore */ pathMod);
  const fontPath = path.resolve(process.cwd(), 'public/fonts/Cairo.ttf');
  const buf: Buffer = fs.readFileSync(fontPath);
  cachedCairoBase64 = buf.toString('base64');
  return cachedCairoBase64;
}

async function createArabicDoc(orientation: 'portrait' | 'landscape'): Promise<jsPDF> {
  const doc = new jsPDF({
    orientation,
    unit: 'mm',
    format: 'a4',
    compress: true,
  });

  const base64Font = await loadCairoFontBase64();
  doc.addFileToVFS('Cairo.ttf', base64Font);
  doc.addFont('Cairo.ttf', 'Cairo', 'normal');
  doc.addFont('Cairo.ttf', 'Cairo', 'bold');
  doc.setFont('Cairo', 'normal');
  return doc;
}

function pdfNum(val: number | undefined | null, decimals = 2): string {
  return Number(val || 0).toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

function wrapLogicalText(text: string, maxCharsPerLine: number): string[] {
  const str = String(text ?? '').trim();
  if (!str) return [''];
  if (str.length <= maxCharsPerLine) return [str];
  const words = str.split(/\s+/);
  const lines: string[] = [];
  let current = '';
  for (const w of words) {
    if ((current + ' ' + w).trim().length > maxCharsPerLine) {
      if (current) lines.push(current.trim());
      if (w.length > maxCharsPerLine) {
        lines.push(w.slice(0, maxCharsPerLine));
        current = w.slice(maxCharsPerLine);
      } else {
        current = w;
      }
    } else {
      current = current ? `${current} ${w}` : w;
    }
  }
  if (current) lines.push(current.trim());
  return lines.length > 0 ? lines : [str];
}

/**
 * Generates a multi-page executive PDF for any ReportPDFOptions structure.
 */
export async function buildReportPdfBytes(options: ReportPDFOptions): Promise<Uint8Array> {
  const maxCols = Math.max(...options.tables.map((t) => t.headers.length), 4);
  const orientation: 'portrait' | 'landscape' = maxCols > 5 ? 'landscape' : 'portrait';
  const doc = await createArabicDoc(orientation);

  doc.setProperties({
    title: options.title,
    subject: options.subtitle || 'ALMANSOOR SMART FINANCE ERP',
    author: options.company?.nameAr || 'Almansoor ERP',
    creator: 'Almansoor Smart Finance ERP PDF Engine',
  });

  const pageW = doc.internal.pageSize.getWidth();
  const pageH = doc.internal.pageSize.getHeight();
  const margin = 12;
  const contentW = pageW - margin * 2;
  let y = margin;

  const drawHeader = () => {
    doc.setFillColor(15, 23, 42); // Slate-900 dark corporate bar
    doc.rect(margin, margin, contentW, 22, 'F');
    doc.setFillColor(217, 119, 6); // Amber gold bottom accent line
    doc.rect(margin, margin + 22, contentW, 1.2, 'F');

    doc.setTextColor(251, 191, 36);
    doc.setFontSize(13);
    doc.text(
      prepareArabicPdfText(options.company?.nameAr || 'المنصور للأنظمة المالية والإدارية الذكية'),
      pageW - margin - 4,
      margin + 8,
      { align: 'right' }
    );

    doc.setTextColor(226, 232, 240);
    doc.setFontSize(8.5);
    const subCompanyParts = [
      options.branch?.nameAr || 'الفرع الرئيسي',
      options.company?.commercialRecord ? `CR: ${options.company.commercialRecord}` : '',
      options.company?.taxNumber ? `TAX: ${options.company.taxNumber}` : '',
      options.company?.phone || '',
    ]
      .filter(Boolean)
      .join('  |  ');
    doc.text(prepareArabicPdfText(subCompanyParts), pageW - margin - 4, margin + 15.5, { align: 'right' });

    doc.setTextColor(255, 255, 255);
    doc.setFontSize(12.5);
    doc.text(prepareArabicPdfText(options.title), margin + 4, margin + 9, { align: 'left' });
    doc.setTextColor(203, 213, 225);
    doc.setFontSize(8.5);
    const rightMeta = options.periodText
      ? `الفترة: ${options.periodText}`
      : options.subtitle || options.reportCode || '';
    doc.text(prepareArabicPdfText(rightMeta), margin + 4, margin + 16, { align: 'left' });

    y = margin + 28;
  };

  const ensureSpace = (needed: number) => {
    if (y + needed > pageH - 18) {
      doc.addPage();
      drawHeader();
      return true;
    }
    return false;
  };

  drawHeader();

  // Optional metadata block
  if (options.metadata && Object.keys(options.metadata).length > 0) {
    const entries = Object.entries(options.metadata);
    const cols = 3;
    const rowsCount = Math.ceil(entries.length / cols);
    const boxH = rowsCount * 7 + 5;
    ensureSpace(boxH + 4);

    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(203, 213, 225);
    doc.rect(margin, y, contentW, boxH, 'FD');

    const colW = contentW / cols;
    doc.setFontSize(8.5);
    entries.forEach(([k, v], idx) => {
      const colIdx = idx % cols;
      const rowIdx = Math.floor(idx / cols);
      const cellX = pageW - margin - colIdx * colW - 4;
      const cellY = y + 6 + rowIdx * 7;
      doc.setTextColor(15, 23, 42);
      doc.text(prepareArabicPdfText(`${k}: ${v}`), cellX, cellY, { align: 'right' });
    });

    y += boxH + 5;
  }

  // Render tables
  for (const table of options.tables) {
    if (table.title) {
      ensureSpace(14);
      doc.setFillColor(241, 245, 249);
      doc.rect(margin, y, contentW, 7, 'F');
      doc.setFillColor(217, 119, 6);
      doc.rect(pageW - margin - 2, y, 2, 7, 'F');
      doc.setTextColor(15, 23, 42);
      doc.setFontSize(10);
      doc.text(prepareArabicPdfText(table.title), pageW - margin - 5, y + 5, { align: 'right' });
      y += 9;
    }

    const colCount = Math.max(table.headers.length, 1);
    const colW = contentW / colCount;
    const maxCharsPerCol = Math.max(Math.floor(colW * 1.45), 8);

    const drawTableHeader = () => {
      doc.setFillColor(30, 41, 59);
      doc.rect(margin, y, contentW, 8, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(8.5);
      table.headers.forEach((h, cIdx) => {
        // RTL ordering: column 0 is rightmost
        const cellLeft = pageW - margin - (cIdx + 1) * colW;
        doc.text(prepareArabicPdfText(h), cellLeft + colW / 2, y + 5.3, { align: 'center' });
      });
      y += 8;
    };

    ensureSpace(16);
    drawTableHeader();

    table.rows.forEach((row, rIdx) => {
      const wrappedCells = row.map((cell) => wrapLogicalText(String(cell ?? '-'), maxCharsPerCol));
      const maxLines = Math.max(...wrappedCells.map((l) => l.length), 1);
      const rowH = Math.max(6.8, maxLines * 4.4 + 2.4);

      if (ensureSpace(rowH + 2)) {
        drawTableHeader();
      }

      if (rIdx % 2 === 1) {
        doc.setFillColor(248, 250, 252);
        doc.rect(margin, y, contentW, rowH, 'F');
      }
      doc.setDrawColor(226, 232, 240);
      doc.rect(margin, y, contentW, rowH, 'S');

      doc.setTextColor(30, 41, 59);
      doc.setFontSize(8);

      wrappedCells.forEach((lines, cIdx) => {
        const cellLeft = pageW - margin - (cIdx + 1) * colW;
        const alignPref = table.alignments?.[cIdx] || 'center';
        lines.forEach((ln, lineIdx) => {
          const ty = y + 4.4 + lineIdx * 4.4;
          if (alignPref === 'right') {
            doc.text(prepareArabicPdfText(ln), cellLeft + colW - 2, ty, { align: 'right' });
          } else if (alignPref === 'left') {
            doc.text(prepareArabicPdfText(ln), cellLeft + 2, ty, { align: 'left' });
          } else {
            doc.text(prepareArabicPdfText(ln), cellLeft + colW / 2, ty, { align: 'center' });
          }
        });
      });

      y += rowH;
    });

    if (table.totals && table.totals.length > 0) {
      ensureSpace(9);
      doc.setFillColor(254, 243, 199);
      doc.setDrawColor(217, 119, 6);
      doc.rect(margin, y, contentW, 8, 'FD');
      doc.setTextColor(120, 53, 15);
      doc.setFontSize(8.5);
      table.totals.forEach((tot, cIdx) => {
        const cellLeft = pageW - margin - (cIdx + 1) * colW;
        doc.text(prepareArabicPdfText(String(tot ?? '')), cellLeft + colW / 2, y + 5.2, { align: 'center' });
      });
      y += 9;
    }

    y += 4;
  }

  // Notes & Signatures block
  if (options.notes) {
    ensureSpace(16);
    doc.setFillColor(240, 253, 244);
    doc.setDrawColor(187, 247, 208);
    doc.rect(margin, y, contentW, 10, 'FD');
    doc.setTextColor(22, 101, 52);
    doc.setFontSize(8.5);
    doc.text(prepareArabicPdfText(`ملاحظات: ${options.notes}`), pageW - margin - 4, y + 6.5, { align: 'right' });
    y += 14;
  }

  ensureSpace(22);
  const sigW = contentW / 3;
  const sigTitles = ['إعداد / المحاسب', 'المراجعة والتدقيق', 'اعتماد الإدارة'];
  const sigNames = [options.preparedBy || 'المحاسب المالي', 'رئيس الحسابات', 'المدير العام'];
  sigTitles.forEach((title, idx) => {
    const sx = pageW - margin - (idx + 1) * sigW;
    doc.setDrawColor(203, 213, 225);
    doc.rect(sx + 2, y, sigW - 4, 16, 'S');
    doc.setTextColor(71, 85, 105);
    doc.setFontSize(8);
    doc.text(prepareArabicPdfText(title), sx + sigW / 2, y + 5, { align: 'center' });
    doc.setTextColor(15, 23, 42);
    doc.text(prepareArabicPdfText(sigNames[idx]), sx + sigW / 2, y + 13, { align: 'center' });
  });

  // Page numbers & footer on every page
  const totalPages = doc.getNumberOfPages();
  const stamp = new Date().toISOString().slice(0, 16).replace('T', ' ');
  for (let p = 1; p <= totalPages; p++) {
    doc.setPage(p);
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, pageH - 11, pageW - margin, pageH - 11);
    doc.setTextColor(100, 116, 139);
    doc.setFontSize(7.5);
    doc.text(
      prepareArabicPdfText(`المنصور للأنظمة المالية الذكية ERP  |  ${stamp}`),
      pageW - margin,
      pageH - 6.5,
      { align: 'right' }
    );
    doc.text(
      prepareArabicPdfText(`صفحة ${p} من ${totalPages}`),
      margin,
      pageH - 6.5,
      { align: 'left' }
    );
  }

  const ab = doc.output('arraybuffer');
  return new Uint8Array(ab);
}

/**
 * Generates a genuine binary PDF document for Sales / Purchase / Return Invoices.
 */
export async function buildInvoicePdfBytes(
  invoice: Invoice,
  company?: Company,
  branch?: Branch,
  warehouseName?: string
): Promise<Uint8Array> {
  const docLabel =
    invoice.type === 'مبيعات'
      ? 'فاتورة مبيعات'
      : invoice.type === 'مشتريات'
      ? 'فاتورة مشتريات'
      : invoice.type === 'مرتجع_مبيعات'
      ? 'إشعار مرتجع مبيعات'
      : 'إشعار مرتجع مشتريات';

  const statusLabel =
    invoice.status === 'posted'
      ? 'مرحلة / معتمدة'
      : invoice.status === 'paid'
      ? 'مدفوعة بالكامل'
      : invoice.status === 'partial'
      ? 'مدفوعة جزئياً'
      : invoice.status === 'cancelled'
      ? 'ملغاة / معكوسة'
      : 'مسودة';

  const partyLabel =
    invoice.type === 'مشتريات' || invoice.type === 'مرتجع_مشتريات' ? 'المورد' : 'العميل';

  const rows = invoice.items.map((item, idx) => [
    String(idx + 1),
    item.itemName,
    item.unit,
    String(item.quantity + (item.bonusQuantity ? ` (+${item.bonusQuantity})` : '')),
    `${pdfNum(item.unitPrice)}`,
    `${pdfNum(item.discountAmount)}`,
    `${pdfNum(item.taxAmount)}`,
    `${pdfNum(item.total)} ${invoice.currency}`,
  ]);

  return buildReportPdfBytes({
    title: `${docLabel} #${invoice.invoiceNumber}`,
    subtitle: `${partyLabel}: ${invoice.entityName}`,
    reportCode: invoice.invoiceNumber,
    periodText: invoice.date,
    company,
    branch,
    preparedBy: invoice.createdBy || 'مسؤول المبيعات',
    notes: invoice.notes,
    metadata: {
      'رقم المستند': invoice.invoiceNumber,
      'التاريخ': invoice.date,
      [partyLabel]: invoice.entityName,
      'نوع الدفع': invoice.paymentType,
      'العملة وسعر الصرف': `${invoice.currency} (${invoice.exchangeRate})`,
      'المستودع': warehouseName || invoice.warehouseId,
      'الحالة': statusLabel,
      'الرصيد السابق':
        invoice.previousBalanceSnapshot !== undefined
          ? `${pdfNum(invoice.previousBalanceSnapshot)} YER`
          : '-',
      'الرصيد بعد الفاتورة':
        invoice.newBalanceSnapshot !== undefined
          ? `${pdfNum(invoice.newBalanceSnapshot)} YER`
          : '-',
    },
    tables: [
      {
        title: 'بنود الفاتورة التفصيلية',
        headers: ['#', 'اسم الصنف', 'الوحدة', 'الكمية', 'سعر الوحدة', 'الخصم', 'الضريبة', 'الإجمالي'],
        rows,
        alignments: ['center', 'right', 'center', 'center', 'center', 'center', 'center', 'center'],
        totals: [
          '',
          'الإجماليات',
          '',
          String(invoice.items.reduce((s, i) => s + i.quantity + (i.bonusQuantity || 0), 0)),
          '',
          pdfNum(invoice.discountTotal),
          pdfNum(invoice.taxTotal),
          `${pdfNum(invoice.grandTotal)} ${invoice.currency}`,
        ],
      },
      {
        title: 'ملخص السداد والاستحقاق',
        headers: ['المجموع الفرعي', 'الخصم', 'الضريبة', 'الصافي النهائي', 'المدفوع', 'المتبقي'],
        rows: [
          [
            `${pdfNum(invoice.subtotal)} ${invoice.currency}`,
            `${pdfNum(invoice.discountTotal)} ${invoice.currency}`,
            `${pdfNum(invoice.taxTotal)} ${invoice.currency}`,
            `${pdfNum(invoice.grandTotal)} ${invoice.currency}`,
            `${pdfNum(invoice.paidAmount)} ${invoice.currency}`,
            `${pdfNum(invoice.remainingAmount)} ${invoice.currency}`,
          ],
        ],
        alignments: ['center', 'center', 'center', 'center', 'center', 'center'],
      },
    ],
  });
}

/**
 * Generates a genuine binary PDF document for Receipt / Payment Vouchers.
 */
export async function buildVoucherPdfBytes(
  voucher: PaymentVoucher,
  company?: Company,
  branch?: Branch
): Promise<Uint8Array> {
  const title = voucher.type === 'قبض' ? `سند قبض مالي #${voucher.voucherNumber}` : `سند صرف مالي #${voucher.voucherNumber}`;
  return buildReportPdfBytes({
    title,
    subtitle: `${voucher.entityType}: ${voucher.entityName}`,
    reportCode: voucher.voucherNumber,
    periodText: voucher.date,
    company,
    branch,
    preparedBy: voucher.createdBy || 'أمين الصندوق',
    notes: voucher.statement,
    metadata: {
      'رقم السند': voucher.voucherNumber,
      'نوع السند': voucher.type === 'قبض' ? 'سند قبض' : 'سند صرف',
      'التاريخ': voucher.date,
      'الطرف / الحساب': `${voucher.entityType} - ${voucher.entityName}`,
      'الخزينة / البنك': voucher.treasuryAccountName,
      'طريقة الدفع': voucher.paymentMethod.replace(/_/g, ' '),
      'العملة وسعر الصرف': `${voucher.currency} (${voucher.exchangeRate})`,
      'الحالة': voucher.status === 'posted' ? 'مرحل ومعتمد' : 'ملغى',
      'المستلم / المحصل': voucher.receivedOrPaidBy || '-',
    },
    tables: [
      {
        title: 'بيانات القيمة المالية للسند',
        headers: ['رقم السند', 'البيان', 'المبلغ بالعملة', 'المعادل بالأساس (YER)', 'المرجع'],
        rows: [
          [
            voucher.voucherNumber,
            voucher.statement || '-',
            `${pdfNum(voucher.amount)} ${voucher.currency}`,
            `${pdfNum(voucher.baseAmount)} YER`,
            voucher.linkedInvoiceNumber || voucher.checkNumber || voucher.transferReference || '-',
          ],
        ],
        alignments: ['center', 'right', 'center', 'center', 'center'],
      },
    ],
  });
}
