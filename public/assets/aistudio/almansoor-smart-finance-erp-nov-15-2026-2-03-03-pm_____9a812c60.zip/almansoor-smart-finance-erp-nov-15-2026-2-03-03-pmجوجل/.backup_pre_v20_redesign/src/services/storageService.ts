/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * ALMANSOOR SMART FINANCE ERP - Storage, Migration, Validation & Numbering Service
 */

import {
  Company,
  Branch,
  Warehouse,
  Currency,
  RegionalArea,
  Customer,
  Vendor,
  UnitOfMeasure,
  InventoryItem,
  ItemWarehouseStock,
  StockMovement,
  InventoryTransfer,
  PhysicalStocktaking,
  WarehouseDocument,
  DispatchLogEntry,
  Account,
  CostCenter,
  JournalEntry,
  Invoice,
  TreasuryAccount,
  PaymentVoucher,
  TreasuryTransfer,
  ExpenseCategory,
  ExpenseRecord,
  Employee,
  PayrollRun,
  FixedAsset,
  User,
  AuditLogEntry,
  TaskAlert,
  SystemSettings,
  CustomLedgerBook,
  CustomLedgerEntry,
} from '../types/erp';

import {
  initialCompany,
  initialCurrencies,
  initialBranches,
  initialWarehouses,
  initialRegionalAreas,
  initialCustomers,
  initialVendors,
  initialInventoryItems,
  initialWarehouseStock,
  initialChartOfAccounts,
  initialCostCenters,
  initialTreasuryAccounts,
  initialJournalEntries,
  initialInvoices,
  initialPaymentVouchers,
  initialStockMovements,
  initialExpenseCategories,
  initialExpenseRecords,
  initialEmployees,
  initialPayrollRuns,
  initialFixedAssets,
  initialUsers,
  initialTaskAlerts,
  initialSystemSettings,
} from '../data/initialData';

export const CURRENT_SCHEMA_VERSION = '2.0.0';

export const defaultUnitsOfMeasure: UnitOfMeasure[] = [
  { id: 'uom-01', nameAr: 'حبة', symbolAr: 'حبة', isBase: true, factorToBase: 1 },
  { id: 'uom-02', nameAr: 'كرتون', symbolAr: 'كرتون', isBase: false, factorToBase: 12 },
  { id: 'uom-03', nameAr: 'شدة', symbolAr: 'شدة', isBase: false, factorToBase: 6 },
  { id: 'uom-04', nameAr: 'كيلوجرام', symbolAr: 'كجم', isBase: true, factorToBase: 1 },
  { id: 'uom-05', nameAr: 'متر', symbolAr: 'م', isBase: true, factorToBase: 1 },
];

export const defaultCustomBooks: CustomLedgerBook[] = [
  {
    id: 'book-01',
    code: 'BK-01',
    nameAr: 'دفتر العهد والسلف والمصروفات النثرية',
    description: 'سجل مساعد لمتابعة العهد اليومية والتسويات الإدارية الميدانية',
    createdAt: '2026-01-01',
  },
];

export interface ERPDatabase {
  schemaVersion?: string;
  company: Company;
  currencies: Currency[];
  branches: Branch[];
  warehouses: Warehouse[];
  regionalAreas: RegionalArea[];
  customers: Customer[];
  vendors: Vendor[];
  unitsOfMeasure?: UnitOfMeasure[];
  inventoryItems: InventoryItem[];
  warehouseStock: ItemWarehouseStock[];
  stockMovements: StockMovement[];
  inventoryTransfers: InventoryTransfer[];
  stocktakings: PhysicalStocktaking[];
  warehouseDocuments: WarehouseDocument[];
  chartOfAccounts: Account[];
  costCenters: CostCenter[];
  journalEntries: JournalEntry[];
  invoices: Invoice[];
  treasuryAccounts: TreasuryAccount[];
  paymentVouchers: PaymentVoucher[];
  treasuryTransfers: TreasuryTransfer[];
  expenseCategories: ExpenseCategory[];
  expenseRecords: ExpenseRecord[];
  employees: Employee[];
  payrollRuns: PayrollRun[];
  fixedAssets: FixedAsset[];
  customBooks?: CustomLedgerBook[];
  customBookEntries?: CustomLedgerEntry[];
  users: User[];
  auditLogs: AuditLogEntry[];
  taskAlerts: TaskAlert[];
  dispatchLogs: DispatchLogEntry[];
  settings: SystemSettings;
}

const STORAGE_KEY = 'almansoor_erp_database_v1';
const IDB_NAME = 'AlmansoorSmartFinanceERP';
const IDB_STORE = 'database';

/**
 * Generates sequential, collision-free document numbers given a prefix and existing document numbers.
 */
export function generateNextDocNumber(
  prefix: string,
  existingNumbers: string[],
  padLength: number = 4
): string {
  let maxSeq = 0;
  const escaped = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const exactRegex = new RegExp(`^${escaped}(\\d+)$`);

  for (const num of existingNumbers) {
    if (!num) continue;
    const match = exactRegex.exec(num.trim());
    if (match) {
      const parsed = parseInt(match[1], 10);
      if (!Number.isNaN(parsed) && parsed > maxSeq) {
        maxSeq = parsed;
      }
      continue;
    }
    if (num.startsWith(prefix)) {
      const tailMatch = /(\d+)$/.exec(num);
      if (tailMatch) {
        const parsed = parseInt(tailMatch[1], 10);
        if (!Number.isNaN(parsed) && parsed > maxSeq) {
          maxSeq = parsed;
        }
      }
    }
  }

  let candidateSeq = maxSeq + 1;
  const existingSet = new Set(existingNumbers.map((n) => (n || '').trim()));
  let candidate = `${prefix}${String(candidateSeq).padStart(padLength, '0')}`;
  while (existingSet.has(candidate)) {
    candidateSeq += 1;
    candidate = `${prefix}${String(candidateSeq).padStart(padLength, '0')}`;
  }
  return candidate;
}

/**
 * Ensures critical COA accounts and newly introduced collections/settings exist when migrating older databases or backups.
 */
export function migrateDatabase(raw: Partial<ERPDatabase>): ERPDatabase {
  const defaultDb = getInitialDatabase();

  const existingAccounts = Array.isArray(raw.chartOfAccounts) && raw.chartOfAccounts.length > 0
    ? [...raw.chartOfAccounts]
    : [...defaultDb.chartOfAccounts];

  const requiredCoaIds = ['acc-4190', 'acc-5340', 'acc-5390'];
  for (const reqId of requiredCoaIds) {
    const defAcc = defaultDb.chartOfAccounts.find((a) => a.id === reqId);
    if (defAcc && !existingAccounts.some((a) => a.id === defAcc.id || a.code === defAcc.code)) {
      existingAccounts.push(defAcc);
    }
  }

  const rawSettings = (raw.settings || {}) as Partial<SystemSettings>;
  const mergedSettings: SystemSettings = {
    ...defaultDb.settings,
    ...rawSettings,
    whatsappTemplates: {
      ...defaultDb.settings.whatsappTemplates!,
      ...(rawSettings.whatsappTemplates || {}),
    },
    paymentMethods:
      Array.isArray(rawSettings.paymentMethods) && rawSettings.paymentMethods.length > 0
        ? rawSettings.paymentMethods
        : defaultDb.settings.paymentMethods,
    uiPreferences: {
      ...defaultDb.settings.uiPreferences!,
      ...(rawSettings.uiPreferences || {}),
      hiddenModules: Array.isArray(rawSettings.uiPreferences?.hiddenModules)
        ? rawSettings.uiPreferences.hiddenModules
        : defaultDb.settings.uiPreferences!.hiddenModules,
      tableColumnPrefs:
        rawSettings.uiPreferences?.tableColumnPrefs && typeof rawSettings.uiPreferences.tableColumnPrefs === 'object'
          ? rawSettings.uiPreferences.tableColumnPrefs
          : {},
    },
  };

  return {
    schemaVersion: CURRENT_SCHEMA_VERSION,
    company: raw.company || defaultDb.company,
    currencies: Array.isArray(raw.currencies) && raw.currencies.length > 0 ? raw.currencies : defaultDb.currencies,
    branches: Array.isArray(raw.branches) && raw.branches.length > 0 ? raw.branches : defaultDb.branches,
    warehouses: Array.isArray(raw.warehouses) && raw.warehouses.length > 0 ? raw.warehouses : defaultDb.warehouses,
    regionalAreas: Array.isArray(raw.regionalAreas) ? raw.regionalAreas : defaultDb.regionalAreas,
    customers: Array.isArray(raw.customers) ? raw.customers : defaultDb.customers,
    vendors: Array.isArray(raw.vendors) ? raw.vendors : defaultDb.vendors,
    unitsOfMeasure:
      Array.isArray(raw.unitsOfMeasure) && raw.unitsOfMeasure.length > 0
        ? raw.unitsOfMeasure
        : defaultUnitsOfMeasure,
    inventoryItems: Array.isArray(raw.inventoryItems) ? raw.inventoryItems : defaultDb.inventoryItems,
    warehouseStock: Array.isArray(raw.warehouseStock) ? raw.warehouseStock : defaultDb.warehouseStock,
    stockMovements: Array.isArray(raw.stockMovements) ? raw.stockMovements : defaultDb.stockMovements,
    inventoryTransfers: Array.isArray(raw.inventoryTransfers) ? raw.inventoryTransfers : [],
    stocktakings: Array.isArray(raw.stocktakings) ? raw.stocktakings : [],
    warehouseDocuments: Array.isArray(raw.warehouseDocuments)
      ? raw.warehouseDocuments
      : defaultDb.warehouseDocuments,
    chartOfAccounts: existingAccounts,
    costCenters: Array.isArray(raw.costCenters) ? raw.costCenters : defaultDb.costCenters,
    journalEntries: Array.isArray(raw.journalEntries) ? raw.journalEntries : defaultDb.journalEntries,
    invoices: Array.isArray(raw.invoices) ? raw.invoices : defaultDb.invoices,
    treasuryAccounts: Array.isArray(raw.treasuryAccounts) ? raw.treasuryAccounts : defaultDb.treasuryAccounts,
    paymentVouchers: Array.isArray(raw.paymentVouchers) ? raw.paymentVouchers : defaultDb.paymentVouchers,
    treasuryTransfers: Array.isArray(raw.treasuryTransfers) ? raw.treasuryTransfers : [],
    expenseCategories: Array.isArray(raw.expenseCategories) ? raw.expenseCategories : defaultDb.expenseCategories,
    expenseRecords: Array.isArray(raw.expenseRecords) ? raw.expenseRecords : defaultDb.expenseRecords,
    employees: Array.isArray(raw.employees) ? raw.employees : defaultDb.employees,
    payrollRuns: Array.isArray(raw.payrollRuns) ? raw.payrollRuns : defaultDb.payrollRuns,
    fixedAssets: Array.isArray(raw.fixedAssets) ? raw.fixedAssets : defaultDb.fixedAssets,
    customBooks:
      Array.isArray(raw.customBooks) && raw.customBooks.length > 0 ? raw.customBooks : defaultCustomBooks,
    customBookEntries: Array.isArray(raw.customBookEntries) ? raw.customBookEntries : [],
    users: Array.isArray(raw.users) && raw.users.length > 0 ? raw.users : defaultDb.users,
    auditLogs: Array.isArray(raw.auditLogs) ? raw.auditLogs : defaultDb.auditLogs,
    taskAlerts: Array.isArray(raw.taskAlerts) ? raw.taskAlerts : defaultDb.taskAlerts,
    dispatchLogs: Array.isArray(raw.dispatchLogs) ? raw.dispatchLogs : defaultDb.dispatchLogs,
    settings: mergedSettings,
  };
}

/**
 * Strict backup validator before restoring any JSON file. Never mutates existing database on failure.
 */
export function validateBackupPayload(rawText: string): {
  valid: boolean;
  db?: ERPDatabase;
  error?: string;
  stats?: {
    accounts: number;
    invoices: number;
    vouchers: number;
    customers: number;
    vendors: number;
    items: number;
    journalEntries: number;
    stocktakings: number;
  };
} {
  if (!rawText || typeof rawText !== 'string' || rawText.trim().length < 2) {
    return { valid: false, error: 'ملف النسخة الاحتياطية فارغ أو غير مقروء.' };
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(rawText);
  } catch {
    return { valid: false, error: 'صيغة JSON غير صالحة في ملف النسخة الاحتياطية.' };
  }

  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return { valid: false, error: 'بنية ملف النسخة الاحتياطية لا تطابق كائن قاعدة البيانات.' };
  }

  const obj = parsed as Partial<ERPDatabase>;

  if (!obj.company || typeof obj.company !== 'object' || !obj.company.nameAr) {
    return { valid: false, error: 'بيانات المؤسسة (company) مفقودة أو غير مكتملة.' };
  }

  const requiredArrays: (keyof ERPDatabase)[] = [
    'chartOfAccounts',
    'invoices',
    'customers',
    'vendors',
    'inventoryItems',
    'treasuryAccounts',
    'journalEntries',
  ];

  for (const key of requiredArrays) {
    if (!Array.isArray(obj[key])) {
      return { valid: false, error: `الجدول الأساسي (${String(key)}) مفقود أو تالف في النسخة الاحتياطية.` };
    }
  }

  if ((obj.chartOfAccounts?.length || 0) === 0) {
    return { valid: false, error: 'شجرة الحسابات فارغة ولا يمكن اعتماد نسخة بدون دليل حسابات.' };
  }

  // Referential & numeric sanity checks
  const hasInvalidTreasury = obj.treasuryAccounts?.some(
    (t) => !t.id || !t.nameAr || !Number.isFinite(Number(t.balance))
  );
  if (hasInvalidTreasury) {
    return { valid: false, error: 'توجد حسابات خزينة بأرصدة رقمية غير صالحة.' };
  }

  const hasInvalidInvoices = obj.invoices?.some(
    (inv) => !inv.id || !inv.invoiceNumber || !Number.isFinite(Number(inv.grandTotal))
  );
  if (hasInvalidInvoices) {
    return { valid: false, error: 'توجد فواتير مفقودة المعرف أو بقيم رقمية غير صالحة.' };
  }

  const migrated = migrateDatabase(obj);

  return {
    valid: true,
    db: migrated,
    stats: {
      accounts: migrated.chartOfAccounts.length,
      invoices: migrated.invoices.length,
      vouchers: migrated.paymentVouchers.length,
      customers: migrated.customers.length,
      vendors: migrated.vendors.length,
      items: migrated.inventoryItems.length,
      journalEntries: migrated.journalEntries.length,
      stocktakings: migrated.stocktakings.length,
    },
  };
}

function openIDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB unavailable'));
      return;
    }
    const req = indexedDB.open(IDB_NAME, 1);
    req.onupgradeneeded = () => {
      const idb = req.result;
      if (!idb.objectStoreNames.contains(IDB_STORE)) {
        idb.createObjectStore(IDB_STORE);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function saveDatabaseToIDB(data: ERPDatabase): Promise<void> {
  try {
    const idb = await openIDB();
    await new Promise<void>((resolve, reject) => {
      const tx = idb.transaction(IDB_STORE, 'readwrite');
      tx.objectStore(IDB_STORE).put(data, STORAGE_KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    idb.close();
  } catch (err) {
    console.warn('IndexedDB save skipped:', err);
  }
}

export async function loadDatabaseFromIDB(): Promise<ERPDatabase | null> {
  try {
    const idb = await openIDB();
    const result = await new Promise<ERPDatabase | null>((resolve, reject) => {
      const tx = idb.transaction(IDB_STORE, 'readonly');
      const req = tx.objectStore(IDB_STORE).get(STORAGE_KEY);
      req.onsuccess = () => resolve((req.result as ERPDatabase) || null);
      req.onerror = () => reject(req.error);
    });
    idb.close();
    if (!result || !result.company) return null;
    return migrateDatabase(result);
  } catch (err) {
    console.warn('IndexedDB load skipped:', err);
    return null;
  }
}

export async function clearDatabaseIDB(): Promise<void> {
  try {
    const idb = await openIDB();
    await new Promise<void>((resolve, reject) => {
      const tx = idb.transaction(IDB_STORE, 'readwrite');
      tx.objectStore(IDB_STORE).delete(STORAGE_KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    idb.close();
  } catch {
    // ignore
  }
}

export function getInitialDatabase(): ERPDatabase {
  return {
    schemaVersion: CURRENT_SCHEMA_VERSION,
    company: initialCompany,
    currencies: initialCurrencies,
    branches: initialBranches,
    warehouses: initialWarehouses,
    regionalAreas: initialRegionalAreas,
    customers: initialCustomers,
    vendors: initialVendors,
    unitsOfMeasure: defaultUnitsOfMeasure,
    inventoryItems: initialInventoryItems,
    warehouseStock: initialWarehouseStock,
    stockMovements: initialStockMovements,
    inventoryTransfers: [],
    stocktakings: [],
    warehouseDocuments: [
      {
        id: 'wdoc-01',
        documentNumber: 'GRN-2026-0001',
        type: 'إذن_توريد',
        date: '2026-01-20',
        warehouseId: 'wh-01',
        beneficiaryOrSupplier: 'شركة الشروق لاستيراد التقنية والإلكترونيات',
        referenceNumber: 'PUR-2026-001',
        reason: 'استلام وتوريد شحنة لابتوبات جديدة',
        items: [
          {
            id: 'wdi-01',
            itemId: 'item-01',
            itemName: 'لابتوب ديل للأعمال Dell Latitude Pro Core-i7',
            unit: 'حبة',
            quantity: 10,
            unitCost: 380000,
            totalCost: 3800000,
            notes: 'تم الفحص الفني والمطابقة بالمستودع المركزي',
          },
        ],
        totalQuantity: 10,
        totalCost: 3800000,
        status: 'posted',
        performedBy: 'فهد العبسي (أمين المستودع)',
        approvedBy: 'م. سامي النهاري',
        notes: 'تم الفحص المخزني ومطابقة الباركود والأرقام التسلسلية',
        createdAt: '2026-01-20T10:00:00Z',
      },
      {
        id: 'wdoc-02',
        documentNumber: 'GIN-2026-0001',
        type: 'إذن_صرف',
        date: '2026-02-10',
        warehouseId: 'wh-01',
        beneficiaryOrSupplier: 'شركة المجد للتجارة العامة والاستيراد',
        referenceNumber: 'INV-2026-001',
        reason: 'صرف بضاعة فاتورة مبيعات',
        items: [
          {
            id: 'wdi-02',
            itemId: 'item-01',
            itemName: 'لابتوب ديل للأعمال Dell Latitude Pro',
            unit: 'حبة',
            quantity: 3,
            unitCost: 380000,
            totalCost: 1140000,
          },
          {
            id: 'wdi-03',
            itemId: 'item-02',
            itemName: 'طابعة إبسون نقطية حرارية للفواتير Epson TM-T88VI',
            unit: 'حبة',
            quantity: 6,
            unitCost: 85000,
            totalCost: 510000,
          },
        ],
        totalQuantity: 9,
        totalCost: 1650000,
        status: 'posted',
        performedBy: 'فهد العبسي (أمين المستودع)',
        approvedBy: 'عصام الشرعبي',
        notes: 'تم تسليم الأجهزة للمندوب بحالة ممتازة',
        createdAt: '2026-02-10T14:30:00Z',
      },
    ],
    chartOfAccounts: initialChartOfAccounts,
    costCenters: initialCostCenters,
    journalEntries: initialJournalEntries,
    invoices: initialInvoices,
    treasuryAccounts: initialTreasuryAccounts,
    paymentVouchers: initialPaymentVouchers,
    treasuryTransfers: [],
    expenseCategories: initialExpenseCategories,
    expenseRecords: initialExpenseRecords,
    employees: initialEmployees,
    payrollRuns: initialPayrollRuns,
    fixedAssets: initialFixedAssets,
    customBooks: defaultCustomBooks,
    customBookEntries: [],
    users: initialUsers,
    auditLogs: [
      {
        id: 'log-01',
        timestamp: new Date().toISOString(),
        userId: 'usr-01',
        userName: 'عبد الرحمن المنصور (المالك)',
        action: 'تسجيل_دخول',
        module: 'المحاسبة',
        details: 'بدء تشغيل النظام والتحقق من سلامة الأرصدة الافتتاحية والمخزون',
      },
    ],
    taskAlerts: initialTaskAlerts,
    dispatchLogs: [
      {
        id: 'disp-01',
        timestamp: new Date().toISOString(),
        recipientType: 'management',
        recipientName: 'عبد الرحمن المنصور (المدير العام)',
        recipientPhone: '+967 770001111',
        channel: 'whatsapp',
        reportType: 'daily_management',
        status: 'sent',
        details: 'إرسال التقرير الإداري اليومي الشامل للإدارة العليا',
        retryCount: 0,
      },
    ],
    settings: initialSystemSettings,
  };
}

export function loadDatabase(): ERPDatabase {
  try {
    if (typeof localStorage === 'undefined') {
      return getInitialDatabase();
    }
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const initial = getInitialDatabase();
      saveDatabase(initial);
      return initial;
    }
    const parsed = JSON.parse(raw) as Partial<ERPDatabase>;
    return migrateDatabase(parsed);
  } catch (err) {
    console.error('Failed to load database from LocalStorage, falling back to initial data:', err);
    return getInitialDatabase();
  }
}

export function saveDatabase(data: ERPDatabase): void {
  void saveDatabaseToIDB(data);
  if (typeof localStorage === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (err) {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // ignore
    }
    console.warn('LocalStorage quota exceeded, persisted safely in IndexedDB instead.', err);
  }
}

export function resetToDemoDatabase(): ERPDatabase {
  const initial = getInitialDatabase();
  void clearDatabaseIDB();
  saveDatabase(initial);
  return initial;
}

export function exportDatabaseBackup(db: ERPDatabase): void {
  const payload: ERPDatabase = {
    ...db,
    schemaVersion: CURRENT_SCHEMA_VERSION,
  };
  const jsonStr = JSON.stringify(payload, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const dateStr = new Date().toISOString().split('T')[0];
  a.download = `almansoor-erp-backup-${dateStr}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
