/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * ALMANSOOR SMART FINANCE ERP - Express Server + Server-Side Gemini AI Solutions + Vite Middleware
 */

import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import express, { type Request, type Response } from 'express';
import { GoogleGenAI, Type } from '@google/genai';

const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = (process.env.GEMINI_API_KEY || '').trim();
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function startServer(): Promise<void> {
  const app = express();
  app.use(express.json({ limit: '2mb' }));

  // Health & readiness endpoint
  app.get('/api/health', (_req: Request, res: Response) => {
    const apiKey = (process.env.GEMINI_API_KEY || '').trim();
    const aiConfigured = Boolean(apiKey && apiKey !== 'MY_GEMINI_API_KEY');
    res.json({
      ok: true,
      service: 'almansoor-erp-server',
      aiConfigured,
      timestamp: new Date().toISOString(),
    });
  });

  // Server-Side Smart ERP Solutions Advisor via Gemini AI
  app.post('/api/ai/analyze', async (req: Request, res: Response) => {
    try {
      const ai = getGeminiClient();
      if (!ai) {
        res.status(503).json({
          error:
            'خدمة التحليل الذكي بالذكاء الاصطناعي غير مفعّلة حالياً لعدم توفر GEMINI_API_KEY في إعدادات الخادم. يمكنك الاعتماد على الفاحص المحلي الفوري للنظام.',
          code: 'AI_KEY_MISSING',
        });
        return;
      }

      const body = (req.body || {}) as {
        lang?: 'ar' | 'en';
        question?: string;
        snapshot?: Record<string, unknown>;
        localFindings?: Array<Record<string, unknown>>;
      };

      const lang = body.lang === 'en' ? 'en' : 'ar';
      const question = String(body.question || '').trim().slice(0, 1200);
      const snapshotJson = JSON.stringify(body.snapshot || {}, null, 2).slice(0, 14000);
      const findingsJson = JSON.stringify((body.localFindings || []).slice(0, 15), null, 2).slice(0, 8000);

      const responseLanguageDirective =
        lang === 'en'
          ? 'Respond strictly in clear professional financial English.'
          : 'أجب باللغة العربية الفصحى المحاسبية الواضحة والمختصرة والعملية.';

      const prompt = [
        'You are a Principal ERP Financial & Inventory Solutions Architect for ALMANSOOR SMART FINANCE ERP.',
        'Analyze the live ERP telemetry snapshot and deterministic audit findings below, then produce accurate, concrete, actionable solutions grounded strictly in the provided figures (never invent account codes, customer names, or amounts that are not in the data).',
        responseLanguageDirective,
        '',
        '### Live ERP Snapshot (Base currency YER & SAR conversion context):',
        snapshotJson,
        '',
        '### Deterministic Local Scanner Findings:',
        findingsJson,
        '',
        question
          ? `### User Question / Specific Request:\n${question}`
          : '### Task:\nProvide an executive diagnosis of financial health, cashflow/currency exposure (SAR/YER), receivables risk, and inventory bottlenecks with concrete step-by-step solutions inside the ERP.',
      ].join('\n');

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              executiveSummary: { type: Type.STRING },
              overallRisk: { type: Type.STRING, enum: ['low', 'moderate', 'high', 'critical'] },
              directAnswer: { type: Type.STRING },
              solutions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    priority: { type: Type.STRING, enum: ['critical', 'high', 'medium', 'low'] },
                    category: {
                      type: Type.STRING,
                      enum: ['accounting', 'liquidity', 'receivables', 'inventory', 'currency', 'operations'],
                    },
                    rootCause: { type: Type.STRING },
                    actionSteps: {
                      type: Type.ARRAY,
                      items: { type: Type.STRING },
                    },
                    expectedImpact: { type: Type.STRING },
                    targetModule: {
                      type: Type.STRING,
                      enum: [
                        'accounting',
                        'treasury',
                        'inventory',
                        'customers',
                        'vendors',
                        'sales',
                        'purchases',
                        'expenses',
                        'reports',
                        'settings',
                      ],
                    },
                  },
                  required: ['title', 'priority', 'category', 'rootCause', 'actionSteps', 'expectedImpact', 'targetModule'],
                },
              },
            },
            required: ['executiveSummary', 'overallRisk', 'directAnswer', 'solutions'],
          },
        },
      });

      const rawText = response.text || '';
      const parsed = JSON.parse(rawText);
      res.json({
        ok: true,
        analysis: parsed,
        generatedAt: new Date().toISOString(),
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Unexpected AI server error';
      const status =
        /429|quota|rate/i.test(msg) ? 429 : /401|403|permission|key/i.test(msg) ? 403 : /400|invalid/i.test(msg) ? 400 : 500;
      res.status(status).json({
        error: msg,
        code: status === 429 ? 'RATE_LIMIT' : status === 403 ? 'AUTH_ERROR' : 'AI_FAILURE',
      });
    }
  });

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve('dist');
    app.use(express.static(distDir));
    app.get('/{*path}', (_req: Request, res: Response) => {
      const indexFile = path.join(distDir, 'index.html');
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send('Build output not found. Run npm run build first.');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ALMANSOOR SMART FINANCE ERP Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start ERP server:', err);
  process.exit(1);
});
