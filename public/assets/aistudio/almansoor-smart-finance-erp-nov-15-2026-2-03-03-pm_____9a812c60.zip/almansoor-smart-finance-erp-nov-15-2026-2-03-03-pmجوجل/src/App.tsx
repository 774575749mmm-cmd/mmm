/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * ALMANSOOR SMART FINANCE ERP - V20 Enterprise Workspace Shell + Real Accounting/Inventory Engines
 */

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Bell,
  HelpCircle,
  RotateCcw,
  Landmark,
  Wallet,
  Building2,
  User as UserIcon,
  Coins,
  Globe,
  Sparkles,
  Search,
  Tag,
  ExternalLink,
  PlusSquare,
  ChevronDown,
} from 'lucide-react';
import {
  loadDatabase,
  loadDatabaseFromIDB,
  saveDatabase,
  resetToDemoDatabase,
  generateNextDocNumber,
  defaultTabsConfig,
  defaultDocumentBooks,
  ERPDatabase,
} from './services/storageService';
import {
  createSalesInvoiceJournalEntry,
  createPurchaseInvoiceJournalEntry,
  createVoucherJournalEntry,
  createExpenseJournalEntry,
  createStocktakingJournalEntry,
  createReversalJournalEntry,
  resolveAccount,
  validateJournalEntry,
} from './services/accountingEngine';
import { getEffectiveCurrencyRate } from './services/currencyHelpers';
import { AppLanguage, getTabLabel, syncDocumentLanguage, t } from './services/i18n';
import {
  executeInventoryTransfer,
  reverseInventoryTransfer,
  applyStocktakingAdjustments,
  updateWarehouseStock,
} from './services/inventoryEngine';
import {
  Invoice,
  Customer,
  Vendor,
  InventoryItem,
  PaymentVoucher,
  ExpenseRecord,
  Employee,
  PayrollRun,
  FixedAsset,
  Branch,
  Warehouse,
  UnitOfMeasure,
  Currency,
  User,
  TaskAlert,
  InventoryTransfer,
  TreasuryAccount,
  TreasuryTransfer,
  JournalEntry,
  WarehouseDocument,
  PhysicalStocktaking,
  DispatchLogEntry,
  CustomLedgerBook,
  CustomLedgerEntry,
  TableColumnPref,
  DocumentBook,
  DepartmentItem,
  RegionalArea,
  Account,
} from './types/erp';

// Common Modals & Banners
import { HelpModal, HelpTopic } from './components/common/HelpModal';
import { PrintModal, PrintableDocumentData } from './components/common/PrintModal';
import { ToastBanner, ToastMessage } from './components/common/ToastBanner';
import { ConfirmModal } from './components/common/ConfirmModal';
import { GlobalSearchModal } from './components/common/GlobalSearchModal';
import { CustomerItemPriceModal } from './components/common/CustomerItemPriceModal';
import { MdiWindowProvider, MdiFloatingFrame } from './components/common/MdiWindowManager';

// V20 Workbenches (8 Enterprise Tabs)
import { InvoiceWorkbench } from './components/modules/workbenches/InvoiceWorkbench';
import { VoucherWorkbench } from './components/modules/workbenches/VoucherWorkbench';
import { LedgersAccountingWorkbench } from './components/modules/workbenches/LedgersAccountingWorkbench';
import { InventoryWorkbench } from './components/modules/workbenches/InventoryWorkbench';
import { PartiesWorkbench } from './components/modules/workbenches/PartiesWorkbench';
import { ReportsWorkbench } from './components/modules/workbenches/ReportsWorkbench';
import { UnifiedOperationsWorkbench } from './components/modules/workbenches/UnifiedOperationsWorkbench';
import { SettingsWorkbench } from './components/modules/workbenches/SettingsWorkbench';

export type V20TabId =
  | 'tab-pos'
  | 'tab-bonds'
  | 'tab-ledgers'
  | 'tab-inventory'
  | 'tab-cust'
  | 'tab-reports'
  | 'tab-unified-coa'
  | 'tab-admin';

export type ReportsSubTabId =
  | 'v20_comp'
  | 'statement'
  | 'daily_customers'
  | 'hub_22'
  | 'daily_22'
  | 'unified_docs'
  | 'tasks_dispatch'
  | 'smart_ai';

export type UnifiedSubTabId = 'coa' | 'hr' | 'expenses' | 'assets' | 'directories';

export interface WorkspaceWindowInstance {
  id: string;
  tabId: V20TabId;
  title: string;
  focusedRecordId?: string;
  reportsSubTab?: ReportsSubTabId;
  unifiedSubTab?: UnifiedSubTabId;
  statementTarget?: { type: 'customer' | 'vendor'; id: string } | null;
}

export default function App() {
  const [db, setDb] = useState<ERPDatabase>(() => loadDatabase());
  const [activeTab, setActiveTab] = useState<V20TabId>('tab-pos');
  const [visitedTabs, setVisitedTabs] = useState<V20TabId[]>(['tab-pos']);
  const [floatingWindows, setFloatingWindows] = useState<WorkspaceWindowInstance[]>([]);
  const [isWinLauncherOpen, setIsWinLauncherOpen] = useState(false);

  const [focusedRecordId, setFocusedRecordId] = useState<string | undefined>(undefined);
  const [reportsSubTab, setReportsSubTab] = useState<ReportsSubTabId>('v20_comp');
  const [unifiedSubTab, setUnifiedSubTab] = useState<UnifiedSubTabId>('coa');
  const [statementTarget, setStatementTarget] = useState<{
    type: 'customer' | 'vendor';
    id: string;
  } | null>(null);

  // Active Contextual State
  const [currentBranch, setCurrentBranch] = useState<Branch>(() => db.branches[0]);
  const [currentCurrency, setCurrentCurrency] = useState<Currency>(() => db.currencies[0]);
  const [currentUser, setCurrentUser] = useState<User>(() => db.users[0]);

  const lang: AppLanguage = db.settings.language === 'en' ? 'en' : 'ar';

  const handleChangeLanguage = useCallback((nextLang: AppLanguage) => {
    setDb((prev) => ({
      ...prev,
      settings: {
        ...prev.settings,
        language: nextLang,
      },
    }));
  }, []);

  useEffect(() => {
    syncDocumentLanguage(lang);
  }, [lang]);

  // Keep every visited main tab mounted so drafts/filters are never lost on tab switch
  useEffect(() => {
    setVisitedTabs((prev) => (prev.includes(activeTab) ? prev : [...prev, activeTab]));
  }, [activeTab]);

  // Modals & Toasts
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [isGlobalSearchOpen, setIsGlobalSearchOpen] = useState(false);
  const [priceLookupModal, setPriceLookupModal] = useState<{
    open: boolean;
    customerId?: string;
    itemId?: string;
  }>({ open: false });
  const [printableDocs, setPrintableDocs] = useState<{ id: string; doc: PrintableDocumentData }[]>([]);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);

  const openPrintDocWindow = useCallback((doc: PrintableDocumentData) => {
    const id = `pdoc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setPrintableDocs((prev) => [...prev, { id, doc }]);
  }, []);

  const closePrintDocWindow = useCallback((id: string) => {
    setPrintableDocs((prev) => prev.filter((p) => p.id !== id));
  }, []);

  const spawnFloatingWindow = useCallback(
    (opts: Omit<WorkspaceWindowInstance, 'id'>) => {
      const id = `mdi-win-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      setFloatingWindows((prev) => [...prev, { ...opts, id }]);
      setIsWinLauncherOpen(false);
    },
    []
  );

  const closeFloatingWindow = useCallback((winId: string) => {
    setFloatingWindows((prev) => prev.filter((w) => w.id !== winId));
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsGlobalSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const notify = useCallback((type: 'success' | 'error' | 'info', message: string) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setToasts((prev) => [...prev.slice(-3), { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  }, []);

  // Hydrate from IndexedDB if large dataset persisted there
  useEffect(() => {
    let active = true;
    loadDatabaseFromIDB().then((idbData) => {
      if (active && idbData) {
        setDb(idbData);
        if (idbData.branches[0]) setCurrentBranch(idbData.branches[0]);
        if (idbData.currencies[0]) setCurrentCurrency(idbData.currencies[0]);
        if (idbData.users[0]) setCurrentUser(idbData.users[0]);
      }
    });
    return () => {
      active = false;
    };
  }, []);

  // Persist DB automatically
  useEffect(() => {
    saveDatabase(db);
  }, [db]);

  // Live Sync of V20 Theme CSS Custom Properties (font size, gold accent, card background)
  useEffect(() => {
    const ui = db.settings.uiPreferences;
    const size = ui?.fontSize || 14;
    const gold = ui?.goldColor || '#f5c748';
    const card = ui?.cardColor || '#101e2e';
    const root = document.documentElement.style;
    root.setProperty('--base-font-size', `${size}px`);
    root.fontSize = `${size}px`;
    root.setProperty('--gold', gold);
    root.setProperty('--bg-card', card);
  }, [db.settings.uiPreferences]);

  const getCurrencyRate = useCallback(
    (code: string): number => getEffectiveCurrencyRate(db.currencies, code),
    [db.currencies]
  );

  // Seamless navigation mapper: opens targeted record / module in an independent floating MDI popup window
  const navigateToRecord = useCallback(
    (moduleName: string, recordId?: string) => {
      let targetTab: V20TabId = 'tab-reports';
      let targetReportsSub: ReportsSubTabId = 'unified_docs';
      let targetUnifiedSub: UnifiedSubTabId = 'coa';
      let winTitle = lang === 'en' ? 'Document Window' : 'نافذة مستند';

      if (moduleName === 'sales' || moduleName === 'purchases' || moduleName === 'tab-pos') {
        targetTab = 'tab-pos';
        winTitle = lang === 'en' ? 'Invoice Window' : 'نافذة فاتورة';
      } else if (moduleName === 'treasury' || moduleName === 'liquidity' || moduleName === 'tab-bonds') {
        targetTab = 'tab-bonds';
        winTitle = lang === 'en' ? 'Voucher Window' : 'نافذة سندات وخزينة';
      } else if (moduleName === 'accounting' || moduleName === 'tab-ledgers') {
        targetTab = 'tab-ledgers';
        winTitle = lang === 'en' ? 'Ledger & Journals' : 'نافذة الدفاتر والقيود';
      } else if (moduleName === 'inventory' || moduleName === 'tab-inventory') {
        targetTab = 'tab-inventory';
        winTitle = lang === 'en' ? 'Inventory & Stock' : 'نافذة الجرد والمستودعات';
      } else if (
        moduleName === 'customers' ||
        moduleName === 'vendors' ||
        moduleName === 'receivables' ||
        moduleName === 'tab-cust'
      ) {
        targetTab = 'tab-cust';
        winTitle = lang === 'en' ? 'Customers & Vendors' : 'نافذة العملاء والموردين';
      } else if (moduleName === 'smart_ai') {
        targetTab = 'tab-reports';
        targetReportsSub = 'smart_ai';
        winTitle = lang === 'en' ? 'Smart AI Advisor' : 'مستشار الحلول الذكية';
      } else if (moduleName === 'daily_report') {
        targetTab = 'tab-reports';
        targetReportsSub = 'daily_22';
        winTitle = lang === 'en' ? 'Daily Management Report' : 'التقرير اليومي (22 مؤشر)';
      } else if (moduleName === 'unified_docs') {
        targetTab = 'tab-reports';
        targetReportsSub = 'unified_docs';
        winTitle = lang === 'en' ? 'Unified Documents' : 'مركز المستندات الموحد';
      } else if (moduleName === 'tasks' || moduleName === 'scheduled_dispatch') {
        targetTab = 'tab-reports';
        targetReportsSub = 'tasks_dispatch';
        winTitle = lang === 'en' ? 'Tasks & Dispatch' : 'التنبيهات والمجدول';
      } else if (moduleName === 'reports' || moduleName === 'dashboard' || moduleName === 'currency' || moduleName === 'tab-reports') {
        targetTab = 'tab-reports';
        targetReportsSub = 'v20_comp';
        winTitle = lang === 'en' ? 'Comprehensive Report' : 'التقرير الشامل للإدارة';
      } else if (moduleName === 'hr') {
        targetTab = 'tab-unified-coa';
        targetUnifiedSub = 'hr';
        winTitle = lang === 'en' ? 'HR & Payroll' : 'شؤون الموظفين والرواتب';
      } else if (moduleName === 'expenses' || moduleName === 'operations') {
        targetTab = 'tab-unified-coa';
        targetUnifiedSub = 'expenses';
        winTitle = lang === 'en' ? 'Expenses Center' : 'نافذة المصروفات';
      } else if (moduleName === 'assets') {
        targetTab = 'tab-unified-coa';
        targetUnifiedSub = 'assets';
        winTitle = lang === 'en' ? 'Fixed Assets' : 'الأصول الثابتة';
      } else if (moduleName === 'tab-unified-coa') {
        targetTab = 'tab-unified-coa';
        winTitle = lang === 'en' ? 'Unified COA & Operations' : 'النظام الموحد والشجرة';
      } else if (moduleName === 'settings' || moduleName === 'tab-admin') {
        targetTab = 'tab-admin';
        winTitle = lang === 'en' ? 'Settings & RBAC' : 'التخصيص والصلاحيات';
      }

      spawnFloatingWindow({
        tabId: targetTab,
        title: recordId ? `${winTitle} (${recordId.slice(-6)})` : winTitle,
        focusedRecordId: recordId,
        reportsSubTab: targetReportsSub,
        unifiedSubTab: targetUnifiedSub,
      });
    },
    [lang, spawnFloatingWindow]
  );

  // ==========================================
  // DOCUMENT BOOKS & DIRECTORIES HANDLERS
  // ==========================================
  const documentBooks = useMemo(
    () => (db.documentBooks && db.documentBooks.length > 0 ? db.documentBooks : defaultDocumentBooks),
    [db.documentBooks]
  );

  const handleSaveDocumentBook = (book: DocumentBook) => {
    const list = db.documentBooks || defaultDocumentBooks;
    const exists = list.some((b) => b.id === book.id);
    setDb({
      ...db,
      documentBooks: exists ? list.map((b) => (b.id === book.id ? book : b)) : [...list, book],
    });
  };

  const handleToggleDocumentBook = (bookId: string) => {
    const list = db.documentBooks || defaultDocumentBooks;
    setDb({
      ...db,
      documentBooks: list.map((b) => (b.id === bookId ? { ...b, isActive: !b.isActive } : b)),
    });
  };

  const handleSetDefaultDocumentBook = (bookId: string) => {
    const list = db.documentBooks || defaultDocumentBooks;
    const target = list.find((b) => b.id === bookId);
    if (!target) return;
    setDb({
      ...db,
      documentBooks: list.map((b) =>
        b.category === target.category ? { ...b, isDefault: b.id === bookId } : b
      ),
    });
  };

  const handleConsumeBookSequence = (bookId: string) => {
    setDb((prev) => ({
      ...prev,
      documentBooks: (prev.documentBooks || defaultDocumentBooks).map((b) =>
        b.id === bookId ? { ...b, nextSequence: b.nextSequence + 1 } : b
      ),
    }));
  };

  // ==========================================
  // TRANSACTIONAL OPERATIONAL BUSINESS LOGIC
  // ==========================================
  const handleSaveDraftInvoice = (invoice: Invoice) => {
    const draftInv: Invoice = { ...invoice, status: 'draft' };
    const exists = db.invoices.some((i) => i.id === draftInv.id);
    setDb((prev) => ({
      ...prev,
      invoices: exists ? prev.invoices.map((i) => (i.id === draftInv.id ? draftInv : i)) : [...prev.invoices, draftInv],
      auditLogs: [
        {
          id: `log-draft-${Date.now()}`,
          timestamp: new Date().toISOString(),
          userId: currentUser.id,
          userName: currentUser.fullName,
          action: exists ? 'تعديل' : 'إنشاء',
          module: draftInv.type.includes('مشتريات') ? 'المشتريات' : 'المبيعات',
          details: `حفظ مسودة فاتورة ${draftInv.type} رقم ${draftInv.invoiceNumber}`,
          entityId: draftInv.id,
        },
        ...prev.auditLogs,
      ],
    }));
  };

  const handlePostSalesInvoice = (invoice: Invoice) => {
    if (!currentUser.canPostEntries) {
      notify('error', 'صلاحيات المستخدم الحالي لا تسمح بترحيل الفواتير.');
      return;
    }
    if (!invoice.items || invoice.items.length === 0 || !Number.isFinite(invoice.grandTotal) || invoice.grandTotal < 0) {
      notify('error', 'يجب أن تحتوي الفاتورة على صنف واحد على الأقل بقيمة صالحة.');
      return;
    }
    const existing = db.invoices.find((i) => i.id === invoice.id);
    if (existing && existing.status !== 'draft') {
      notify('error', `الفاتورة رقم ${invoice.invoiceNumber} مرحلة مسبقاً.`);
      return;
    }

    const isReturn = invoice.type === 'مرتجع_مبيعات';
    const rate = invoice.exchangeRate || getCurrencyRate(invoice.currency);
    const normalizedPaid = Math.max(0, Math.min(invoice.grandTotal, Number(invoice.paidAmount) || 0));
    const normalizedRemaining = Math.max(0, Math.round((invoice.grandTotal - normalizedPaid) * 100) / 100);
    const normalizedInvoice: Invoice = {
      ...invoice,
      exchangeRate: rate,
      paidAmount: normalizedPaid,
      remainingAmount: normalizedRemaining,
    };

    let updatedStocks = [...db.warehouseStock];
    const newMovements = [...db.stockMovements];

    for (const line of normalizedInvoice.items) {
      const totalShippedQty = line.quantity + (line.bonusQuantity || 0);
      const qtyDelta = isReturn ? totalShippedQty : -totalShippedQty;
      updatedStocks = updateWarehouseStock(updatedStocks, line.itemId, normalizedInvoice.warehouseId, qtyDelta, line.unitCost);
      newMovements.push({
        id: `sm-${Date.now()}-${line.itemId}-${Math.random().toString(36).slice(2, 6)}`,
        itemId: line.itemId,
        warehouseId: normalizedInvoice.warehouseId,
        documentType: isReturn ? 'مرتجع_مبيعات' : 'فاتورة_مبيعات',
        documentNumber: normalizedInvoice.invoiceNumber,
        documentId: normalizedInvoice.id,
        movementDate: normalizedInvoice.date,
        quantityChange: qtyDelta,
        unitCost: line.unitCost,
        totalCost: line.unitCost * totalShippedQty,
        runningBalance: 0,
        notes: line.bonusQuantity ? `بونص مجاني: ${line.bonusQuantity}` : line.notes,
        performedBy: currentUser.fullName,
      });
    }

    const journalEntry = createSalesInvoiceJournalEntry(
      normalizedInvoice,
      db.chartOfAccounts,
      currentUser.fullName,
      db.journalEntries.map((j) => j.entryNumber)
    );

    const remainingBase = normalizedRemaining * rate;
    const paidBase = normalizedPaid * rate;
    const balanceDelta = isReturn ? -remainingBase : remainingBase;

    const targetCustomer = db.customers.find((c) => c.id === normalizedInvoice.entityId);
    const prevCustomerBalance =
      normalizedInvoice.previousBalanceSnapshot !== undefined
        ? normalizedInvoice.previousBalanceSnapshot
        : targetCustomer?.currentBalance ?? 0;
    const newCustomerBalance = prevCustomerBalance + balanceDelta;

    const updatedCustomers = db.customers.map((c) =>
      c.id === normalizedInvoice.entityId ? { ...c, currentBalance: c.currentBalance + balanceDelta } : c
    );

    let updatedTreasuries = [...db.treasuryAccounts];
    if (normalizedPaid > 0 && normalizedInvoice.treasuryAccountId) {
      updatedTreasuries = updatedTreasuries.map((t) => {
        if (t.id === normalizedInvoice.treasuryAccountId) {
          const tRate = getCurrencyRate(t.currency);
          const amtInTreasury = t.currency === normalizedInvoice.currency ? normalizedPaid : paidBase / tRate;
          return { ...t, balance: isReturn ? t.balance - amtInTreasury : t.balance + amtInTreasury };
        }
        return t;
      });
    }

    const enrichedInvoice: Invoice = {
      ...normalizedInvoice,
      status:
        normalizedInvoice.status === 'draft'
          ? normalizedRemaining === 0
            ? 'paid'
            : normalizedPaid > 0
            ? 'partial'
            : 'posted'
          : normalizedInvoice.status,
      previousBalanceSnapshot: prevCustomerBalance,
      newBalanceSnapshot: newCustomerBalance,
      journalEntryId: journalEntry.id,
    };

    setDb((prev) => ({
      ...prev,
      invoices: existing
        ? prev.invoices.map((i) => (i.id === existing.id ? enrichedInvoice : i))
        : [...prev.invoices, enrichedInvoice],
      warehouseStock: updatedStocks,
      stockMovements: newMovements,
      journalEntries: [...prev.journalEntries, journalEntry],
      customers: updatedCustomers,
      treasuryAccounts: updatedTreasuries,
      auditLogs: [
        {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          userId: currentUser.id,
          userName: currentUser.fullName,
          action: 'ترحيل',
          module: 'المبيعات',
          details: `ترحيل ${normalizedInvoice.type} رقم ${normalizedInvoice.invoiceNumber} بقيمة (${normalizedInvoice.grandTotal.toLocaleString()} ${normalizedInvoice.currency})`,
          entityId: normalizedInvoice.id,
        },
        ...prev.auditLogs,
      ],
    }));
  };

  const handlePostPurchaseInvoice = (invoice: Invoice) => {
    if (!currentUser.canPostEntries) {
      notify('error', 'صلاحيات المستخدم الحالي لا تسمح بترحيل فواتير المشتريات.');
      return;
    }
    if (!invoice.items || invoice.items.length === 0 || !Number.isFinite(invoice.grandTotal) || invoice.grandTotal < 0) {
      notify('error', 'يجب أن تحتوي فاتورة المشتريات على صنف واحد على الأقل بقيمة صالحة.');
      return;
    }
    const existing = db.invoices.find((i) => i.id === invoice.id);
    if (existing && existing.status !== 'draft') {
      notify('error', `الفاتورة رقم ${invoice.invoiceNumber} مرحلة مسبقاً.`);
      return;
    }

    const isReturn = invoice.type === 'مرتجع_مشتريات';
    const rate = invoice.exchangeRate || getCurrencyRate(invoice.currency);
    const normalizedPaid = Math.max(0, Math.min(invoice.grandTotal, Number(invoice.paidAmount) || 0));
    const normalizedRemaining = Math.max(0, Math.round((invoice.grandTotal - normalizedPaid) * 100) / 100);
    const normalizedInvoice: Invoice = {
      ...invoice,
      exchangeRate: rate,
      paidAmount: normalizedPaid,
      remainingAmount: normalizedRemaining,
    };

    let updatedStocks = [...db.warehouseStock];
    const newMovements = [...db.stockMovements];

    for (const line of normalizedInvoice.items) {
      const totalReceivedQty = line.quantity + (line.bonusQuantity || 0);
      const effectiveUnitCost =
        totalReceivedQty > 0 ? (line.unitCost * line.quantity) / totalReceivedQty : line.unitCost;
      const qtyDelta = isReturn ? -totalReceivedQty : totalReceivedQty;

      updatedStocks = updateWarehouseStock(updatedStocks, line.itemId, normalizedInvoice.warehouseId, qtyDelta, effectiveUnitCost);
      newMovements.push({
        id: `sm-pur-${Date.now()}-${line.itemId}-${Math.random().toString(36).slice(2, 6)}`,
        itemId: line.itemId,
        warehouseId: normalizedInvoice.warehouseId,
        documentType: isReturn ? 'مرتجع_مشتريات' : 'فاتورة_مشتريات',
        documentNumber: normalizedInvoice.invoiceNumber,
        documentId: normalizedInvoice.id,
        movementDate: normalizedInvoice.date,
        quantityChange: qtyDelta,
        unitCost: effectiveUnitCost,
        totalCost: line.unitCost * line.quantity,
        runningBalance: 0,
        notes: line.bonusQuantity ? `بونص توريد مجاني: ${line.bonusQuantity}` : line.notes,
        performedBy: currentUser.fullName,
      });
    }

    const journalEntry = createPurchaseInvoiceJournalEntry(
      normalizedInvoice,
      db.chartOfAccounts,
      currentUser.fullName,
      db.journalEntries.map((j) => j.entryNumber)
    );

    const remainingBase = normalizedRemaining * rate;
    const paidBase = normalizedPaid * rate;
    const balanceDelta = isReturn ? -remainingBase : remainingBase;

    const targetVendor = db.vendors.find((v) => v.id === normalizedInvoice.entityId);
    const prevVendorBalance =
      normalizedInvoice.previousBalanceSnapshot !== undefined
        ? normalizedInvoice.previousBalanceSnapshot
        : targetVendor?.currentBalance ?? 0;
    const newVendorBalance = prevVendorBalance + balanceDelta;

    const updatedVendors = db.vendors.map((v) =>
      v.id === normalizedInvoice.entityId ? { ...v, currentBalance: v.currentBalance + balanceDelta } : v
    );

    let updatedTreasuries = [...db.treasuryAccounts];
    if (normalizedPaid > 0 && normalizedInvoice.treasuryAccountId) {
      updatedTreasuries = updatedTreasuries.map((t) => {
        if (t.id === normalizedInvoice.treasuryAccountId) {
          const tRate = getCurrencyRate(t.currency);
          const amtInTreasury = t.currency === normalizedInvoice.currency ? normalizedPaid : paidBase / tRate;
          return { ...t, balance: isReturn ? t.balance + amtInTreasury : t.balance - amtInTreasury };
        }
        return t;
      });
    }

    const enrichedInvoice: Invoice = {
      ...normalizedInvoice,
      status:
        normalizedInvoice.status === 'draft'
          ? normalizedRemaining === 0
            ? 'paid'
            : normalizedPaid > 0
            ? 'partial'
            : 'posted'
          : normalizedInvoice.status,
      previousBalanceSnapshot: prevVendorBalance,
      newBalanceSnapshot: newVendorBalance,
      journalEntryId: journalEntry.id,
    };

    setDb((prev) => ({
      ...prev,
      invoices: existing
        ? prev.invoices.map((i) => (i.id === existing.id ? enrichedInvoice : i))
        : [...prev.invoices, enrichedInvoice],
      warehouseStock: updatedStocks,
      stockMovements: newMovements,
      journalEntries: [...prev.journalEntries, journalEntry],
      vendors: updatedVendors,
      treasuryAccounts: updatedTreasuries,
      auditLogs: [
        {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          userId: currentUser.id,
          userName: currentUser.fullName,
          action: 'ترحيل',
          module: 'المشتريات',
          details: `ترحيل ${normalizedInvoice.type} رقم ${normalizedInvoice.invoiceNumber} بقيمة (${normalizedInvoice.grandTotal.toLocaleString()} ${normalizedInvoice.currency})`,
          entityId: normalizedInvoice.id,
        },
        ...prev.auditLogs,
      ],
    }));
  };

  const handleCancelInvoice = (invoiceId: string) => {
    if (currentUser.canDeleteInvoices === false) {
      notify('error', 'صلاحياتك لا تسمح بإلغاء أو حذف الفواتير.');
      return;
    }
    const inv = db.invoices.find((i) => i.id === invoiceId);
    if (!inv || inv.status === 'cancelled') {
      notify('info', 'الفاتورة ملغاة مسبقاً أو غير موجودة.');
      return;
    }

    const wasDraft = inv.status === 'draft';
    let updatedStocks = [...db.warehouseStock];
    const newMovements = [...db.stockMovements];
    let updatedCustomers = [...db.customers];
    let updatedVendors = [...db.vendors];
    let updatedTreasuries = [...db.treasuryAccounts];
    let updatedJEs = [...db.journalEntries];

    if (!wasDraft) {
      const rate = inv.exchangeRate || getCurrencyRate(inv.currency);
      const isSalesSide = inv.type === 'مبيعات' || inv.type === 'مرتجع_مبيعات';
      const wasStockDeducted = inv.type === 'مبيعات' || inv.type === 'مرتجع_مشتريات';

      for (const line of inv.items) {
        const qty = line.quantity + (line.bonusQuantity || 0);
        const reverseDelta = wasStockDeducted ? qty : -qty;
        updatedStocks = updateWarehouseStock(updatedStocks, line.itemId, inv.warehouseId, reverseDelta, line.unitCost);
        newMovements.push({
          id: `sm-can-${Date.now()}-${line.itemId}-${Math.random().toString(36).slice(2, 6)}`,
          itemId: line.itemId,
          warehouseId: inv.warehouseId,
          documentType: wasStockDeducted ? 'مرتجع_مبيعات' : 'مرتجع_مشتريات',
          documentNumber: `${inv.invoiceNumber}-CANCEL`,
          documentId: inv.id,
          movementDate: new Date().toISOString().split('T')[0],
          quantityChange: reverseDelta,
          unitCost: line.unitCost,
          totalCost: line.unitCost * qty,
          runningBalance: 0,
          notes: `عكس مخزون نتيجة إلغاء فاتورة ${inv.invoiceNumber}`,
          performedBy: currentUser.fullName,
        });
      }

      const remainingBase = (inv.remainingAmount || 0) * rate;
      const paidBase = (inv.paidAmount || 0) * rate;

      if (isSalesSide) {
        const sign = inv.type === 'مبيعات' ? -1 : 1;
        updatedCustomers = updatedCustomers.map((c) =>
          c.id === inv.entityId ? { ...c, currentBalance: c.currentBalance + sign * remainingBase } : c
        );
      } else {
        const sign = inv.type === 'مشتريات' ? -1 : 1;
        updatedVendors = updatedVendors.map((v) =>
          v.id === inv.entityId ? { ...v, currentBalance: v.currentBalance + sign * remainingBase } : v
        );
      }

      if (inv.paidAmount > 0 && inv.treasuryAccountId) {
        const treasurySign = inv.type === 'مبيعات' || inv.type === 'مرتجع_مشتريات' ? -1 : 1;
        updatedTreasuries = updatedTreasuries.map((t) => {
          if (t.id === inv.treasuryAccountId) {
            const tRate = getCurrencyRate(t.currency);
            const amtInTreasury = t.currency === inv.currency ? inv.paidAmount : paidBase / tRate;
            return { ...t, balance: t.balance + treasurySign * amtInTreasury };
          }
          return t;
        });
      }

      if (inv.journalEntryId) {
        const origJe = updatedJEs.find((j) => j.id === inv.journalEntryId && j.status === 'posted');
        if (origJe) {
          const revJe = createReversalJournalEntry(
            origJe,
            `إلغاء فاتورة ${inv.invoiceNumber}`,
            currentUser.fullName,
            updatedJEs.map((j) => j.entryNumber)
          );
          updatedJEs = updatedJEs.map((j) => (j.id === origJe.id ? { ...j, status: 'reversed' } : j));
          updatedJEs.push(revJe);
        }
      }
    }

    setDb((prev) => ({
      ...prev,
      invoices: prev.invoices.map((i) => (i.id === inv.id ? { ...i, status: 'cancelled' as const } : i)),
      warehouseStock: updatedStocks,
      stockMovements: newMovements,
      customers: updatedCustomers,
      vendors: updatedVendors,
      treasuryAccounts: updatedTreasuries,
      journalEntries: updatedJEs,
      auditLogs: [
        {
          id: `log-can-${Date.now()}`,
          timestamp: new Date().toISOString(),
          userId: currentUser.id,
          userName: currentUser.fullName,
          action: 'إلغاء',
          module: inv.type.includes('مشتريات') ? 'المشتريات' : 'المبيعات',
          details: `إلغاء ${wasDraft ? 'مسودة' : 'فاتورة'} رقم ${inv.invoiceNumber}${wasDraft ? '' : ' وعكس القيد والمخزون والأرصدة'}`,
          entityId: inv.id,
        },
        ...prev.auditLogs,
      ],
    }));
    notify('success', `تم إلغاء الفاتورة ${inv.invoiceNumber} وعكس أثرها بالكامل.`);
  };

  const handleBatchPostVouchers = (vouchers: PaymentVoucher[]) => {
    let updatedTreasuries = [...db.treasuryAccounts];
    let updatedCustomers = [...db.customers];
    let updatedVendors = [...db.vendors];
    const newJournalEntries: JournalEntry[] = [];
    const newVouchers: PaymentVoucher[] = [];
    const newAuditLogs: ERPDatabase['auditLogs'] = [];
    const runningJeNums = db.journalEntries.map((j) => j.entryNumber);

    vouchers.forEach((voucher) => {
      const rate = voucher.exchangeRate || getCurrencyRate(voucher.currency);
      const baseAmt = voucher.baseAmount || voucher.amount * rate;
      const norm: PaymentVoucher = { ...voucher, exchangeRate: rate, baseAmount: baseAmt };

      const journalEntry = createVoucherJournalEntry(norm, db.chartOfAccounts, currentUser.fullName, runningJeNums);
      runningJeNums.push(journalEntry.entryNumber);
      newJournalEntries.push(journalEntry);
      newVouchers.push({ ...norm, journalEntryId: journalEntry.id });

      updatedTreasuries = updatedTreasuries.map((t) => {
        if (t.id === voucher.treasuryAccountId) {
          const tRate = getCurrencyRate(t.currency);
          const amtInTreasury = t.currency === voucher.currency ? voucher.amount : baseAmt / tRate;
          return {
            ...t,
            balance: voucher.type === 'قبض' ? t.balance + amtInTreasury : t.balance - amtInTreasury,
          };
        }
        return t;
      });

      if (voucher.entityType === 'عميل' && voucher.entityId) {
        updatedCustomers = updatedCustomers.map((c) =>
          c.id === voucher.entityId
            ? { ...c, currentBalance: voucher.type === 'قبض' ? c.currentBalance - baseAmt : c.currentBalance + baseAmt }
            : c
        );
      }

      if (voucher.entityType === 'مورد' && voucher.entityId) {
        updatedVendors = updatedVendors.map((v) =>
          v.id === voucher.entityId
            ? { ...v, currentBalance: voucher.type === 'صرف' ? v.currentBalance - baseAmt : v.currentBalance + baseAmt }
            : v
        );
      }

      newAuditLogs.push({
        id: `log-${Date.now()}-${voucher.id}`,
        timestamp: new Date().toISOString(),
        userId: currentUser.id,
        userName: currentUser.fullName,
        action: 'إنشاء',
        module: 'الخزينة',
        details: `ترحيل ${voucher.type === 'قبض' ? 'سند قبض' : 'سند صرف'} رقم ${voucher.voucherNumber} بمبلغ (${voucher.amount.toLocaleString()} ${voucher.currency})`,
        entityId: voucher.id,
      });
    });

    setDb((prev) => ({
      ...prev,
      paymentVouchers: [...prev.paymentVouchers, ...newVouchers],
      journalEntries: [...prev.journalEntries, ...newJournalEntries],
      treasuryAccounts: updatedTreasuries,
      customers: updatedCustomers,
      vendors: updatedVendors,
      auditLogs: [...newAuditLogs, ...prev.auditLogs],
    }));
  };

  const handleCancelVoucher = (voucherId: string) => {
    if (currentUser.canDeleteVouchers === false) {
      notify('error', 'صلاحياتك لا تسمح بإلغاء السندات المالية.');
      return;
    }
    const v = db.paymentVouchers.find((x) => x.id === voucherId);
    if (!v || v.status === 'cancelled') return;

    const rate = v.exchangeRate || getCurrencyRate(v.currency);
    const baseAmt = v.baseAmount || v.amount * rate;

    const updatedTreasuries = db.treasuryAccounts.map((t) => {
      if (t.id === v.treasuryAccountId) {
        const tRate = getCurrencyRate(t.currency);
        const amtInTreasury = t.currency === v.currency ? v.amount : baseAmt / tRate;
        return { ...t, balance: v.type === 'قبض' ? t.balance - amtInTreasury : t.balance + amtInTreasury };
      }
      return t;
    });

    const updatedCustomers =
      v.entityType === 'عميل' && v.entityId
        ? db.customers.map((c) =>
            c.id === v.entityId
              ? { ...c, currentBalance: v.type === 'قبض' ? c.currentBalance + baseAmt : c.currentBalance - baseAmt }
              : c
          )
        : db.customers;

    const updatedVendors =
      v.entityType === 'مورد' && v.entityId
        ? db.vendors.map((vnd) =>
            vnd.id === v.entityId
              ? { ...vnd, currentBalance: v.type === 'صرف' ? vnd.currentBalance + baseAmt : vnd.currentBalance - baseAmt }
              : vnd
          )
        : db.vendors;

    let updatedJEs = [...db.journalEntries];
    if (v.journalEntryId) {
      const origJe = updatedJEs.find((j) => j.id === v.journalEntryId && j.status === 'posted');
      if (origJe) {
        const revJe = createReversalJournalEntry(
          origJe,
          `إلغاء سند ${v.voucherNumber}`,
          currentUser.fullName,
          updatedJEs.map((j) => j.entryNumber)
        );
        updatedJEs = updatedJEs.map((j) => (j.id === origJe.id ? { ...j, status: 'reversed' } : j));
        updatedJEs.push(revJe);
      }
    }

    setDb((prev) => ({
      ...prev,
      paymentVouchers: prev.paymentVouchers.map((x) =>
        x.id === v.id ? { ...x, status: 'cancelled' as const } : x
      ),
      treasuryAccounts: updatedTreasuries,
      customers: updatedCustomers,
      vendors: updatedVendors,
      journalEntries: updatedJEs,
      auditLogs: [
        {
          id: `log-vcan-${Date.now()}`,
          timestamp: new Date().toISOString(),
          userId: currentUser.id,
          userName: currentUser.fullName,
          action: 'إلغاء',
          module: 'الخزينة',
          details: `إلغاء سند ${v.type} رقم ${v.voucherNumber} وعكس القيد والأرصدة`,
          entityId: v.id,
        },
        ...prev.auditLogs,
      ],
    }));
    notify('success', `تم إلغاء السند ${v.voucherNumber} وعكس أثره بنجاح.`);
  };

  const handleTreasuryTransfer = (transfer: TreasuryTransfer) => {
    const fromTr = db.treasuryAccounts.find((t) => t.id === transfer.fromTreasuryId);
    const toTr = db.treasuryAccounts.find((t) => t.id === transfer.toTreasuryId);
    if (!fromTr || !toTr || fromTr.id === toTr.id || transfer.amount <= 0) {
      notify('error', 'بيانات التحويل بين الصناديق غير صالحة.');
      return;
    }

    const rate = getCurrencyRate(transfer.currency);
    const baseAmt = transfer.amount * rate;
    const baseFee = (transfer.feeAmount || 0) * rate;

    const updatedTreasuries = db.treasuryAccounts.map((t) => {
      const tRate = getCurrencyRate(t.currency);
      if (t.id === fromTr.id) {
        const deductAmt =
          t.currency === transfer.currency ? transfer.amount + (transfer.feeAmount || 0) : (baseAmt + baseFee) / tRate;
        return { ...t, balance: t.balance - deductAmt };
      }
      if (t.id === toTr.id) {
        const addAmt = t.currency === transfer.currency ? transfer.amount : baseAmt / tRate;
        return { ...t, balance: t.balance + addAmt };
      }
      return t;
    });

    const accFrom =
      db.chartOfAccounts.find((a) => a.id === fromTr.generalLedgerAccountId) ||
      resolveAccount(db.chartOfAccounts, ['1111', '131'], 'أصول', ['الصندوق']);
    const accTo =
      db.chartOfAccounts.find((a) => a.id === toTr.generalLedgerAccountId) ||
      resolveAccount(db.chartOfAccounts, ['1121', '132'], 'أصول', ['بنك']);
    const accBankFees =
      resolveAccount(db.chartOfAccounts, ['5340', '510'], 'مصروفات', ['رسوم', 'مصاريف']);

    const entryNumber = generateNextDocNumber(
      `JV-${new Date().getFullYear()}-`,
      db.journalEntries.map((j) => j.entryNumber),
      4
    );

    const je: JournalEntry = {
      id: `je-tr-${Date.now()}`,
      entryNumber,
      date: transfer.date,
      branchId: currentBranch.id,
      referenceType: 'تحويل_نقدية',
      referenceNumber: transfer.transferNumber,
      referenceId: transfer.id,
      description: `تحويل نقدي من ${fromTr.nameAr} إلى ${toTr.nameAr}`,
      lines: [
        {
          id: `jl-t1-${Date.now()}`,
          accountId: accTo.id,
          accountCode: accTo.code,
          accountName: `${accTo.nameAr} (${toTr.nameAr})`,
          debit: baseAmt,
          credit: 0,
          currency: transfer.currency,
          exchangeRate: rate,
          memo: `استلام تحويل نقدي ${transfer.transferNumber}`,
        },
        ...(baseFee > 0
          ? [
              {
                id: `jl-t2-${Date.now()}`,
                accountId: accBankFees.id,
                accountCode: accBankFees.code,
                accountName: accBankFees.nameAr,
                debit: baseFee,
                credit: 0,
                currency: transfer.currency,
                exchangeRate: rate,
                memo: `رسوم تحويل بنكي ${transfer.transferNumber}`,
              },
            ]
          : []),
        {
          id: `jl-t3-${Date.now()}`,
          accountId: accFrom.id,
          accountCode: accFrom.code,
          accountName: `${accFrom.nameAr} (${fromTr.nameAr})`,
          debit: 0,
          credit: baseAmt + baseFee,
          currency: transfer.currency,
          exchangeRate: rate,
          memo: `صرف تحويل نقدي إلى ${toTr.nameAr}`,
        },
      ],
      totalDebit: baseAmt + baseFee,
      totalCredit: baseAmt + baseFee,
      status: 'posted',
      createdBy: currentUser.fullName,
      createdAt: new Date().toISOString(),
    };

    setDb((prev) => ({
      ...prev,
      treasuryAccounts: updatedTreasuries,
      treasuryTransfers: [{ ...transfer, journalEntryId: je.id }, ...(prev.treasuryTransfers || [])],
      journalEntries: [...prev.journalEntries, je],
      auditLogs: [
        {
          id: `log-ttr-${Date.now()}`,
          timestamp: new Date().toISOString(),
          userId: currentUser.id,
          userName: currentUser.fullName,
          action: 'إنشاء',
          module: 'الخزينة',
          details: `تحويل نقدي رقم ${transfer.transferNumber} من (${fromTr.nameAr}) إلى (${toTr.nameAr})`,
          entityId: transfer.id,
        },
        ...prev.auditLogs,
      ],
    }));
  };

  const handleSaveCustomBookEntry = (
    entry: CustomLedgerEntry,
    options?: { syncVoucher?: boolean }
  ) => {
    const existing = db.customBookEntries || [];
    const exists = existing.some((e) => e.id === entry.id);
    const updatedEntries = exists ? existing.map((e) => (e.id === entry.id ? entry : e)) : [entry, ...existing];

    let updatedTreasuries = [...db.treasuryAccounts];
    let updatedCustomers = [...db.customers];
    let updatedVendors = [...db.vendors];
    const generatedVouchers: PaymentVoucher[] = [];
    const generatedJEs: JournalEntry[] = [];
    const runningJeNums = db.journalEntries.map((j) => j.entryNumber);

    if (!exists && entry.treasuryAccountId) {
      const tr = db.treasuryAccounts.find((t) => t.id === entry.treasuryAccountId);
      const totalVal = entry.rows.reduce(
        (s, r) => s + ((entry.direction === 'IN' ? r.debit : r.credit) || r.debit || r.credit || 0),
        0
      );
      if (tr && totalVal > 0) {
        updatedTreasuries = updatedTreasuries.map((t) => {
          if (t.id === entry.treasuryAccountId) {
            const trRate = getCurrencyRate(t.currency);
            const delta = totalVal / trRate;
            return {
              ...t,
              balance: entry.direction === 'IN' ? t.balance + delta : t.balance - delta,
            };
          }
          return t;
        });

        if (options?.syncVoucher !== false) {
          const batchId = `cbook-${entry.id}`;
          const vType: PaymentVoucher['type'] = entry.direction === 'IN' ? 'قبض' : 'صرف';
          entry.rows.forEach((r, idx) => {
            const rowAmt = (entry.direction === 'IN' ? r.debit : r.credit) || r.debit || r.credit || 0;
            if (rowAmt <= 0) return;
            const rate = getCurrencyRate(r.currency || 'YER');
            const baseAmt = rowAmt * rate;
            const pName = (r.partyName || '').trim();
            const matchedCust = db.customers.find((c) => c.nameAr.trim() === pName);
            const matchedVend = !matchedCust ? db.vendors.find((v) => v.nameAr.trim() === pName) : undefined;
            const matchedExpCat =
              !matchedCust && !matchedVend
                ? db.expenseCategories.find((ec) => ec.nameAr.trim() === pName)
                : undefined;
            const matchedAcc =
              !matchedCust && !matchedVend && !matchedExpCat
                ? db.chartOfAccounts.find((a) => a.isLeaf && a.nameAr.trim() === pName)
                : undefined;

            const entityType: PaymentVoucher['entityType'] = matchedCust
              ? 'عميل'
              : matchedVend
              ? 'مورد'
              : entry.direction === 'OUT'
              ? 'مصروف'
              : 'إيراد';
            const entityId =
              matchedCust?.id ||
              matchedVend?.id ||
              matchedExpCat?.ledgerAccountId ||
              matchedAcc?.id;

            const voucher: PaymentVoucher = {
              id: `vch-cb-${entry.id}-${idx}`,
              voucherNumber: entry.rows.length > 1 ? `${entry.entryNumber}-${idx + 1}` : entry.entryNumber,
              batchId,
              type: vType,
              date: entry.date,
              branchId: currentBranch.id,
              treasuryAccountId: tr.id,
              treasuryAccountName: tr.nameAr,
              entityType,
              entityId,
              entityName: pName || entry.treasuryAccountName || 'دفتر يومي',
              amount: rowAmt,
              currency: r.currency || 'YER',
              exchangeRate: rate,
              baseAmount: baseAmt,
              paymentMethod: 'نقداً',
              statement: r.statement || entry.notes || `قيد دفتر ${entry.entryNumber}`,
              status: 'posted',
              receivedOrPaidBy: currentUser.fullName,
              createdBy: currentUser.fullName,
              createdAt: new Date().toISOString(),
            };
            const je = createVoucherJournalEntry(voucher, db.chartOfAccounts, currentUser.fullName, runningJeNums);
            runningJeNums.push(je.entryNumber);
            generatedJEs.push(je);
            generatedVouchers.push({ ...voucher, journalEntryId: je.id });

            if (matchedCust) {
              updatedCustomers = updatedCustomers.map((c) =>
                c.id === matchedCust.id
                  ? { ...c, currentBalance: vType === 'قبض' ? c.currentBalance - baseAmt : c.currentBalance + baseAmt }
                  : c
              );
            } else if (matchedVend) {
              updatedVendors = updatedVendors.map((v) =>
                v.id === matchedVend.id
                  ? { ...v, currentBalance: vType === 'صرف' ? v.currentBalance - baseAmt : v.currentBalance + baseAmt }
                  : v
              );
            }
          });
        }
      }
    }

    setDb((prev) => ({
      ...prev,
      customBookEntries: updatedEntries,
      treasuryAccounts: updatedTreasuries,
      customers: updatedCustomers,
      vendors: updatedVendors,
      paymentVouchers: generatedVouchers.length > 0 ? [...prev.paymentVouchers, ...generatedVouchers] : prev.paymentVouchers,
      journalEntries: generatedJEs.length > 0 ? [...prev.journalEntries, ...generatedJEs] : prev.journalEntries,
    }));
  };

  const handlePostExpense = (expense: ExpenseRecord) => {
    if (!currentUser.canPostEntries) {
      notify('error', 'صلاحياتك لا تسمح بترحيل المصروفات.');
      return;
    }
    if (!Number.isFinite(expense.total) || expense.total <= 0) {
      notify('error', 'قيمة المصروف يجب أن تكون أكبر من صفر.');
      return;
    }
    const expRate = getCurrencyRate(expense.currency || 'YER');
    const baseExpAmount = expense.total * expRate;
    const journalEntry = createExpenseJournalEntry(
      expense,
      db.chartOfAccounts,
      currentUser.fullName,
      db.journalEntries.map((j) => j.entryNumber),
      expRate
    );
    const updatedTreasuries = db.treasuryAccounts.map((t) => {
      if (t.id === expense.treasuryAccountId) {
        const tRate = getCurrencyRate(t.currency);
        const deductAmt = t.currency === expense.currency ? expense.total : baseExpAmount / tRate;
        return { ...t, balance: t.balance - deductAmt };
      }
      return t;
    });
    setDb((prev) => ({
      ...prev,
      expenseRecords: [...prev.expenseRecords, { ...expense, journalEntryId: journalEntry.id }],
      journalEntries: [...prev.journalEntries, journalEntry],
      treasuryAccounts: updatedTreasuries,
    }));
  };

  const handlePostManualEntry = (entry: JournalEntry) => {
    if (!currentUser.canPostEntries) {
      notify('error', 'صلاحياتك لا تسمح بترحيل القيود المحاسبية.');
      return;
    }
    if (db.settings.enforceBalancedJournalEntries) {
      const check = validateJournalEntry(entry.lines);
      if (!check.isValid) {
        notify('error', check.error || 'القيد المحاسبي غير متوازن.');
        return;
      }
    }
    setDb((prev) => ({
      ...prev,
      journalEntries: [...prev.journalEntries, entry],
    }));
  };

  const handleReverseJournalEntry = (entryId: string, reason: string) => {
    const orig = db.journalEntries.find((j) => j.id === entryId);
    if (!orig || orig.status === 'reversed') {
      notify('error', 'هذا القيد معكوس مسبقاً أو غير موجود.');
      return;
    }
    const rev = createReversalJournalEntry(
      orig,
      reason,
      currentUser.fullName,
      db.journalEntries.map((j) => j.entryNumber)
    );
    setDb((prev) => ({
      ...prev,
      journalEntries: [...prev.journalEntries.map((j) => (j.id === orig.id ? { ...j, status: 'reversed' as const } : j)), rev],
    }));
    notify('success', `تم إنشاء القيد العكسي ${rev.entryNumber} بنجاح.`);
  };

  const handleExecuteTransfer = (transfer: InventoryTransfer) => {
    const res = executeInventoryTransfer(db.warehouseStock, transfer, currentUser.fullName);
    if (!res.success) {
      notify('error', res.error || 'تعذر تنفيذ التحويل المخزني.');
      return;
    }
    setDb((prev) => ({
      ...prev,
      warehouseStock: res.newStocks,
      stockMovements: [...prev.stockMovements, ...res.movements],
      inventoryTransfers: [...prev.inventoryTransfers, { ...transfer, status: 'completed' }],
    }));
    notify('success', `تم تنفيذ التحويل المخزني ${transfer.transferNumber} بنجاح.`);
  };

  const handleReverseTransfer = (transfer: InventoryTransfer) => {
    const res = reverseInventoryTransfer(db.warehouseStock, transfer, currentUser.fullName);
    if (!res.success) {
      notify('error', res.error || 'تعذر عكس التحويل المخزني.');
      return;
    }
    setDb((prev) => ({
      ...prev,
      warehouseStock: res.newStocks,
      stockMovements: [...prev.stockMovements, ...res.movements],
      inventoryTransfers: prev.inventoryTransfers.map((t) =>
        t.id === transfer.id ? { ...t, status: 'cancelled' as const } : t
      ),
    }));
    notify('success', `تم عكس التحويل المخزني ${transfer.transferNumber} بنجاح.`);
  };

  const handleAdjustStock = (itemId: string, warehouseId: string, diff: number, reason: string) => {
    const it = db.inventoryItems.find((i) => i.id === itemId);
    const unitCost = it ? it.purchasePrice : 10000;
    const updatedStocks = updateWarehouseStock(db.warehouseStock, itemId, warehouseId, diff, unitCost);
    setDb((prev) => ({
      ...prev,
      warehouseStock: updatedStocks,
      stockMovements: [
        ...prev.stockMovements,
        {
          id: `sm-adj-${Date.now()}`,
          itemId,
          warehouseId,
          documentType: diff > 0 ? 'تسوية_زيادة' : 'تسوية_عجز',
          documentNumber: `ADJ-${Date.now().toString().slice(-4)}`,
          documentId: `adj-${Date.now()}`,
          movementDate: new Date().toISOString().split('T')[0],
          quantityChange: diff,
          unitCost,
          totalCost: Math.abs(diff * unitCost),
          runningBalance: 0,
          notes: reason,
          performedBy: currentUser.fullName,
        },
      ],
    }));
  };

  const handleSaveStocktaking = (stocktake: PhysicalStocktaking) => {
    const existing = db.stocktakings.find((s) => s.id === stocktake.id);
    if (existing?.status === 'approved') return;
    setDb((prev) => ({
      ...prev,
      stocktakings: existing
        ? prev.stocktakings.map((s) => (s.id === stocktake.id ? stocktake : s))
        : [stocktake, ...prev.stocktakings],
    }));
    notify('success', `تم حفظ مسودة الجرد ${stocktake.stocktakeNumber}.`);
  };

  const handleApproveStocktaking = (stocktake: PhysicalStocktaking) => {
    const res = applyStocktakingAdjustments(db.warehouseStock, stocktake, currentUser.fullName);
    if (!res.success) {
      notify('error', res.error || 'تعذر اعتماد محضر الجرد.');
      return;
    }
    const je = createStocktakingJournalEntry(
      stocktake,
      db.chartOfAccounts,
      db.settings.stocktakeSurplusAccountCode || '4190',
      db.settings.stocktakeShortageAccountCode || '5390',
      currentUser.fullName,
      db.journalEntries.map((j) => j.entryNumber)
    );
    const approved: PhysicalStocktaking = {
      ...stocktake,
      status: 'approved',
      approvedBy: currentUser.fullName,
      approvedAt: new Date().toISOString(),
      adjustmentJournalEntryId: je?.id,
    };
    const existing = db.stocktakings.find((s) => s.id === stocktake.id);
    setDb((prev) => ({
      ...prev,
      stocktakings: existing
        ? prev.stocktakings.map((s) => (s.id === stocktake.id ? approved : s))
        : [approved, ...prev.stocktakings],
      warehouseStock: res.newStocks,
      stockMovements: [...prev.stockMovements, ...res.movements],
      journalEntries: je ? [...prev.journalEntries, je] : prev.journalEntries,
    }));
    notify('success', `تم اعتماد محضر الجرد ${stocktake.stocktakeNumber} وتحديث المخزون والقيود بنجاح.`);
  };

  const handleDisbursePayroll = (payroll: PayrollRun) => {
    if (!currentUser.canPostEntries) {
      notify('error', 'صلاحياتك لا تسمح بصرف وترحيل مسير الرواتب.');
      return;
    }
    const updatedTreasuries = db.treasuryAccounts.map((t) => {
      if (t.id === payroll.disbursementTreasuryId) {
        const tRate = getCurrencyRate(t.currency);
        return { ...t, balance: t.balance - payroll.totalNet / tRate };
      }
      return t;
    });
    const accSalaries = resolveAccount(db.chartOfAccounts, ['5210', '521', '520'], 'مصروفات', ['رواتب']);
    const accTreasury = resolveAccount(db.chartOfAccounts, ['1111', '131'], 'أصول', ['الصندوق']);
    const accDeductions = resolveAccount(db.chartOfAccounts, ['2130', '213', '210'], 'خصوم', ['استقطاع', 'مستحق']);
    const entryNumber = generateNextDocNumber(
      `JV-${new Date().getFullYear()}-`,
      db.journalEntries.map((j) => j.entryNumber),
      4
    );
    const payrollEntry: JournalEntry = {
      id: `je-pay-${Date.now()}`,
      entryNumber,
      date: payroll.disbursedDate || new Date().toISOString().split('T')[0],
      branchId: currentBranch.id,
      referenceType: 'رواتب',
      referenceNumber: payroll.payrollNumber,
      referenceId: payroll.id,
      description: `قيد إثبات وصرف رواتب شهر ${payroll.month}`,
      lines: [
        {
          id: `jl-p1-${Date.now()}`,
          accountId: accSalaries.id,
          accountCode: accSalaries.code,
          accountName: accSalaries.nameAr,
          debit: payroll.totalGross,
          credit: 0,
          currency: 'YER',
          exchangeRate: 1,
          memo: `رواتب شهر ${payroll.month}`,
        },
        {
          id: `jl-p2-${Date.now()}`,
          accountId: accTreasury.id,
          accountCode: accTreasury.code,
          accountName: accTreasury.nameAr,
          debit: 0,
          credit: payroll.totalNet,
          currency: 'YER',
          exchangeRate: 1,
          memo: `صرف صافي الرواتب`,
        },
        {
          id: `jl-p3-${Date.now()}`,
          accountId: accDeductions.id,
          accountCode: accDeductions.code,
          accountName: accDeductions.nameAr,
          debit: 0,
          credit: payroll.totalDeductions,
          currency: 'YER',
          exchangeRate: 1,
          memo: `استقطاعات`,
        },
      ],
      totalDebit: payroll.totalGross,
      totalCredit: payroll.totalGross,
      status: 'posted',
      createdBy: currentUser.fullName,
      createdAt: new Date().toISOString(),
    };
    setDb((prev) => ({
      ...prev,
      payrollRuns: [...prev.payrollRuns, { ...payroll, journalEntryId: payrollEntry.id }],
      journalEntries: [...prev.journalEntries, payrollEntry],
      treasuryAccounts: updatedTreasuries,
    }));
  };

  const handleRunDepreciation = (totalDepr: number) => {
    if (!Number.isFinite(totalDepr) || totalDepr <= 0) {
      notify('info', 'لا توجد مبالغ إهلاك مستحقة لهذا الشهر.');
      return;
    }
    const accExpense = resolveAccount(db.chartOfAccounts, ['5410', '541', '540'], 'مصروفات', ['إهلاك']);
    const accAccDepr = resolveAccount(db.chartOfAccounts, ['1290', '129', '123'], 'أصول', ['مجمع', 'إهلاك']);
    const entryNumber = generateNextDocNumber(
      `JV-${new Date().getFullYear()}-`,
      db.journalEntries.map((j) => j.entryNumber),
      4
    );
    const deprEntry: JournalEntry = {
      id: `je-depr-${Date.now()}`,
      entryNumber,
      date: new Date().toISOString().split('T')[0],
      branchId: currentBranch.id,
      referenceType: 'إهلاك',
      referenceNumber: `DEPR-${Date.now().toString().slice(-4)}`,
      description: 'قيد إهلاك الأصول الثابتة الدوري',
      lines: [
        {
          id: `jl-d1-${Date.now()}`,
          accountId: accExpense.id,
          accountCode: accExpense.code,
          accountName: accExpense.nameAr,
          debit: totalDepr,
          credit: 0,
          currency: 'YER',
          exchangeRate: 1,
          memo: 'مصروف إهلاك أصول',
        },
        {
          id: `jl-d2-${Date.now()}`,
          accountId: accAccDepr.id,
          accountCode: accAccDepr.code,
          accountName: accAccDepr.nameAr,
          debit: 0,
          credit: totalDepr,
          currency: 'YER',
          exchangeRate: 1,
          memo: 'مجمع إهلاك الأصول',
        },
      ],
      totalDebit: totalDepr,
      totalCredit: totalDepr,
      status: 'posted',
      createdBy: currentUser.fullName,
      createdAt: new Date().toISOString(),
    };
    const updatedAssets = db.fixedAssets.map((a) => {
      if (a.status !== 'active' || a.currentBookValue <= a.salvageValue) return a;
      const monthly = Math.min(
        a.currentBookValue - a.salvageValue,
        Math.round((a.purchaseCost - a.salvageValue) / (a.usefulLifeMonths || 48))
      );
      return {
        ...a,
        totalAccumulatedDepreciation: a.totalAccumulatedDepreciation + monthly,
        currentBookValue: Math.max(a.salvageValue, a.currentBookValue - monthly),
      };
    });
    setDb((prev) => ({
      ...prev,
      fixedAssets: updatedAssets,
      journalEntries: [...prev.journalEntries, deprEntry],
    }));
  };

  const executeResetDatabase = () => {
    const pristine = resetToDemoDatabase();
    setDb(pristine);
    if (pristine.branches[0]) setCurrentBranch(pristine.branches[0]);
    if (pristine.currencies[0]) setCurrentCurrency(pristine.currencies[0]);
    if (pristine.users[0]) setCurrentUser(pristine.users[0]);
    setIsResetConfirmOpen(false);
    notify('success', 'تمت إعادة ضبط النظام إلى البيانات التجريبية بنجاح.');
  };

  const handleSaveColumnPrefs = useCallback((tableId: string, prefs: TableColumnPref[]) => {
    setDb((prev) => {
      const currentUi = prev.settings.uiPreferences || {
        fontSize: 14,
        accentPreset: 'amber',
        hiddenModules: [],
        tableColumnPrefs: {},
      };
      return {
        ...prev,
        settings: {
          ...prev.settings,
          uiPreferences: {
            ...currentUi,
            tableColumnPrefs: {
              ...(currentUi.tableColumnPrefs || {}),
              [tableId]: prefs,
            },
          },
        },
      };
    });
  }, []);

  const savedColPrefsMap = db.settings.uiPreferences?.tableColumnPrefs || {};

  // Visible tabs configuration
  const visibleTabs = useMemo(() => {
    const cfg = db.settings.uiPreferences?.tabsConfig;
    const base = cfg && cfg.length > 0 ? cfg : defaultTabsConfig;
    return base.filter((t) => t.visible || t.id === 'tab-admin');
  }, [db.settings.uiPreferences?.tabsConfig]);

  // Liquidity Total in Base Currency (YER)
  const totalLiquidityBase = useMemo(
    () =>
      db.treasuryAccounts
        .filter((t) => t.status === 'active')
        .reduce((sum, t) => sum + t.balance * getCurrencyRate(t.currency), 0),
    [db.treasuryAccounts, getCurrencyRate]
  );

  const helpTopic: HelpTopic = {
    title: 'نظام المنصور V20 المتكامل — دليل الاستخدام السريع',
    purpose: 'واجهة العمل السريعة بنظام الجداول ولوحة المفاتيح مع محرك القيد المزدوج وجرد المستودعات.',
    responsibleRole: 'المالك، المحاسب العام، الكاشير، أمين المستودع',
    operationalSteps: [
      'استخدم شريط التبويبات العلوي للتنقل الفوري بين الفواتير، السندات، الدفاتر، الجرد، العملاء، التقارير، الشجرة الموحدة، والتخصيص.',
      'داخل الجداول: اضغط ↑ و ↓ لإضافة والتنقل بين الصفوف، و Enter للانتقال السريع بين الحقول.',
      'استخدم زر "إدارة الدفاتر" لتحديد بادئات الترقيم وفتح دفاتر مخصصة لكل نشاط.',
    ],
    accountingImpact: 'يُنشئ النظام قيداً محاسبياً مزدوجاً متوازناً ويحدث أرصدة الصناديق والعملاء والموردين فوراً.',
    inventoryImpact: 'يُراقب الرصيد اللحظي في المستودعات ويمنع البيع بالسالب حسب سياسة المنشأة.',
    commonMistakes: ['إغلاق الفاتورة قبل اختيار الصنف من القائمة المنسدلة أو ضبط الكمية.'],
    bestPractices: 'مراجعة شريط السيولة العلوي والتقرير الشامل بنهاية كل وردية وأخذ نسخة احتياطية دورية.',
  };

  const unreadAlertsCount = db.taskAlerts.filter((t) => !t.isCompleted).length;

  const launcherItems: {
    labelAr: string;
    labelEn: string;
    tabId: V20TabId;
    reportsSubTab?: ReportsSubTabId;
    unifiedSubTab?: UnifiedSubTabId;
  }[] = [
    { labelAr: 'فاتورة مبيعات / مشتريات (نافذة مستقلة)', labelEn: 'New Invoice Window', tabId: 'tab-pos' },
    { labelAr: 'سند قبض / صرف جديد (نافذة مستقلة)', labelEn: 'New Voucher Window', tabId: 'tab-bonds' },
    { labelAr: 'كشف حساب عميل / مورد', labelEn: 'Party Account Statement', tabId: 'tab-reports', reportsSubTab: 'statement' },
    { labelAr: 'التقرير الشامل للإدارة', labelEn: 'Executive Comprehensive Report', tabId: 'tab-reports', reportsSubTab: 'v20_comp' },
    { labelAr: 'حركة العملاء اليومية والإرسال', labelEn: 'Daily Customer Movement', tabId: 'tab-reports', reportsSubTab: 'daily_customers' },
    { labelAr: 'مركز التقارير (22 تقريراً)', labelEn: '22 Reports Center', tabId: 'tab-reports', reportsSubTab: 'hub_22' },
    { labelAr: 'الدفاتر اليومية والقيود', labelEn: 'Journals & Ledgers', tabId: 'tab-ledgers' },
    { labelAr: 'الجرد والحركة والمستودعات', labelEn: 'Inventory & Stock', tabId: 'tab-inventory' },
    { labelAr: 'العملاء والموردون والعملات', labelEn: 'Parties & Currencies', tabId: 'tab-cust' },
    { labelAr: 'المصروفات والشجرة والرواتب', labelEn: 'Expenses, COA & HR', tabId: 'tab-unified-coa', unifiedSubTab: 'expenses' },
  ];

  const renderWorkbenchView = (opts: {
    tabId: V20TabId;
    focusedId?: string;
    rSubTab?: ReportsSubTabId;
    uSubTab?: UnifiedSubTabId;
    stmtTarget?: { type: 'customer' | 'vendor'; id: string } | null;
  }) => {
    switch (opts.tabId) {
      case 'tab-pos':
        return (
          <InvoiceWorkbench
            invoices={db.invoices}
            warehouseDocuments={db.warehouseDocuments || []}
            customers={db.customers}
            vendors={db.vendors}
            warehouses={db.warehouses}
            inventoryItems={db.inventoryItems}
            warehouseStock={db.warehouseStock}
            treasuryAccounts={db.treasuryAccounts}
            currencies={db.currencies}
            documentBooks={documentBooks}
            departments={db.departments || []}
            currentBranch={currentBranch}
            currentCurrency={currentCurrency}
            currentUser={currentUser}
            company={db.company}
            allowNegativeStock={db.settings.allowNegativeStock}
            defaultTaxRate={db.settings.defaultTaxRate}
            enableTax={db.settings.enableTax}
            autoDownloadInvoices={db.settings.autoDownloadInvoices}
            whatsappTemplates={db.settings.whatsappTemplates}
            savedColumnPrefs={savedColPrefsMap['v20-invoice-grid']}
            focusedRecordId={opts.focusedId}
            onSaveColumnPrefs={handleSaveColumnPrefs}
            onPostSalesInvoice={handlePostSalesInvoice}
            onPostPurchaseInvoice={handlePostPurchaseInvoice}
            onSaveDraftInvoice={handleSaveDraftInvoice}
            onCancelInvoice={handleCancelInvoice}
            onSaveWarehouseDoc={(doc) =>
              setDb((prev) => ({
                ...prev,
                warehouseDocuments: [doc, ...(prev.warehouseDocuments || [])],
              }))
            }
            onExecuteTransfer={handleExecuteTransfer}
            onSaveDocumentBook={handleSaveDocumentBook}
            onToggleDocumentBook={handleToggleDocumentBook}
            onSetDefaultDocumentBook={handleSetDefaultDocumentBook}
            onConsumeBookSequence={handleConsumeBookSequence}
            onQuickSaveCustomer={(c) =>
              setDb((prev) => ({
                ...prev,
                customers: prev.customers.some((x) => x.id === c.id)
                  ? prev.customers.map((x) => (x.id === c.id ? c : x))
                  : [c, ...prev.customers],
              }))
            }
            onQuickSaveVendor={(v) =>
              setDb((prev) => ({
                ...prev,
                vendors: prev.vendors.some((x) => x.id === v.id)
                  ? prev.vendors.map((x) => (x.id === v.id ? v : x))
                  : [v, ...prev.vendors],
              }))
            }
            onQuickSaveItem={(it) =>
              setDb((prev) => ({
                ...prev,
                inventoryItems: prev.inventoryItems.some((x) => x.id === it.id)
                  ? prev.inventoryItems.map((x) => (x.id === it.id ? it : x))
                  : [it, ...prev.inventoryItems],
              }))
            }
            onNotify={notify}
          />
        );
      case 'tab-bonds':
        return (
          <VoucherWorkbench
            vouchers={db.paymentVouchers}
            treasuryAccounts={db.treasuryAccounts}
            treasuryTransfers={db.treasuryTransfers}
            customers={db.customers}
            vendors={db.vendors}
            expenseCategories={db.expenseCategories}
            chartOfAccounts={db.chartOfAccounts}
            currencies={db.currencies}
            documentBooks={documentBooks}
            currentBranch={currentBranch}
            currentCurrency={currentCurrency}
            currentUser={currentUser}
            company={db.company}
            paymentMethods={db.settings.paymentMethods}
            whatsappTemplates={db.settings.whatsappTemplates}
            savedColumnPrefs={savedColPrefsMap['v20-bond-grid']}
            focusedRecordId={opts.focusedId}
            onSaveColumnPrefs={handleSaveColumnPrefs}
            onBatchPostVouchers={handleBatchPostVouchers}
            onCancelVoucher={handleCancelVoucher}
            onTreasuryTransfer={handleTreasuryTransfer}
            onSaveDocumentBook={handleSaveDocumentBook}
            onToggleDocumentBook={handleToggleDocumentBook}
            onSetDefaultDocumentBook={handleSetDefaultDocumentBook}
            onConsumeBookSequence={handleConsumeBookSequence}
            onNotify={notify}
          />
        );
      case 'tab-ledgers':
        return (
          <LedgersAccountingWorkbench
            chartOfAccounts={db.chartOfAccounts}
            journalEntries={db.journalEntries}
            costCenters={db.costCenters}
            invoices={db.invoices}
            paymentVouchers={db.paymentVouchers}
            expenseRecords={db.expenseRecords}
            customBooks={db.customBooks || []}
            customBookEntries={db.customBookEntries || []}
            treasuryAccounts={db.treasuryAccounts}
            customers={db.customers}
            vendors={db.vendors}
            expenseCategories={db.expenseCategories}
            currencies={db.currencies}
            currentBranch={currentBranch}
            currentCurrency={currentCurrency}
            currentUser={currentUser}
            company={db.company}
            savedColumnPrefs={savedColPrefsMap['v20-ledger-log']}
            focusedRecordId={opts.focusedId}
            onSaveColumnPrefs={handleSaveColumnPrefs}
            onPostManualEntry={handlePostManualEntry}
            onReverseJournalEntry={handleReverseJournalEntry}
            onSaveCustomBook={(book) =>
              setDb((prev) => {
                const list = prev.customBooks || [];
                const ex = list.some((b) => b.id === book.id);
                return {
                  ...prev,
                  customBooks: ex ? list.map((b) => (b.id === book.id ? book : b)) : [...list, book],
                };
              })
            }
            onSaveCustomBookEntry={handleSaveCustomBookEntry}
            onOpenPrintModal={openPrintDocWindow}
            onNotify={notify}
          />
        );
      case 'tab-inventory':
        return (
          <InventoryWorkbench
            items={db.inventoryItems}
            warehouses={db.warehouses}
            warehouseStock={db.warehouseStock}
            stockMovements={db.stockMovements}
            inventoryTransfers={db.inventoryTransfers}
            stocktakings={db.stocktakings}
            warehouseDocuments={db.warehouseDocuments || []}
            departments={db.departments || []}
            unitsOfMeasure={db.unitsOfMeasure || []}
            company={db.company}
            branch={currentBranch}
            currentUser={currentUser}
            currencySymbol={currentCurrency.symbol}
            savedColumnPrefsMap={savedColPrefsMap}
            focusedRecordId={opts.focusedId}
            onSaveColumnPrefs={handleSaveColumnPrefs}
            onSaveItem={(item) =>
              setDb((prev) => ({
                ...prev,
                inventoryItems: prev.inventoryItems.some((i) => i.id === item.id)
                  ? prev.inventoryItems.map((i) => (i.id === item.id ? item : i))
                  : [item, ...prev.inventoryItems],
              }))
            }
            onExecuteTransfer={handleExecuteTransfer}
            onReverseTransfer={handleReverseTransfer}
            onAdjustStock={handleAdjustStock}
            onSaveWarehouseDoc={(doc) =>
              setDb((prev) => ({
                ...prev,
                warehouseDocuments: [doc, ...(prev.warehouseDocuments || [])],
              }))
            }
            onSaveStocktaking={handleSaveStocktaking}
            onApproveStocktaking={handleApproveStocktaking}
            onNotify={notify}
          />
        );
      case 'tab-cust':
        return (
          <PartiesWorkbench
            customers={db.customers}
            vendors={db.vendors}
            regionalAreas={db.regionalAreas}
            currencies={db.currencies}
            company={db.company}
            branch={currentBranch}
            savedColumnPrefsMap={savedColPrefsMap}
            onSaveColumnPrefs={handleSaveColumnPrefs}
            onSaveCustomer={(c) =>
              setDb((prev) => ({
                ...prev,
                customers: prev.customers.some((x) => x.id === c.id)
                  ? prev.customers.map((x) => (x.id === c.id ? c : x))
                  : [c, ...prev.customers],
              }))
            }
            onSaveVendor={(v) =>
              setDb((prev) => ({
                ...prev,
                vendors: prev.vendors.some((x) => x.id === v.id)
                  ? prev.vendors.map((x) => (x.id === v.id ? v : x))
                  : [v, ...prev.vendors],
              }))
            }
            onSaveZone={(z: RegionalArea) =>
              setDb((prev) => ({
                ...prev,
                regionalAreas: prev.regionalAreas.some((x) => x.id === z.id)
                  ? prev.regionalAreas.map((x) => (x.id === z.id ? z : x))
                  : [...prev.regionalAreas, z],
              }))
            }
            onOpenStatement={(type, id) => {
              const partyName =
                type === 'customer'
                  ? db.customers.find((c) => c.id === id)?.nameAr
                  : db.vendors.find((v) => v.id === id)?.nameAr;
              spawnFloatingWindow({
                tabId: 'tab-reports',
                title: lang === 'en' ? `Statement: ${partyName || ''}` : `كشف حساب: ${partyName || ''}`,
                reportsSubTab: 'statement',
                statementTarget: { type, id },
              });
            }}
            onOpenPriceLookup={(customerId) => setPriceLookupModal({ open: true, customerId })}
            onNotify={notify}
          />
        );
      case 'tab-reports':
        return (
          <ReportsWorkbench
            db={db}
            currentBranch={currentBranch}
            currencySymbol={currentCurrency.symbol}
            lang={lang}
            initialSubTab={opts.rSubTab || 'v20_comp'}
            preselectedStatementParty={opts.stmtTarget}
            savedColumnPrefsMap={savedColPrefsMap}
            onSaveColumnPrefs={handleSaveColumnPrefs}
            onSaveCustomer={(c) =>
              setDb((prev) => ({
                ...prev,
                customers: prev.customers.some((x) => x.id === c.id)
                  ? prev.customers.map((x) => (x.id === c.id ? c : x))
                  : [c, ...prev.customers],
              }))
            }
            onSaveVendor={(v) =>
              setDb((prev) => ({
                ...prev,
                vendors: prev.vendors.some((x) => x.id === v.id)
                  ? prev.vendors.map((x) => (x.id === v.id ? v : x))
                  : [v, ...prev.vendors],
              }))
            }
            onOpenPrintModal={openPrintDocWindow}
            onNavigateToRecord={navigateToRecord}
            onAddTask={(task: TaskAlert) =>
              setDb((prev) => ({ ...prev, taskAlerts: [task, ...prev.taskAlerts] }))
            }
            onToggleTaskComplete={(taskId) =>
              setDb((prev) => ({
                ...prev,
                taskAlerts: prev.taskAlerts.map((t) =>
                  t.id === taskId ? { ...t, isCompleted: !t.isCompleted } : t
                ),
              }))
            }
            onUpdateSettings={(s) => setDb((prev) => ({ ...prev, settings: s }))}
            onAddDispatchLog={(log: DispatchLogEntry) =>
              setDb((prev) => ({ ...prev, dispatchLogs: [log, ...(prev.dispatchLogs || [])] }))
            }
            onRetryDispatch={(logId) =>
              setDb((prev) => ({
                ...prev,
                dispatchLogs: (prev.dispatchLogs || []).map((l) =>
                  l.id === logId ? { ...l, status: 'sent' as const, retryCount: l.retryCount + 1 } : l
                ),
              }))
            }
            onNotify={notify}
          />
        );
      case 'tab-unified-coa':
        return (
          <UnifiedOperationsWorkbench
            chartOfAccounts={db.chartOfAccounts}
            costCenters={db.costCenters}
            employees={db.employees}
            payrollRuns={db.payrollRuns}
            expenseCategories={db.expenseCategories}
            expenseRecords={db.expenseRecords}
            fixedAssets={db.fixedAssets}
            treasuryAccounts={db.treasuryAccounts}
            warehouses={db.warehouses}
            departments={db.departments || []}
            regionalAreas={db.regionalAreas}
            currencies={db.currencies}
            company={db.company}
            currentBranch={currentBranch}
            currentUser={currentUser}
            currencySymbol={currentCurrency.symbol}
            initialSubTab={opts.uSubTab || 'coa'}
            savedColumnPrefsMap={savedColPrefsMap}
            focusedRecordId={opts.focusedId}
            onSaveColumnPrefs={handleSaveColumnPrefs}
            onSaveAccount={(acc: Account) =>
              setDb((prev) => ({
                ...prev,
                chartOfAccounts: prev.chartOfAccounts.some((x) => x.id === acc.id)
                  ? prev.chartOfAccounts.map((x) => (x.id === acc.id ? acc : x))
                  : [...prev.chartOfAccounts, acc],
              }))
            }
            onSaveEmployee={(emp: Employee) =>
              setDb((prev) => ({
                ...prev,
                employees: prev.employees.some((x) => x.id === emp.id)
                  ? prev.employees.map((x) => (x.id === emp.id ? emp : x))
                  : [emp, ...prev.employees],
              }))
            }
            onDisbursePayroll={handleDisbursePayroll}
            onPostExpense={handlePostExpense}
            onSaveAsset={(asset: FixedAsset) =>
              setDb((prev) => ({
                ...prev,
                fixedAssets: prev.fixedAssets.some((x) => x.id === asset.id)
                  ? prev.fixedAssets.map((x) => (x.id === asset.id ? asset : x))
                  : [asset, ...prev.fixedAssets],
              }))
            }
            onRunDepreciation={handleRunDepreciation}
            onSaveTreasuryAccount={(acc: TreasuryAccount) =>
              setDb((prev) => ({
                ...prev,
                treasuryAccounts: prev.treasuryAccounts.some((t) => t.id === acc.id)
                  ? prev.treasuryAccounts.map((t) => (t.id === acc.id ? acc : t))
                  : [...prev.treasuryAccounts, acc],
              }))
            }
            onSaveWarehouse={(w: Warehouse) =>
              setDb((prev) => ({
                ...prev,
                warehouses: prev.warehouses.some((x) => x.id === w.id)
                  ? prev.warehouses.map((x) => (x.id === w.id ? w : x))
                  : [...prev.warehouses, w],
              }))
            }
            onSaveDepartment={(d: DepartmentItem) =>
              setDb((prev) => {
                const list = prev.departments || [];
                return {
                  ...prev,
                  departments: list.some((x) => x.id === d.id)
                    ? list.map((x) => (x.id === d.id ? d : x))
                    : [...list, d],
                };
              })
            }
            onSaveZone={(z: RegionalArea) =>
              setDb((prev) => ({
                ...prev,
                regionalAreas: prev.regionalAreas.some((x) => x.id === z.id)
                  ? prev.regionalAreas.map((x) => (x.id === z.id ? z : x))
                  : [...prev.regionalAreas, z],
              }))
            }
            onNotify={notify}
          />
        );
      case 'tab-admin':
        return (
          <SettingsWorkbench
            db={db}
            currentUser={currentUser}
            lang={lang}
            onChangeLanguage={handleChangeLanguage}
            onUpdateCompany={(c) => setDb((prev) => ({ ...prev, company: c }))}
            onUpdateSettings={(s) => setDb((prev) => ({ ...prev, settings: s }))}
            onSaveBranch={(b: Branch) =>
              setDb((prev) => ({
                ...prev,
                branches: prev.branches.some((x) => x.id === b.id)
                  ? prev.branches.map((x) => (x.id === b.id ? b : x))
                  : [...prev.branches, b],
              }))
            }
            onSaveWarehouse={(w: Warehouse) =>
              setDb((prev) => ({
                ...prev,
                warehouses: prev.warehouses.some((x) => x.id === w.id)
                  ? prev.warehouses.map((x) => (x.id === w.id ? w : x))
                  : [...prev.warehouses, w],
              }))
            }
            onSaveUnitOfMeasure={(u: UnitOfMeasure) =>
              setDb((prev) => {
                const list = prev.unitsOfMeasure || [];
                return {
                  ...prev,
                  unitsOfMeasure: list.some((x) => x.id === u.id)
                    ? list.map((x) => (x.id === u.id ? u : x))
                    : [...list, u],
                };
              })
            }
            onUpdateCurrencies={(currencies) => {
              setDb((prev) => ({ ...prev, currencies }));
              const updatedCurr = currencies.find((c) => c.code === currentCurrency.code);
              if (updatedCurr) setCurrentCurrency(updatedCurr);
            }}
            onUpdateUserPermissions={(u) => {
              setDb((prev) => ({
                ...prev,
                users: prev.users.map((usr) => (usr.id === u.id ? u : usr)),
              }));
              if (currentUser.id === u.id) setCurrentUser(u);
            }}
            onAddUser={(u) =>
              setDb((prev) => ({ ...prev, users: [...prev.users, u] }))
            }
            onSaveDocumentBook={handleSaveDocumentBook}
            onToggleDocumentBook={handleToggleDocumentBook}
            onSetDefaultDocumentBook={handleSetDefaultDocumentBook}
            onResetDatabase={executeResetDatabase}
            onRestoreDatabase={(restored) => {
              setDb(restored);
              if (restored.branches[0]) setCurrentBranch(restored.branches[0]);
              const baseCurr = restored.currencies.find((c) => c.isBase) || restored.currencies[0];
              if (baseCurr) setCurrentCurrency(baseCurr);
              if (restored.users[0]) setCurrentUser(restored.users[0]);
            }}
            onNotify={notify}
          />
        );
    }
  };

  return (
    <MdiWindowProvider lang={lang}>
    <div className="min-h-screen flex flex-col bg-[var(--bg-obsidian)] text-[var(--text-main)]" dir={lang === 'en' ? 'ltr' : 'rtl'}>
      {/* V20 Sticky Top System Header */}
      <header className="sticky top-0 z-40 bg-gradient-to-l from-[#071019] to-[#0D1A29] border-b-2 border-[var(--gold)] shadow-2xl no-print">
        <div className="max-w-[1700px] mx-auto px-3 py-2 space-y-2">
          {/* Top Row: Brand, Context Selectors & System Controls */}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-[var(--gold)] text-[#03060A] flex items-center justify-center font-black text-base shadow">
                {lang === 'en' ? 'M' : 'م'}
              </div>
              <div>
                <h1 className="text-sm sm:text-base font-black text-[var(--gold)] leading-tight">
                  {db.company.nameAr}
                </h1>
                <p className="text-[11px] text-[var(--text-secondary)] font-bold">
                  ALMANSOOR SMART FINANCE ERP · {currentBranch.nameAr}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 flex-wrap text-xs">
              {/* Branch Switcher */}
              <div className="flex items-center gap-1 bg-[#060D15] border border-[var(--border-strong)] rounded-md px-2 py-1">
                <Building2 className="w-3.5 h-3.5 text-[var(--gold)]" />
                <select
                  value={currentBranch.id}
                  onChange={(e) => {
                    const b = db.branches.find((x) => x.id === e.target.value);
                    if (b) setCurrentBranch(b);
                  }}
                  className="bg-transparent text-white font-bold outline-none cursor-pointer"
                >
                  {db.branches.map((b) => (
                    <option key={b.id} value={b.id} className="bg-[#071019]">
                      {b.nameAr}
                    </option>
                  ))}
                </select>
              </div>

              {/* Currency Switcher */}
              <div className="flex items-center gap-1 bg-[#060D15] border border-[var(--border-strong)] rounded-md px-2 py-1">
                <Coins className="w-3.5 h-3.5 text-[var(--gold)]" />
                <select
                  value={currentCurrency.code}
                  onChange={(e) => {
                    const c = db.currencies.find((x) => x.code === e.target.value);
                    if (c) setCurrentCurrency(c);
                  }}
                  className="bg-transparent text-white font-bold outline-none cursor-pointer"
                >
                  {db.currencies.map((c) => (
                    <option key={c.code} value={c.code} className="bg-[#071019]">
                      {c.code} ({c.exchangeRate})
                    </option>
                  ))}
                </select>
              </div>

              {/* Active User Switcher */}
              <div className="flex items-center gap-1 bg-[#060D15] border border-[var(--gold)] rounded-md px-2 py-1">
                <UserIcon className="w-3.5 h-3.5 text-[var(--gold)]" />
                <select
                  value={currentUser.id}
                  onChange={(e) => {
                    const u = db.users.find((x) => x.id === e.target.value);
                    if (u) setCurrentUser(u);
                  }}
                  className="bg-transparent text-[var(--gold)] font-black outline-none cursor-pointer"
                >
                  {db.users.map((u) => (
                    <option key={u.id} value={u.id} className="bg-[#071019] text-white">
                      {u.fullName} ({u.role})
                    </option>
                  ))}
                </select>
              </div>

              {/* Quick Global Search (Ctrl+K) */}
              <button
                type="button"
                onClick={() => setIsGlobalSearchOpen(true)}
                className="px-2.5 py-1.5 rounded-md bg-[#08121E] border border-[var(--border-strong)] hover:border-[var(--gold)] text-white font-black flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer transition"
                title={t('globalSearchTooltip', lang)}
              >
                <Search className="w-3.5 h-3.5 text-[var(--gold)]" />
                <span>{t('globalSearchBtn', lang)}</span>
                <span className="hidden md:inline font-mono text-[10px] px-1 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                  Ctrl+K
                </span>
              </button>

              {/* Quick Customer-Item Historical Price Lookup */}
              <button
                type="button"
                onClick={() => setPriceLookupModal({ open: true })}
                className="px-2.5 py-1.5 rounded-md bg-[#08121E] border border-sky-500/60 hover:border-[var(--gold)] text-sky-300 hover:text-[var(--gold)] font-black flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer transition"
                title={t('priceLookupTooltip', lang)}
              >
                <Tag className="w-3.5 h-3.5" />
                <span>{t('priceLookupBtn', lang)}</span>
              </button>

              {/* Multi-Window MDI Launcher */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setIsWinLauncherOpen((o) => !o)}
                  className="px-2.5 py-1.5 rounded-md bg-[var(--gold)] text-[#03060A] hover:bg-[var(--gold-hover)] font-black flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer transition shadow"
                  title={lang === 'en' ? 'Open a new floating MDI window alongside your current work' : 'فتح نافذة منبثقة جديدة للعمل بالتوازي مع الشاشة الحالية'}
                >
                  <PlusSquare className="w-3.5 h-3.5" />
                  <span>{lang === 'en' ? 'New Window' : 'نافذة منبثقة'}</span>
                  <ChevronDown className="w-3 h-3" />
                </button>
                {isWinLauncherOpen && (
                  <div
                    className={`absolute top-full mt-1.5 w-72 bg-[#091422] border-2 border-[var(--gold)] rounded-xl shadow-2xl p-1.5 z-[120] ${
                      lang === 'en' ? 'right-0' : 'left-0'
                    }`}
                  >
                    <div className="px-2.5 py-1.5 text-[11px] font-black text-[var(--gold)] border-b border-[var(--border-strong)] mb-1 flex items-center justify-between">
                      <span>{lang === 'en' ? 'Open Floating Popup Window' : 'فتح نافذة منبثقة جديدة'}</span>
                      <button
                        type="button"
                        onClick={() => setIsWinLauncherOpen(false)}
                        className="text-slate-400 hover:text-white cursor-pointer"
                      >
                        ✕
                      </button>
                    </div>
                    <div className="space-y-0.5 max-h-80 overflow-y-auto">
                      {launcherItems.map((item, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() =>
                            spawnFloatingWindow({
                              tabId: item.tabId,
                              title: lang === 'en' ? item.labelEn : item.labelAr,
                              reportsSubTab: item.reportsSubTab,
                              unifiedSubTab: item.unifiedSubTab,
                            })
                          }
                          className="w-full text-start px-2.5 py-1.5 rounded-lg text-xs font-bold text-slate-200 hover:bg-[var(--gold)] hover:text-[#03060A] flex items-center justify-between gap-2 cursor-pointer transition"
                        >
                          <span className="truncate">{lang === 'en' ? item.labelEn : item.labelAr}</span>
                          <ExternalLink className="w-3 h-3 shrink-0 opacity-70" />
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Quick Smart AI Advisor Shortcut */}
              <button
                type="button"
                onClick={() => {
                  setReportsSubTab('smart_ai');
                  setActiveTab('tab-reports');
                }}
                className="px-2.5 py-1.5 rounded-md bg-[#0D1E32] border border-[var(--gold)] text-[var(--gold)] hover:bg-[var(--gold)] hover:text-[#03060A] font-black flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer transition"
                title={t('repTabSmartAi', lang)}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{t('smartAiBtn', lang)}</span>
              </button>

              {/* Quick Bilingual Toggle (AR / EN) */}
              <button
                type="button"
                onClick={() => handleChangeLanguage(lang === 'ar' ? 'en' : 'ar')}
                className="px-2.5 py-1.5 rounded-md bg-[#08121E] border border-[var(--border-strong)] hover:border-[var(--gold)] text-white font-black flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer"
                title={t('langSwitchTooltip', lang)}
              >
                <Globe className="w-3.5 h-3.5 text-[var(--gold)]" />
                <span>{t('langBadge', lang)}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setReportsSubTab('tasks_dispatch');
                  setActiveTab('tab-reports');
                }}
                className="relative px-2.5 py-1.5 rounded-md bg-[#08121E] border border-[var(--border-strong)] text-white hover:border-[var(--gold)] flex items-center gap-1 cursor-pointer"
                title={t('alertsAndDispatch', lang)}
              >
                <Bell className="w-3.5 h-3.5 text-[var(--gold)]" />
                {unreadAlertsCount > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full bg-[var(--danger)] text-white text-[10px] font-black tabular-nums">
                    {unreadAlertsCount}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() => setIsHelpOpen(true)}
                className="px-2.5 py-1.5 rounded-md bg-[#08121E] border border-[var(--border-strong)] text-sky-300 hover:border-[var(--gold)] flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{t('help', lang)}</span>
              </button>

              <button
                type="button"
                onClick={() => setIsResetConfirmOpen(true)}
                className="px-2.5 py-1.5 rounded-md bg-[#2B0B0E] border border-[var(--danger)] text-[var(--danger)] hover:bg-[var(--danger)] hover:text-white flex items-center gap-1 cursor-pointer"
                title={t('resetDemo', lang)}
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Live Top Treasuries Liquidity Bar */}
          <div className="flex items-center gap-2 overflow-x-auto pb-0.5 text-[11px]">
            <div className="shrink-0 flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#050B12] border border-[var(--gold)] font-black text-[var(--gold)] tabular-nums">
              <Landmark className="w-3.5 h-3.5" />
              <span>{t('totalLiquidity', lang)}: {totalLiquidityBase.toLocaleString()} YER</span>
            </div>
            {db.treasuryAccounts
              .filter((tAcc) => tAcc.status === 'active')
              .map((tr) => (
                <div
                  key={tr.id}
                  className="shrink-0 flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#08121E] border border-[var(--border-strong)] text-slate-200 tabular-nums"
                >
                  <Wallet className="w-3 h-3 text-emerald-400" />
                  <span className="font-bold">{tr.nameAr}:</span>
                  <span className="font-black text-emerald-300">
                    {tr.balance.toLocaleString()} {tr.currency}
                  </span>
                </div>
              ))}
          </div>

          {/* V20 Dynamic Horizontal 8-Tab Navigation Bar + Instant Floating Popup Button */}
          <nav className="flex items-center gap-1.5 overflow-x-auto pt-1 border-t border-[var(--border-strong)]">
            {visibleTabs.map((tab) => {
              const isActive = activeTab === tab.id;
              const label = getTabLabel(tab.id, tab.label, lang);
              return (
                <div
                  key={tab.id}
                  className={`shrink-0 flex items-center rounded-t-md border transition ${
                    isActive
                      ? 'bg-[var(--gold)] text-[#03060A] border-[var(--gold)] shadow'
                      : 'bg-[#08121E] text-slate-200 border-[var(--border-strong)] hover:border-[var(--gold)]'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => {
                      setFocusedRecordId(undefined);
                      setActiveTab(tab.id as V20TabId);
                    }}
                    className="px-3 py-1.5 text-xs font-black cursor-pointer"
                  >
                    {label}
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      spawnFloatingWindow({
                        tabId: tab.id as V20TabId,
                        title: label,
                        reportsSubTab: tab.id === 'tab-reports' ? reportsSubTab : undefined,
                        unifiedSubTab: tab.id === 'tab-unified-coa' ? unifiedSubTab : undefined,
                      })
                    }
                    title={lang === 'en' ? `Open ${label} in floating MDI window` : `فتح "${label}" في نافذة منبثقة مستقلة`}
                    className={`px-1.5 py-1.5 text-[11px] cursor-pointer border-s ${
                      isActive
                        ? 'border-[#03060A]/25 text-[#03060A] hover:bg-black/10'
                        : 'border-[var(--border-strong)] text-[var(--gold)] hover:bg-[var(--gold)]/20'
                    }`}
                  >
                    <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
              );
            })}
          </nav>
        </div>
      </header>

      {/* Main Workspace Content (Keeps all visited tabs mounted so unsaved entries never disappear) */}
      <main className="flex-1 max-w-[1700px] w-full mx-auto p-3 md:p-4">
        {visitedTabs.map((tabId) => (
          <div key={tabId} className={activeTab === tabId ? '' : 'hidden'}>
            {renderWorkbenchView({
              tabId,
              focusedId: tabId === activeTab ? focusedRecordId : undefined,
              rSubTab: tabId === 'tab-reports' ? reportsSubTab : undefined,
              uSubTab: tabId === 'tab-unified-coa' ? unifiedSubTab : undefined,
              stmtTarget: tabId === 'tab-reports' ? statementTarget : undefined,
            })}
          </div>
        ))}
      </main>

      {/* Simultaneous Floating MDI Workspace Popup Windows */}
      {floatingWindows.map((win) => (
        <MdiFloatingFrame
          key={win.id}
          windowId={win.id}
          title={win.title}
          kind="workspace"
          defaultWidth={1080}
          defaultHeight={680}
          dir={lang === 'en' ? 'ltr' : 'rtl'}
          onClose={() => closeFloatingWindow(win.id)}
        >
          <div className="p-3">
            {renderWorkbenchView({
              tabId: win.tabId,
              focusedId: win.focusedRecordId,
              rSubTab: win.reportsSubTab,
              uSubTab: win.unifiedSubTab,
              stmtTarget: win.statementTarget,
            })}
          </div>
        </MdiFloatingFrame>
      ))}

      <GlobalSearchModal
        isOpen={isGlobalSearchOpen}
        onClose={() => setIsGlobalSearchOpen(false)}
        db={db}
        lang={lang}
        onNavigate={navigateToRecord}
      />

      <CustomerItemPriceModal
        isOpen={priceLookupModal.open}
        onClose={() => setPriceLookupModal({ open: false })}
        invoices={db.invoices}
        customers={db.customers}
        inventoryItems={db.inventoryItems}
        currencies={db.currencies}
        initialCustomerId={priceLookupModal.customerId}
        initialItemId={priceLookupModal.itemId}
        lang={lang}
        onOpenInvoice={(invId) => navigateToRecord('sales', invId)}
      />

      <HelpModal isOpen={isHelpOpen} onClose={() => setIsHelpOpen(false)} topic={helpTopic} lang={lang} />

      {printableDocs.map((p) => (
        <PrintModal
          key={p.id}
          isOpen
          onClose={() => closePrintDocWindow(p.id)}
          document={p.doc}
          company={db.company}
          branch={currentBranch}
          lang={lang}
        />
      ))}

      <ConfirmModal
        isOpen={isResetConfirmOpen}
        title={t('resetConfirmTitle', lang)}
        variant="danger"
        message={t('resetConfirmMsg', lang)}
        confirmLabel={t('resetConfirmBtn', lang)}
        onConfirm={executeResetDatabase}
        onCancel={() => setIsResetConfirmOpen(false)}
      />

      <ToastBanner
        toasts={toasts}
        onDismiss={(id) => setToasts((prev) => prev.filter((t) => t.id !== id))}
      />
    </div>
    </MdiWindowProvider>
  );
}
