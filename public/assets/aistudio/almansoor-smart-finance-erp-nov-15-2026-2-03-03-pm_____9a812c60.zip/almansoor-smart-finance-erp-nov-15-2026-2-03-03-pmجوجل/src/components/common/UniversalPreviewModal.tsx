/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * ALMANSOOR SMART FINANCE ERP - V20 Windows-Style Resizable Preview, Print, Binary PDF, Excel, WhatsApp & Bluetooth Modal
 */

import React, { useId, useState } from 'react';
import { createPortal } from 'react-dom';
import {
  Printer,
  FileDown,
  ImageDown,
  FileSpreadsheet,
  MessageCircle,
  Bluetooth,
} from 'lucide-react';
import { Company, Branch, Invoice, PaymentVoucher } from '../../types/erp';
import {
  ReportPDFOptions,
  SummaryCardDef,
  downloadReportAsPDF,
  downloadInvoicePDF,
  downloadVoucherPDF,
  exportToExcel,
  printReportPreview,
} from '../../services/exportService';
import {
  downloadPngPages,
  renderPayloadToPngPages,
} from '../../services/documentImageHelper';
import { MdiFloatingFrame } from './MdiWindowManager';
import { WhatsAppShareModal } from './WhatsAppShareModal';

export interface UniversalPreviewPayload {
  title: string;
  subtitle?: string;
  periodText?: string;
  reportCode?: string;
  metadata?: Record<string, string>;
  tables: {
    title?: string;
    headers: string[];
    rows: (string | number)[][];
    totals?: (string | number)[];
  }[];
  summaryCards?: SummaryCardDef[];
  notes?: string;
  whatsappText: string;
  defaultPhone?: string;
  bluetoothLines?: string[];
  invoiceObj?: Invoice;
  voucherObj?: PaymentVoucher;
  warehouseName?: string;
}

interface UniversalPreviewModalProps {
  isOpen: boolean;
  payload: UniversalPreviewPayload | null;
  company: Company;
  branch: Branch;
  lang?: 'ar' | 'en';
  onClose: () => void;
  onNotify?: (type: 'success' | 'error' | 'info', msg: string) => void;
}

function renderBidiSafeCell(val: string | number | undefined | null): React.ReactNode {
  if (val === undefined || val === null || val === '') return '-';
  const text = String(val);
  // If a string accidentally joins two currency values with "|", stack them safely on separate lines
  if (text.includes(' | ')) {
    const parts = text.split(' | ').map((p) => p.trim()).filter(Boolean);
    if (parts.length > 1) {
      return (
        <div className="flex flex-col gap-0.5 leading-tight">
          {parts.map((part, idx) => (
            <bdi key={idx} dir="auto" className="block">
              {part}
            </bdi>
          ))}
        </div>
      );
    }
  }
  return <bdi dir="auto">{text}</bdi>;
}

export const UniversalPreviewModal: React.FC<UniversalPreviewModalProps> = ({
  isOpen,
  payload,
  company,
  branch,
  lang = 'ar',
  onClose,
  onNotify,
}) => {
  const reactId = useId();
  const [isWaOpen, setIsWaOpen] = useState(false);
  const [isBusyPdf, setIsBusyPdf] = useState(false);
  const [isBusyPng, setIsBusyPng] = useState(false);

  if (!isOpen || !payload) return null;

  const pdfOptions: ReportPDFOptions = {
    title: payload.title,
    subtitle: payload.subtitle,
    reportCode: payload.reportCode,
    periodText: payload.periodText,
    metadata: payload.metadata,
    tables: payload.tables,
    summaryCards: payload.summaryCards,
    company,
    branch,
    notes: payload.notes,
    lang,
  };

  const handleCleanPrint = () => {
    printReportPreview(pdfOptions);
    onNotify?.('info', 'تم تجهيز المستند للطباعة المعزولة.');
  };

  const handleSavePdf = async () => {
    try {
      setIsBusyPdf(true);
      if (payload.invoiceObj) {
        await downloadInvoicePDF(payload.invoiceObj, company, branch, payload.warehouseName);
      } else if (payload.voucherObj) {
        await downloadVoucherPDF(payload.voucherObj, company, branch);
      } else {
        await downloadReportAsPDF(pdfOptions);
      }
      onNotify?.('success', 'تم إنشاء وتنزيل ملف PDF الثنائي بنجاح.');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'تعذر إنشاء ملف PDF';
      onNotify?.('error', msg);
    } finally {
      setIsBusyPdf(false);
    }
  };

  const handleSavePngPages = async () => {
    try {
      setIsBusyPng(true);
      const pages = await renderPayloadToPngPages(payload, company, branch);
      if (pages.length === 0) {
        onNotify?.('error', 'تعذر توليد صفحات الصورة.');
        return;
      }
      downloadPngPages(pages);
      onNotify?.(
        'success',
        pages.length > 1
          ? `تم حفظ ${pages.length} صفحات صور عالية الدقة (2480px) بنجاح بدون قص أو ضعف في الجودة.`
          : 'تم حفظ صورة المستند عالية الدقة (2480px PNG) بنجاح.'
      );
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'تعذر إنشاء صور PNG';
      onNotify?.('error', msg);
    } finally {
      setIsBusyPng(false);
    }
  };

  const handleExportExcel = () => {
    const sheets = payload.tables.map((t, idx) => ({
      name: t.title || `بيانات_${idx + 1}`,
      data: [t.headers, ...t.rows, ...(t.totals ? [t.totals] : [])],
    }));
    exportToExcel({
      fileName: `${payload.title.replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}`,
      sheets: sheets.length > 0 ? sheets : [{ name: 'ملخص', data: [[payload.title]] }],
    });
    onNotify?.('success', 'تم تصدير ملف Excel (.xlsx) بنجاح.');
  };

  const handleBluetoothPrint = async () => {
    const nav = navigator as Navigator & {
      bluetooth?: {
        requestDevice: (opts: { acceptAllDevices: boolean; optionalServices: string[] }) => Promise<{
          gatt?: {
            connect: () => Promise<{
              getPrimaryServices: () => Promise<
                {
                  getCharacteristics: () => Promise<
                    {
                      properties: { write?: boolean; writeWithoutResponse?: boolean };
                      writeValue: (data: Uint8Array) => Promise<void>;
                    }[]
                  >;
                }[]
              >;
            }>;
          };
        }>;
      };
    };

    if (!nav.bluetooth) {
      onNotify?.('error', 'المتصفح الحالي لا يدعم الطباعة بالبلوتوث المباشر (Web Bluetooth). يرجى استخدام Chrome أو Edge على سطح المكتب أو أندرويد.');
      return;
    }

    try {
      onNotify?.('info', 'جاري البحث عن طابعات البلوتوث القريبة...');
      const device = await nav.bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: [
          '000018f0-0000-1000-8000-00805f9b34fb',
          'e7810a71-73ae-499d-8c15-faa9aef0c3f2',
          '49535343-fe7d-4ae5-8fa9-9fafd205e455',
        ],
      });
      const server = await device.gatt?.connect();
      if (!server) throw new Error('تعذر الاتصال بخدمة GATT للطابعة');
      const services = await server.getPrimaryServices();
      let targetChar: {
        properties: { write?: boolean; writeWithoutResponse?: boolean };
        writeValue: (data: Uint8Array) => Promise<void>;
      } | null = null;

      for (const svc of services) {
        const chars = await svc.getCharacteristics();
        for (const ch of chars) {
          if (ch.properties.write || ch.properties.writeWithoutResponse) {
            targetChar = ch;
            break;
          }
        }
        if (targetChar) break;
      }
      if (!targetChar) {
        onNotify?.('error', 'الجهاز المتصل لا يدعم استقبال بيانات الطباعة النصية.');
        return;
      }

      const lines = payload.bluetoothLines && payload.bluetoothLines.length > 0
        ? payload.bluetoothLines
        : [company.nameAr, company.phone, '----------------', payload.title];
      const data = new TextEncoder().encode(lines.join('\n') + '\n\n\n\x1D\x56\x00');
      for (let i = 0; i < data.length; i += 20) {
        await targetChar.writeValue(data.slice(i, i + 20));
      }
      onNotify?.('success', 'تم إرسال الإيصال إلى طابعة البلوتوث بنجاح.');
    } catch (err: unknown) {
      const e = err as { name?: string; message?: string };
      if (e?.name !== 'NotFoundError') {
        onNotify?.('error', `خطأ بلوتوث: ${e?.message || 'غير معروف'}`);
      }
    }
  };

  const headerActions = (
    <div className="flex items-center gap-1.5 flex-wrap">
      <button
        type="button"
        onClick={handleCleanPrint}
        className="px-2.5 py-1.5 rounded-md text-xs font-black bg-[var(--gold)] text-[#03060A] hover:bg-[var(--gold-hover)] flex items-center gap-1 cursor-pointer whitespace-nowrap"
      >
        <Printer className="w-3.5 h-3.5" />
        <span>طباعة</span>
      </button>
      <button
        type="button"
        onClick={handleSavePdf}
        disabled={isBusyPdf}
        className="px-2.5 py-1.5 rounded-md text-xs font-black bg-[var(--info)] text-[#03060A] hover:brightness-110 flex items-center gap-1 cursor-pointer disabled:opacity-60 whitespace-nowrap"
      >
        <FileDown className="w-3.5 h-3.5" />
        <span>{isBusyPdf ? 'جاري PDF...' : 'حفظ PDF'}</span>
      </button>
      <button
        type="button"
        onClick={handleSavePngPages}
        disabled={isBusyPng}
        title="تصدير التقرير كصور A4 مقسّمة بدقة 2480 بكسل بدون فقدان الجودة"
        className="px-2.5 py-1.5 rounded-md text-xs font-black bg-amber-300 text-[#03060A] hover:brightness-105 flex items-center gap-1 cursor-pointer disabled:opacity-60 whitespace-nowrap"
      >
        <ImageDown className="w-3.5 h-3.5" />
        <span>{isBusyPng ? 'تجهيز PNG...' : 'صور عالية الدقة'}</span>
      </button>
      <button
        type="button"
        onClick={handleExportExcel}
        className="px-2.5 py-1.5 rounded-md text-xs font-black bg-[#10B981] text-[#03060A] hover:brightness-110 flex items-center gap-1 cursor-pointer whitespace-nowrap"
      >
        <FileSpreadsheet className="w-3.5 h-3.5" />
        <span>Excel</span>
      </button>
      <button
        type="button"
        onClick={() => setIsWaOpen(true)}
        className="px-2.5 py-1.5 rounded-md text-xs font-black bg-[#25D366] text-[#03060A] hover:brightness-110 flex items-center gap-1 cursor-pointer whitespace-nowrap"
      >
        <MessageCircle className="w-3.5 h-3.5" />
        <span>واتس</span>
      </button>
      <button
        type="button"
        onClick={handleBluetoothPrint}
        className="px-2.5 py-1.5 rounded-md text-xs font-black bg-[#3B82F6] text-white hover:brightness-110 flex items-center gap-1 cursor-pointer whitespace-nowrap"
      >
        <Bluetooth className="w-3.5 h-3.5" />
        <span>بلوتوث</span>
      </button>
    </div>
  );

  return (
    <>
      {createPortal(
        <MdiFloatingFrame
          windowId={`preview-${reactId}`}
          title={lang === 'en' ? `Preview: ${payload.title}` : `معاينة: ${payload.title}`}
          subtitle={payload.periodText || payload.subtitle}
          kind="preview"
          defaultWidth={960}
          defaultHeight={680}
          dir={lang === 'en' ? 'ltr' : 'rtl'}
          headerActions={headerActions}
          onClose={onClose}
        >
          {/* Paper Preview Viewport */}
          <div className="p-4 bg-[#071019]">
            <div className="preview-paper max-w-4xl mx-auto">
              {/* Header Banner or Corporate Title */}
              <div className="text-center border-b-2 border-black pb-3 mb-4">
                {company.useFullBanner && company.bannerBase64 ? (
                  <img
                    src={company.bannerBase64}
                    alt={company.nameAr}
                    className="w-full max-h-32 object-contain mx-auto mb-2"
                  />
                ) : (
                  <>
                    <h2 className="text-xl font-black text-black">{company.nameAr}</h2>
                    <p className="text-xs text-slate-800 mt-0.5">
                      {branch.nameAr} · {company.address} · هاتف: {company.phone}
                      {company.commercialRecord ? ` · س.ت: ${company.commercialRecord}` : ''}
                    </p>
                  </>
                )}
                <div className="mt-2 bg-slate-200 border border-black py-1 px-3 font-black text-sm text-black flex items-center justify-between flex-wrap gap-2">
                  <span>{payload.title}</span>
                  {payload.periodText && <span className="text-xs font-bold">{payload.periodText}</span>}
                </div>
              </div>

              {/* Metadata Grid */}
              {payload.metadata && Object.keys(payload.metadata).length > 0 && (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 bg-slate-50 border border-slate-400 p-2.5 mb-3 text-xs">
                  {Object.entries(payload.metadata).map(([k, v]) => (
                    <div key={k} className="flex items-center gap-1.5">
                      <span className="font-bold text-slate-700">{k}:</span>
                      <span className="font-black text-black">{v}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Tables (wrapped in overflow-x-auto so narrow mobile screens never clip columns) */}
              {payload.tables.map((t, tIdx) => (
                <div key={tIdx} className="mb-4">
                  {t.title && <h4 className="font-black text-sm text-black mb-1">{t.title}</h4>}
                  <div className="w-full overflow-x-auto">
                    <table>
                      <thead>
                        <tr>
                          {t.headers.map((h, i) => (
                            <th key={i} className="whitespace-nowrap">
                              {h}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {t.rows.length === 0 ? (
                          <tr>
                            <td colSpan={t.headers.length} className="text-center font-bold">
                              لا توجد بيانات
                            </td>
                          </tr>
                        ) : (
                          t.rows.map((row, rIdx) => (
                            <tr key={rIdx}>
                              {row.map((cell, cIdx) => (
                                <td key={cIdx} className="tabular-nums">
                                  {renderBidiSafeCell(cell)}
                                </td>
                              ))}
                            </tr>
                          ))
                        )}
                      </tbody>
                      {t.totals && t.totals.length > 0 && (
                        <tfoot>
                          <tr>
                            {t.totals.map((tot, idx) => (
                              <td key={idx} className="tabular-nums">
                                {renderBidiSafeCell(tot)}
                              </td>
                            ))}
                          </tr>
                        </tfoot>
                      )}
                    </table>
                  </div>
                </div>
              ))}

              {/* Summary Cards (Each currency renders on its own BiDi-isolated row so symbols never swap) */}
              {payload.summaryCards && payload.summaryCards.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 border-t-2 border-black pt-3 mt-3 text-xs">
                  {payload.summaryCards.map((c, idx) => {
                    const toneCls =
                      c.tone === 'green'
                        ? 'border-emerald-700 bg-emerald-50/70'
                        : c.tone === 'red'
                          ? 'border-rose-700 bg-rose-50/70'
                          : c.tone === 'gold'
                            ? 'border-amber-700 bg-amber-50/70'
                            : c.tone === 'blue'
                              ? 'border-sky-700 bg-sky-50/70'
                              : 'border-slate-400 bg-slate-50';
                    const legacyParts =
                      !c.subValue && c.value.includes(' | ')
                        ? c.value.split(' | ').map((x) => x.trim()).filter(Boolean)
                        : null;
                    return (
                      <div key={idx} className={`border ${toneCls} p-2.5 rounded`}>
                        <div className="text-slate-700 font-bold mb-1">{c.label}</div>
                        {legacyParts && legacyParts.length > 1 ? (
                          <div className="space-y-0.5 tabular-nums">
                            {legacyParts.map((part, pIdx) => (
                              <div key={pIdx} className={pIdx === 0 ? 'text-black font-black text-sm' : 'text-slate-800 font-bold text-xs'}>
                                <bdi dir="auto">{part}</bdi>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="space-y-0.5 tabular-nums">
                            <div className="text-black font-black text-sm leading-snug">
                              <bdi dir="auto">{c.value}</bdi>
                            </div>
                            {c.subValue && (
                              <div className="text-slate-800 font-bold text-xs leading-snug border-t border-black/10 pt-0.5">
                                <bdi dir="auto">{c.subValue}</bdi>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}

              {payload.notes && (
                <div className="mt-3 p-2 border border-slate-400 bg-slate-50 text-xs font-bold text-black">
                  ملاحظات: {payload.notes}
                </div>
              )}

              <div className="mt-5 pt-2 border-t border-dashed border-black text-center text-xs font-bold text-slate-700">
                {company.invoiceFooterNote || 'شكراً لتعاملكم معنا - نظام المنصور للإدارة المالية الذكية'}
              </div>
            </div>
          </div>
        </MdiFloatingFrame>,
        document.body
      )}

      <WhatsAppShareModal
        isOpen={isWaOpen}
        title={`مشاركة عبر واتساب: ${payload.title}`}
        defaultPhone={payload.defaultPhone}
        defaultMessage={payload.whatsappText}
        previewPayload={payload}
        company={company}
        branch={branch}
        onClose={() => setIsWaOpen(false)}
        onNotify={onNotify}
      />
    </>
  );
};
