/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * ALMANSOOR SMART FINANCE ERP - Genuine Binary PDF Engine
 * Static DejaVuSans Regular & Bold TTF (100% Arabic Presentation Forms-B + Latin + Numerals),
 * Logical-to-Visual UAX #9 BiDi without double-reversal, and Adaptive Table Layout.
 */

import { jsPDF } from 'jspdf';
import type { Company, Branch, Invoice, PaymentVoucher } from '../types/erp';
import type { ReportPDFOptions } from './exportService';

// [isolated, final, initial, medial] in Unicode Arabic Presentation Forms-B
const ARABIC_FORMS: Record<string, [string, string, string?, string?]> = {
  '\u0621': ['\uFE80', '\uFE80'],
  '\u0622': ['\uFE81', '\uFE82'],
  '\u0623': ['\uFE83', '\uFE84'],
  '\u0624': ['\uFE85', '\uFE86'],
  '\u0625': ['\uFE87', '\uFE88'],
  '\u0626': ['\uFE89', '\uFE8A', '\uFE8B', '\uFE8C'],
  '\u0627': ['\uFE8D', '\uFE8E'],
  '\u0628': ['\uFE8F', '\uFE90', '\uFE91', '\uFE92'],
  '\u0629': ['\uFE93', '\uFE94'],
  '\u062A': ['\uFE95', '\uFE96', '\uFE97', '\uFE98'],
  '\u062B': ['\uFE99', '\uFE9A', '\uFE9B', '\uFE9C'],
  '\u062C': ['\uFE9D', '\uFE9E', '\uFE9F', '\uFEA0'],
  '\u062D': ['\uFEA1', '\uFEA2', '\uFEA3', '\uFEA4'],
  '\u062E': ['\uFEA5', '\uFEA6', '\uFEA7', '\uFEA8'],
  '\u062F': ['\uFEA9', '\uFEAA'],
  '\u0630': ['\uFEAB', '\uFEAC'],
  '\u0631': ['\uFEAD', '\uFEAE'],
  '\u0632': ['\uFEAF', '\uFEB0'],
  '\u0633': ['\uFEB1', '\uFEB2', '\uFEB3', '\uFEB4'],
  '\u0634': ['\uFEB5', '\uFEB6', '\uFEB7', '\uFEB8'],
  '\u0635': ['\uFEB9', '\uFEBA', '\uFEBB', '\uFEBC'],
  '\u0636': ['\uFEBD', '\uFEBE', '\uFEBF', '\uFEC0'],
  '\u0637': ['\uFEC1', '\uFEC2', '\uFEC3', '\uFEC4'],
  '\u0638': ['\uFEC5', '\uFEC6', '\uFEC7', '\uFEC8'],
  '\u0639': ['\uFEC9', '\uFECA', '\uFECB', '\uFECC'],
  '\u063A': ['\uFECD', '\uFECE', '\uFECF', '\uFED0'],
  '\u0640': ['\u0640', '\u0640', '\u0640', '\u0640'],
  '\u0641': ['\uFED1', '\uFED2', '\uFED3', '\uFED4'],
  '\u0642': ['\uFED5', '\uFED6', '\uFED7', '\uFED8'],
  '\u0643': ['\uFED9', '\uFEDA', '\uFEDB', '\uFEDC'],
  '\u0644': ['\uFEDD', '\uFEDE', '\uFEDF', '\uFEE0'],
  '\u0645': ['\uFEE1', '\uFEE2', '\uFEE3', '\uFEE4'],
  '\u0646': ['\uFEE5', '\uFEE6', '\uFEE7', '\uFEE8'],
  '\u0647': ['\uFEE9', '\uFEEA', '\uFEEB', '\uFEEC'],
  '\u0648': ['\uFEED', '\uFEEE'],
  '\u0649': ['\uFEEF', '\uFEF0'],
  '\u064A': ['\uFEF1', '\uFEF2', '\uFEF3', '\uFEF4'],
};

const LAM_ALEF_LIGATURES: Record<string, [string, string]> = {
  '\u0622': ['\uFEF5', '\uFEF6'],
  '\u0623': ['\uFEF7', '\uFEF8'],
  '\u0625': ['\uFEF9', '\uFEFA'],
  '\u0627': ['\uFEFB', '\uFEFC'],
};

const ARABIC_DIACRITICS_REGEX = /[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]/g;

function canConnectAfter(ch: string | undefined): boolean {
  if (!ch) return false;
  const forms = ARABIC_FORMS[ch];
  return Boolean(forms && forms[2] && forms[3]);
}

function isArabicLetter(ch: string | undefined): boolean {
  if (!ch) return false;
  return Boolean(ARABIC_FORMS[ch]);
}

/**
 * Shapes logical Arabic characters into Presentation Forms-B including Lam-Alef ligatures.
 */
export function shapeArabicLogical(text: string): string {
  const cleaned = (text || '').replace(ARABIC_DIACRITICS_REGEX, '');
  const chars = Array.from(cleaned);
  const out: string[] = [];

  for (let i = 0; i < chars.length; i++) {
    const ch = chars[i];
    if (!isArabicLetter(ch)) {
      out.push(ch);
      continue;
    }

    const prevChar = i > 0 ? chars[i - 1] : undefined;
    const prevConnects = canConnectAfter(prevChar);

    if (ch === '\u0644' && i + 1 < chars.length && LAM_ALEF_LIGATURES[chars[i + 1]]) {
      const lig = LAM_ALEF_LIGATURES[chars[i + 1]];
      out.push(prevConnects ? lig[1] : lig[0]);
      i += 1;
      continue;
    }

    const nextChar = i + 1 < chars.length ? chars[i + 1] : undefined;
    const nextIsArabic = isArabicLetter(nextChar);
    const forms = ARABIC_FORMS[ch];
    const hasInitial = Boolean(forms[2]);
    const hasMedial = Boolean(forms[3]);

    if (prevConnects && nextIsArabic && hasMedial) {
      out.push(forms[3]!);
    } else if (prevConnects && forms[1]) {
      out.push(forms[1]);
    } else if (!prevConnects && nextIsArabic && hasInitial) {
      out.push(forms[2]!);
    } else {
      out.push(forms[0]);
    }
  }

  return out.join('');
}

function containsArabic(text: string): boolean {
  return /[\u0600-\u06FF\uFE70-\uFEFC]/.test(text);
}

/**
 * Prepares logical Arabic/mixed text for jsPDF 4.x's native Logical->Visual BiDi engine:
 * - Strips diacritics/control clutter that break metrics
 * - Preserves logical character order (NO manual reversal that would cause double-reversal!)
 * - Wraps dates (YYYY-MM-DD / DD/MM/YYYY), document codes (BAK-1001), and signed numbers (-500.00)
 *   with LRM (\u200E) inside RTL sentences so numbers/dates never flip order.
 */
export function prepareArabicPdfText(input: string | number | undefined | null): string {
  if (input === undefined || input === null) return '';
  const raw = String(input)
    .replace(ARABIC_DIACRITICS_REGEX, '')
    .replace(/[\u200B-\u200F\u202A-\u202E]/g, '');
  if (!raw) return '';
  if (!containsArabic(raw)) return raw;

  return raw.replace(
    /(?:\([A-Za-z0-9.,:/%\-_+# ]+\)|[A-Za-z0-9#+-][A-Za-z0-9.,:/%\-_+#()]*(?:[ \t]+[A-Za-z0-9.,:/%\-_+#()]*[A-Za-z0-9)])*)/g,
    '\u200E$&\u200E'
  );
}

let cachedRegularFontB64: string | null = null;
let cachedBoldFontB64: string | null = null;

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  const chunks: string[] = [];
  for (let i = 0; i < bytes.length; i += chunkSize) {
    chunks.push(String.fromCharCode(...bytes.subarray(i, i + chunkSize)));
  }
  if (typeof btoa === 'function') {
    return btoa(chunks.join(''));
  }
  return Buffer.from(bytes).toString('base64');
}

async function fetchOrReadFont(fileName: string): Promise<string> {
  if (typeof window !== 'undefined' && typeof fetch === 'function') {
    const resp = await fetch(`/fonts/${fileName}`);
    if (!resp.ok) {
      throw new Error(`تعذر تحميل خط الطباعة العربية (${fileName} HTTP ${resp.status})`);
    }
    const buf = await resp.arrayBuffer();
    return arrayBufferToBase64(buf);
  }

  const fsMod = 'node:fs';
  const pathMod = 'node:path';
  const fs = await import(/* @vite-ignore */ fsMod);
  const path = await import(/* @vite-ignore */ pathMod);
  const fontPath = path.resolve(process.cwd(), 'public/fonts', fileName);
  const buf: Buffer = fs.readFileSync(fontPath);
  return buf.toString('base64');
}

async function loadArabicPdfFonts(): Promise<{ regular: string; bold: string }> {
  if (!cachedRegularFontB64) {
    cachedRegularFontB64 = await fetchOrReadFont('DejaVuSans.ttf');
  }
  if (!cachedBoldFontB64) {
    try {
      cachedBoldFontB64 = await fetchOrReadFont('DejaVuSans-Bold.ttf');
    } catch {
      cachedBoldFontB64 = cachedRegularFontB64;
    }
  }
  return { regular: cachedRegularFontB64, bold: cachedBoldFontB64 };
}

async function createArabicDoc(orientation: 'portrait' | 'landscape'): Promise<jsPDF> {
  const doc = new jsPDF({
    orientation,
    unit: 'mm',
    format: 'a4',
    compress: true,
  });

  const { regular, bold } = await loadArabicPdfFonts();
  doc.addFileToVFS('DejaVuSans.ttf', regular);
  doc.addFont('DejaVuSans.ttf', 'DejaVu', 'normal');
  doc.addFileToVFS('DejaVuSans-Bold.ttf', bold);
  doc.addFont('DejaVuSans-Bold.ttf', 'DejaVu', 'bold');
  doc.setFont('DejaVu', 'normal');
  return doc;
}

/**
 * Draws text using jsPDF's native Logical->Visual BiDi engine without double reversal.
 */
function drawPdfText(
  doc: jsPDF,
  text: string | number | undefined | null,
  x: number,
  y: number,
  align: 'left' | 'center' | 'right' = 'right',
  forceLtrParagraph = false
): void {
  const prepared = prepareArabicPdfText(text);
  if (!prepared) return;
  const hasAr = !forceLtrParagraph && containsArabic(prepared);
  doc.text(prepared, x, y, {
    align,
    isInputVisual: false,
    isOutputVisual: true,
    isInputRtl: hasAr,
    isOutputRtl: false,
    isSymmetricSwapping: true,
  } as Record<string, unknown>);
}

function pdfNum(val: number | undefined | null, decimals = 2): string {
  return Number(val || 0).toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

/**
 * Measures logical text width safely against actual PDF cell width (mm) and wraps words cleanly.
 */
function wrapTextToWidth(doc: jsPDF, text: string, maxWidthMm: number): string[] {
  const str = String(text ?? '').replace(/\s+/g, ' ').trim();
  if (!str) return ['-'];
  const safeMax = Math.max(maxWidthMm, 8);
  if (doc.getTextWidth(str) <= safeMax) return [str];

  const words = str.split(' ');
  const lines: string[] = [];
  let current = '';

  const pushChunkedWord = (word: string) => {
    let part = '';
    for (const ch of Array.from(word)) {
      if (part && doc.getTextWidth(part + ch) > safeMax) {
        lines.push(part);
        part = ch;
      } else {
        part += ch;
      }
    }
    return part;
  };

  for (const w of words) {
    const candidate = current ? `${current} ${w}` : w;
    if (doc.getTextWidth(candidate) <= safeMax) {
      current = candidate;
    } else {
      if (current) lines.push(current);
      if (doc.getTextWidth(w) > safeMax) {
        current = pushChunkedWord(w);
      } else {
        current = w;
      }
    }
  }
  if (current) lines.push(current);
  return lines.length > 0 ? lines : [str];
}

/**
 * Generates a multi-page executive PDF for any ReportPDFOptions structure.
 */
export async function buildReportPdfBytes(options: ReportPDFOptions): Promise<Uint8Array> {
  const maxCols = Math.max(...options.tables.map((t) => t.headers.length), 4);
  const orientation: 'portrait' | 'landscape' = maxCols > 5 ? 'landscape' : 'portrait';
  const doc = await createArabicDoc(orientation);
  const isEnDoc = options.lang === 'en';

  doc.setProperties({
    title: options.title,
    subject: options.subtitle || 'ALMANSOOR SMART FINANCE ERP',
    author: options.company?.nameAr || 'Almansoor ERP',
    creator: 'Almansoor Smart Finance ERP PDF Engine',
  });

  const pageW = doc.internal.pageSize.getWidth();
  const pageH = doc.internal.pageSize.getHeight();
  const margin = 10;
  const contentW = pageW - margin * 2;
  let y = margin;

  const drawHeader = () => {
    doc.setFillColor(15, 23, 42);
    doc.rect(margin, margin, contentW, 22, 'F');
    doc.setFillColor(217, 119, 6);
    doc.rect(margin, margin + 22, contentW, 1.2, 'F');

    doc.setFont('DejaVu', 'bold');
    doc.setTextColor(251, 191, 36);
    doc.setFontSize(12);
    drawPdfText(
      doc,
      options.company?.nameAr || 'المنصور للأنظمة المالية والإدارية الذكية',
      pageW - margin - 4,
      margin + 8,
      'right',
      isEnDoc
    );

    doc.setFont('DejaVu', 'normal');
    doc.setTextColor(226, 232, 240);
    doc.setFontSize(8);
    const subCompanyParts = [
      options.branch?.nameAr || 'الفرع الرئيسي',
      options.company?.commercialRecord ? `CR: ${options.company.commercialRecord}` : '',
      options.company?.taxNumber ? `TAX: ${options.company.taxNumber}` : '',
      options.company?.phone || '',
    ]
      .filter(Boolean)
      .join('  |  ');
    drawPdfText(doc, subCompanyParts, pageW - margin - 4, margin + 15.5, 'right', isEnDoc);

    doc.setFont('DejaVu', 'bold');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(11);
    const titleWrapped = wrapTextToWidth(doc, options.title, contentW * 0.45);
    drawPdfText(doc, titleWrapped[0], margin + 4, margin + 8.5, 'left', isEnDoc);

    doc.setFont('DejaVu', 'normal');
    doc.setTextColor(203, 213, 225);
    doc.setFontSize(8);
    const leftMeta = options.periodText
      ? `${isEnDoc ? 'Period' : 'الفترة'}: ${options.periodText}`
      : options.subtitle || options.reportCode || '';
    drawPdfText(doc, leftMeta, margin + 4, margin + 15.5, 'left', isEnDoc);

    y = margin + 27;
  };

  const ensureSpace = (needed: number) => {
    if (y + needed > pageH - 16) {
      doc.addPage();
      drawHeader();
      return true;
    }
    return false;
  };

  drawHeader();

  // Metadata grid (2 responsive columns with text wrapping so values never overlap)
  if (options.metadata && Object.keys(options.metadata).length > 0) {
    const entries = Object.entries(options.metadata);
    const cols = 2;
    const colW = contentW / cols;
    doc.setFont('DejaVu', 'normal');
    doc.setFontSize(8);

    const metaPairs: { lines: string[]; height: number }[] = entries.map(([k, v]) => {
      const wrapped = wrapTextToWidth(doc, `${k}: ${v}`, colW - 8);
      return { lines: wrapped, height: wrapped.length * 4.2 + 2.5 };
    });

    const rowHeights: number[] = [];
    for (let i = 0; i < metaPairs.length; i += cols) {
      const h1 = metaPairs[i]?.height || 6;
      const h2 = metaPairs[i + 1]?.height || 0;
      rowHeights.push(Math.max(h1, h2));
    }
    const boxH = rowHeights.reduce((s, h) => s + h, 0) + 4;
    ensureSpace(boxH + 4);

    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(203, 213, 225);
    doc.rect(margin, y, contentW, boxH, 'FD');

    let curMetaY = y + 5;
    for (let r = 0; r < rowHeights.length; r++) {
      for (let c = 0; c < cols; c++) {
        const item = metaPairs[r * cols + c];
        if (!item) continue;
        const cellX = isEnDoc
          ? margin + c * colW + 4
          : pageW - margin - c * colW - 4;
        doc.setTextColor(15, 23, 42);
        item.lines.forEach((ln, lIdx) => {
          drawPdfText(
            doc,
            ln,
            cellX,
            curMetaY + lIdx * 4.2,
            isEnDoc ? 'left' : 'right',
            isEnDoc
          );
        });
      }
      curMetaY += rowHeights[r];
    }

    y += boxH + 4;
  }

  // Tables
  for (const table of options.tables) {
    if (table.title) {
      ensureSpace(13);
      doc.setFillColor(241, 245, 249);
      doc.rect(margin, y, contentW, 7, 'F');
      doc.setFillColor(217, 119, 6);
      doc.rect(isEnDoc ? margin : pageW - margin - 2, y, 2, 7, 'F');
      doc.setFont('DejaVu', 'bold');
      doc.setTextColor(15, 23, 42);
      doc.setFontSize(9.5);
      drawPdfText(
        doc,
        table.title,
        isEnDoc ? margin + 5 : pageW - margin - 5,
        y + 5,
        isEnDoc ? 'left' : 'right',
        isEnDoc
      );
      y += 8.5;
    }

    const colCount = Math.max(table.headers.length, 1);
    const bodyFontSize = colCount >= 10 ? 6.8 : colCount >= 8 ? 7.3 : 8;
    const headerFontSize = colCount >= 10 ? 7 : colCount >= 8 ? 7.5 : 8;
    const lineHeightMm = bodyFontSize * 0.52;

    // Proportional column widths based on actual header & content lengths
    const weights = table.headers.map((h, cIdx) => {
      const sampleLens = table.rows.slice(0, 35).map((r) => String(r[cIdx] ?? '').length);
      const maxLen = Math.max(String(h).length, ...sampleLens, 3);
      return Math.min(Math.max(maxLen, 5), 32);
    });
    const weightSum = weights.reduce((s, w) => s + w, 0) || colCount;
    const minColMm = Math.min(13, contentW / colCount);
    const colWidths = weights.map((w) => Math.max(minColMm, (w / weightSum) * contentW));
    const widthTotal = colWidths.reduce((s, w) => s + w, 0);
    const scaleFactor = contentW / widthTotal;
    const finalColWidths = colWidths.map((w) => w * scaleFactor);

    const colLeftAt = (cIdx: number): number => {
      if (isEnDoc) {
        let offset = 0;
        for (let i = 0; i < cIdx; i++) offset += finalColWidths[i];
        return margin + offset;
      }
      let rightOffset = 0;
      for (let i = 0; i <= cIdx; i++) rightOffset += finalColWidths[i];
      return pageW - margin - rightOffset;
    };

    const drawColGridLines = (rowY: number, rowH: number, color: [number, number, number]) => {
      doc.setDrawColor(color[0], color[1], color[2]);
      let acc = 0;
      for (let i = 0; i < colCount - 1; i++) {
        acc += finalColWidths[i];
        const lx = isEnDoc ? margin + acc : pageW - margin - acc;
        doc.line(lx, rowY, lx, rowY + rowH);
      }
    };

    const drawTableHeader = () => {
      doc.setFont('DejaVu', 'bold');
      doc.setFontSize(headerFontSize);
      const headerWrapped = table.headers.map((h, i) =>
        wrapTextToWidth(doc, String(h), finalColWidths[i] - 3)
      );
      const headerLines = Math.max(...headerWrapped.map((l) => l.length), 1);
      const headerH = Math.max(8, headerLines * (lineHeightMm + 0.5) + 3);
      doc.setFillColor(30, 41, 59);
      doc.rect(margin, y, contentW, headerH, 'F');
      drawColGridLines(y, headerH, [71, 85, 105]);
      doc.setTextColor(255, 255, 255);
      headerWrapped.forEach((lines, cIdx) => {
        const cellLeft = colLeftAt(cIdx);
        const w = finalColWidths[cIdx];
        lines.forEach((ln, lineIdx) => {
          drawPdfText(
            doc,
            ln,
            cellLeft + w / 2,
            y + 4.8 + lineIdx * (lineHeightMm + 0.4),
            'center',
            isEnDoc
          );
        });
      });
      y += headerH;
    };

    ensureSpace(16);
    drawTableHeader();

    doc.setFont('DejaVu', 'normal');
    doc.setFontSize(bodyFontSize);

    table.rows.forEach((row, rIdx) => {
      doc.setFont('DejaVu', 'normal');
      doc.setFontSize(bodyFontSize);
      const wrappedCells = row.map((cell, cIdx) => {
        const w = finalColWidths[cIdx] ?? contentW / colCount;
        return wrapTextToWidth(doc, String(cell ?? '-'), w - 3);
      });
      const maxLines = Math.max(...wrappedCells.map((l) => l.length), 1);
      const rowH = Math.max(6.5, maxLines * (lineHeightMm + 0.5) + 2.4);

      if (ensureSpace(rowH + 2)) {
        drawTableHeader();
        doc.setFont('DejaVu', 'normal');
        doc.setFontSize(bodyFontSize);
      }

      if (rIdx % 2 === 1) {
        doc.setFillColor(248, 250, 252);
        doc.rect(margin, y, contentW, rowH, 'F');
      }
      doc.setDrawColor(226, 232, 240);
      doc.rect(margin, y, contentW, rowH, 'S');
      drawColGridLines(y, rowH, [226, 232, 240]);

      doc.setTextColor(30, 41, 59);
      wrappedCells.forEach((lines, cIdx) => {
        const cellLeft = colLeftAt(cIdx);
        const w = finalColWidths[cIdx] ?? contentW / colCount;
        const alignPref = table.alignments?.[cIdx] || 'center';
        lines.forEach((ln, lineIdx) => {
          const ty = y + 4.3 + lineIdx * (lineHeightMm + 0.5);
          if (alignPref === 'right') {
            drawPdfText(doc, ln, cellLeft + w - 1.5, ty, 'right', isEnDoc);
          } else if (alignPref === 'left') {
            drawPdfText(doc, ln, cellLeft + 1.5, ty, 'left', isEnDoc);
          } else {
            drawPdfText(doc, ln, cellLeft + w / 2, ty, 'center', isEnDoc);
          }
        });
      });

      y += rowH;
    });

    if (table.totals && table.totals.length > 0) {
      doc.setFont('DejaVu', 'bold');
      doc.setFontSize(bodyFontSize);
      const totWrapped = table.totals.map((tot, cIdx) => {
        const rawTot = String(tot ?? '').trim();
        return rawTot ? wrapTextToWidth(doc, rawTot, (finalColWidths[cIdx] ?? 20) - 3) : [''];
      });
      const totLines = Math.max(...totWrapped.map((l) => l.length), 1);
      const totH = Math.max(7.5, totLines * (lineHeightMm + 0.5) + 2.5);
      ensureSpace(totH + 2);
      doc.setFillColor(254, 243, 199);
      doc.setDrawColor(217, 119, 6);
      doc.rect(margin, y, contentW, totH, 'FD');
      drawColGridLines(y, totH, [217, 119, 6]);
      doc.setTextColor(120, 53, 15);
      totWrapped.forEach((lines, cIdx) => {
        const cellLeft = colLeftAt(cIdx);
        const w = finalColWidths[cIdx] ?? contentW / colCount;
        lines.forEach((ln, lineIdx) => {
          drawPdfText(
            doc,
            ln,
            cellLeft + w / 2,
            y + 4.8 + lineIdx * (lineHeightMm + 0.5),
            'center',
            isEnDoc
          );
        });
      });
      y += totH + 1;
    }

    y += 3.5;
  }

  // Summary Cards in PDF (3 per row, stacked primary & secondary currency rows)
  if (options.summaryCards && options.summaryCards.length > 0) {
    const cols = 3;
    const gap = 3;
    const cardW = (contentW - gap * (cols - 1)) / cols;
    const hasSub = options.summaryCards.some((c) => Boolean(c.subValue) || (c.value || '').includes(' | '));
    const cardH = hasSub ? 17 : 12.5;
    const rowsCount = Math.ceil(options.summaryCards.length / cols);

    for (let r = 0; r < rowsCount; r++) {
      ensureSpace(cardH + 3);
      for (let c = 0; c < cols; c++) {
        const card = options.summaryCards[r * cols + c];
        if (!card) continue;
        const cx = isEnDoc ? margin + c * (cardW + gap) : pageW - margin - (c + 1) * cardW - c * gap;
        doc.setFillColor(248, 250, 252);
        doc.setDrawColor(148, 163, 184);
        doc.rect(cx, y, cardW, cardH, 'FD');

        doc.setFont('DejaVu', 'normal');
        doc.setFontSize(7);
        doc.setTextColor(71, 85, 105);
        const labelLines = wrapTextToWidth(doc, card.label, cardW - 4);
        drawPdfText(doc, labelLines[0], isEnDoc ? cx + 2 : cx + cardW - 2, y + 4.3, isEnDoc ? 'left' : 'right', isEnDoc);

        const parts =
          !card.subValue && (card.value || '').includes(' | ')
            ? card.value.split(' | ').map((x) => x.trim()).filter(Boolean)
            : [card.value, ...(card.subValue ? [card.subValue] : [])];

        doc.setFont('DejaVu', 'bold');
        doc.setFontSize(8);
        doc.setTextColor(15, 23, 42);
        const p1Lines = wrapTextToWidth(doc, parts[0] || '', cardW - 4);
        drawPdfText(doc, p1Lines[0], isEnDoc ? cx + 2 : cx + cardW - 2, y + 9.8, isEnDoc ? 'left' : 'right', isEnDoc);

        if (parts[1]) {
          doc.setFont('DejaVu', 'normal');
          doc.setFontSize(7.2);
          doc.setTextColor(51, 65, 85);
          const p2Lines = wrapTextToWidth(doc, parts[1], cardW - 4);
          drawPdfText(doc, p2Lines[0], isEnDoc ? cx + 2 : cx + cardW - 2, y + 14.5, isEnDoc ? 'left' : 'right', isEnDoc);
        }
      }
      y += cardH + 2.5;
    }
    y += 2;
  }

  // Notes & Signatures
  if (options.notes) {
    doc.setFont('DejaVu', 'normal');
    doc.setFontSize(8);
    const noteLines = wrapTextToWidth(
      doc,
      `${isEnDoc ? 'Notes' : 'ملاحظات'}: ${options.notes}`,
      contentW - 8
    );
    const noteH = noteLines.length * 4.5 + 4.5;
    ensureSpace(noteH + 4);
    doc.setFillColor(240, 253, 244);
    doc.setDrawColor(187, 247, 208);
    doc.rect(margin, y, contentW, noteH, 'FD');
    doc.setTextColor(22, 101, 52);
    noteLines.forEach((ln, idx) => {
      drawPdfText(
        doc,
        ln,
        isEnDoc ? margin + 4 : pageW - margin - 4,
        y + 5.5 + idx * 4.5,
        isEnDoc ? 'left' : 'right',
        isEnDoc
      );
    });
    y += noteH + 4;
  }

  ensureSpace(20);
  const sigW = contentW / 3;
  const sigTitles = isEnDoc
    ? ['Prepared By', 'Reviewed By', 'Approved By']
    : ['إعداد / المحاسب', 'المراجعة والتدقيق', 'اعتماد الإدارة'];
  const sigNames = isEnDoc
    ? [options.preparedBy || 'Financial Accountant', 'Chief Accountant', 'General Manager']
    : [options.preparedBy || 'المحاسب المالي', 'رئيس الحسابات', 'المدير العام'];
  sigTitles.forEach((title, idx) => {
    const sx = isEnDoc ? margin + idx * sigW : pageW - margin - (idx + 1) * sigW;
    doc.setDrawColor(203, 213, 225);
    doc.rect(sx + 2, y, sigW - 4, 15, 'S');
    doc.setFont('DejaVu', 'bold');
    doc.setTextColor(71, 85, 105);
    doc.setFontSize(7.5);
    drawPdfText(doc, title, sx + sigW / 2, y + 5, 'center', isEnDoc);
    doc.setFont('DejaVu', 'normal');
    doc.setTextColor(15, 23, 42);
    drawPdfText(doc, sigNames[idx], sx + sigW / 2, y + 12, 'center', isEnDoc);
  });

  // Page numbers & footer
  const totalPages = doc.getNumberOfPages();
  const stamp = new Date().toISOString().slice(0, 16).replace('T', ' ');
  for (let p = 1; p <= totalPages; p++) {
    doc.setPage(p);
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, pageH - 10, pageW - margin, pageH - 10);
    doc.setFont('DejaVu', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.setFontSize(7.5);
    drawPdfText(
      doc,
      `${isEnDoc ? 'ALMANSOOR SMART FINANCE ERP' : 'المنصور للأنظمة المالية الذكية ERP'} | ${stamp}`,
      pageW - margin,
      pageH - 5.8,
      'right',
      isEnDoc
    );
    drawPdfText(
      doc,
      isEnDoc ? `Page ${p} of ${totalPages}` : `صفحة ${p} من ${totalPages}`,
      margin,
      pageH - 5.8,
      'left',
      isEnDoc
    );
  }

  const ab = doc.output('arraybuffer');
  return new Uint8Array(ab);
}

/**
 * Generates a genuine binary PDF document for Sales / Purchase / Return Invoices.
 */
export async function buildInvoicePdfBytes(
  invoice: Invoice,
  company?: Company,
  branch?: Branch,
  warehouseName?: string
): Promise<Uint8Array> {
  const docLabel =
    invoice.type === 'مبيعات'
      ? 'فاتورة مبيعات'
      : invoice.type === 'مشتريات'
      ? 'فاتورة مشتريات'
      : invoice.type === 'مرتجع_مبيعات'
      ? 'إشعار مرتجع مبيعات'
      : 'إشعار مرتجع مشتريات';

  const statusLabel =
    invoice.status === 'posted'
      ? 'مرحلة / معتمدة'
      : invoice.status === 'paid'
      ? 'مدفوعة بالكامل'
      : invoice.status === 'partial'
      ? 'مدفوعة جزئياً'
      : invoice.status === 'cancelled'
      ? 'ملغاة / معكوسة'
      : 'مسودة';

  const partyLabel =
    invoice.type === 'مشتريات' || invoice.type === 'مرتجع_مشتريات' ? 'المورد' : 'العميل';

  const rows = invoice.items.map((item, idx) => [
    String(idx + 1),
    item.itemName,
    item.unit,
    String(item.quantity + (item.bonusQuantity ? ` (+${item.bonusQuantity})` : '')),
    `${pdfNum(item.unitPrice)}`,
    `${pdfNum(item.discountAmount)}`,
    `${pdfNum(item.taxAmount)}`,
    `${pdfNum(item.total)} ${invoice.currency}`,
  ]);

  const invCurr = invoice.currency || 'YER';
  const invRate =
    invoice.exchangeRate && invoice.exchangeRate > 1
      ? invoice.exchangeRate
      : invCurr === 'SAR'
      ? 142
      : invCurr === 'USD'
      ? 535
      : 1;
  const formatBalSnapshot = (baseVal?: number) => {
    if (baseVal === undefined) return '-';
    if (invCurr !== 'YER' && invRate > 1) {
      const nativeBal = Math.round((baseVal / invRate) * 100) / 100;
      return `${pdfNum(nativeBal)} ${invCurr} (${pdfNum(baseVal)} YER)`;
    }
    return `${pdfNum(baseVal)} YER`;
  };

  return buildReportPdfBytes({
    title: `${docLabel} #${invoice.invoiceNumber}`,
    subtitle: `${partyLabel}: ${invoice.entityName}`,
    reportCode: invoice.invoiceNumber,
    periodText: invoice.date,
    company,
    branch,
    preparedBy: invoice.createdBy || 'مسؤول المبيعات',
    notes: invoice.notes,
    metadata: {
      'رقم المستند': invoice.invoiceNumber,
      'التاريخ': invoice.date,
      [partyLabel]: invoice.entityName,
      'نوع الدفع': invoice.paymentType,
      'العملة وسعر الصرف': `${invCurr} (${invRate})`,
      'المستودع': warehouseName || invoice.warehouseId,
      'الحالة': statusLabel,
      'الرصيد السابق': formatBalSnapshot(invoice.previousBalanceSnapshot),
      'الرصيد بعد الفاتورة': formatBalSnapshot(invoice.newBalanceSnapshot),
    },
    tables: [
      {
        title: 'بنود الفاتورة التفصيلية',
        headers: ['#', 'اسم الصنف', 'الوحدة', 'الكمية', 'سعر الوحدة', 'الخصم', 'الضريبة', 'الإجمالي'],
        rows,
        alignments: ['center', 'right', 'center', 'center', 'center', 'center', 'center', 'center'],
        totals: [
          '',
          'الإجماليات',
          '',
          String(invoice.items.reduce((s, i) => s + i.quantity + (i.bonusQuantity || 0), 0)),
          '',
          pdfNum(invoice.discountTotal),
          pdfNum(invoice.taxTotal),
          `${pdfNum(invoice.grandTotal)} ${invoice.currency}`,
        ],
      },
      {
        title: 'ملخص السداد والاستحقاق',
        headers: ['المجموع الفرعي', 'الخصم', 'الضريبة', 'الصافي النهائي', 'المدفوع', 'المتبقي'],
        rows: [
          [
            `${pdfNum(invoice.subtotal)} ${invoice.currency}`,
            `${pdfNum(invoice.discountTotal)} ${invoice.currency}`,
            `${pdfNum(invoice.taxTotal)} ${invoice.currency}`,
            `${pdfNum(invoice.grandTotal)} ${invoice.currency}`,
            `${pdfNum(invoice.paidAmount)} ${invoice.currency}`,
            `${pdfNum(invoice.remainingAmount)} ${invoice.currency}`,
          ],
        ],
        alignments: ['center', 'center', 'center', 'center', 'center', 'center'],
      },
    ],
  });
}

/**
 * Generates a genuine binary PDF document for Receipt / Payment Vouchers.
 */
export async function buildVoucherPdfBytes(
  voucher: PaymentVoucher,
  company?: Company,
  branch?: Branch
): Promise<Uint8Array> {
  const title =
    voucher.type === 'قبض'
      ? `سند قبض مالي #${voucher.voucherNumber}`
      : `سند صرف مالي #${voucher.voucherNumber}`;
  return buildReportPdfBytes({
    title,
    subtitle: `${voucher.entityType}: ${voucher.entityName}`,
    reportCode: voucher.voucherNumber,
    periodText: voucher.date,
    company,
    branch,
    preparedBy: voucher.createdBy || 'أمين الصندوق',
    notes: voucher.statement,
    metadata: {
      'رقم السند': voucher.voucherNumber,
      'نوع السند': voucher.type === 'قبض' ? 'سند قبض' : 'سند صرف',
      'التاريخ': voucher.date,
      'الطرف / الحساب': `${voucher.entityType} - ${voucher.entityName}`,
      'الخزينة / البنك': voucher.treasuryAccountName,
      'طريقة الدفع': voucher.paymentMethod.replace(/_/g, ' '),
      'العملة وسعر الصرف': `${voucher.currency} (${voucher.exchangeRate})`,
      'الحالة': voucher.status === 'posted' ? 'مرحل ومعتمد' : 'ملغى',
      'المستلم / المحصل': voucher.receivedOrPaidBy || '-',
    },
    tables: [
      {
        title: 'بيانات القيمة المالية للسند',
        headers: ['رقم السند', 'البيان', 'المبلغ بالعملة', 'المعادل بالأساس (YER)', 'المرجع'],
        rows: [
          [
            voucher.voucherNumber,
            voucher.statement || '-',
            `${pdfNum(voucher.amount)} ${voucher.currency}`,
            `${pdfNum(voucher.baseAmount)} YER`,
            voucher.linkedInvoiceNumber || voucher.checkNumber || voucher.transferReference || '-',
          ],
        ],
        alignments: ['center', 'right', 'center', 'center', 'center'],
      },
    ],
  });
}
