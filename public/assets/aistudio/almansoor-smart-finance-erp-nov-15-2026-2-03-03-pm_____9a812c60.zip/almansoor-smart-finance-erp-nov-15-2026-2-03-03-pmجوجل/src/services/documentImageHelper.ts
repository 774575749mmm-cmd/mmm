/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * ALMANSOOR SMART FINANCE ERP - High-Resolution Paginated PNG Image & PDF Blob Renderer
 * Paginates long reports into crisp A4-ratio 2480px-wide (@2x) PNG pages with zero row truncation
 * and zero browser/WhatsApp tall-canvas resolution degradation.
 */

import { Branch, Company } from '../types/erp';
import { UniversalPreviewPayload } from '../components/common/UniversalPreviewModal';
import { ReportPDFOptions } from './exportService';
import {
  buildInvoicePdfBytes,
  buildReportPdfBytes,
  buildVoucherPdfBytes,
} from './arabicPdfHelper';

export interface PngPageAsset {
  pageNumber: number;
  totalPages: number;
  blob: Blob;
  dataUrl: string;
  fileName: string;
  widthPx: number;
  heightPx: number;
}

export interface RenderedPngResult {
  blob: Blob;
  dataUrl: string;
  fileName: string;
  pages: PngPageAsset[];
}

function wrapCanvasText(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number
): string[] {
  const str = String(text ?? '').trim();
  if (!str) return ['-'];
  const safeMax = Math.max(maxWidth, 32);
  if (ctx.measureText(str).width <= safeMax) return [str];

  const words = str.split(/\s+/);
  const lines: string[] = [];
  let line = '';

  const splitLongWord = (w: string) => {
    let chunk = '';
    for (const ch of Array.from(w)) {
      if (chunk && ctx.measureText(chunk + ch).width > safeMax) {
        lines.push(chunk);
        chunk = ch;
      } else {
        chunk += ch;
      }
    }
    return chunk;
  };

  for (const w of words) {
    const test = line ? `${line} ${w}` : w;
    if (ctx.measureText(test).width > safeMax) {
      if (line) lines.push(line);
      line = ctx.measureText(w).width > safeMax ? splitLongWord(w) : w;
    } else {
      line = test;
    }
  }
  if (line) lines.push(line);
  return lines.length > 0 ? lines : [str];
}

interface ComputedRowLayout {
  cells: string[][];
  height: number;
}

interface ComputedTableLayout {
  title?: string;
  headers: string[];
  colWidths: number[];
  rows: ComputedRowLayout[];
  totals?: string[];
}

/**
 * Renders any UniversalPreviewPayload into 1..N crisp A4-proportioned high-DPI PNG pages (2480px wide @2x).
 * Long reports never shrink or lose resolution because each page stays <= 1754px logical height (3508px @2x).
 */
export async function renderPayloadToPngPages(
  payload: UniversalPreviewPayload,
  company: Company,
  branch?: Branch
): Promise<PngPageAsset[]> {
  if (typeof document === 'undefined') {
    throw new Error('توليد الصور متاح في المتصفح فقط.');
  }

  try {
    if (document.fonts && document.fonts.ready) {
      await document.fonts.ready;
    }
  } catch {
    // ignore
  }

  const pageWidth = 1240;
  const maxPageHeight = 1754;
  const padX = 40;
  const innerW = pageWidth - padX * 2;
  const footerReserve = 52;
  const scale = 2; // 2480px wide physical canvas per page

  const measureCanvas = document.createElement('canvas');
  const mCtx = measureCanvas.getContext('2d')!;
  mCtx.direction = 'rtl';

  const metaEntries = payload.metadata ? Object.entries(payload.metadata) : [];
  const summaryCards = payload.summaryCards || [];

  // Measure all tables and wrap all cells accurately
  const computedTables: ComputedTableLayout[] = [];
  for (const tbl of payload.tables) {
    const colCount = Math.max(tbl.headers.length, 1);
    const bodyFontSize = colCount >= 10 ? 12 : colCount >= 8 ? 13 : 14;
    const lineStep = bodyFontSize + 6;
    mCtx.font = `600 ${bodyFontSize}px "Cairo", "Segoe UI", Tahoma, sans-serif`;

    const rawWeights = tbl.headers.map((h, cIdx) => {
      let maxW = mCtx.measureText(String(h)).width + 24;
      const sampleRows = tbl.rows.slice(0, 30);
      for (const r of sampleRows) {
        const w = mCtx.measureText(String(r[cIdx] ?? '')).width + 20;
        if (w > maxW) maxW = w;
      }
      return Math.min(Math.max(maxW, 68), 360);
    });
    const weightSum = rawWeights.reduce((s, w) => s + w, 0) || 1;
    const colWidths = rawWeights.map((w) => (w / weightSum) * innerW);

    const rowLayouts = tbl.rows.map((row) => {
      const cellLines = Array.from({ length: colCount }, (_, cIdx) =>
        wrapCanvasText(mCtx, String(row[cIdx] ?? '-'), Math.max(colWidths[cIdx] - 14, 34))
      );
      const maxLines = Math.max(...cellLines.map((l) => l.length), 1);
      const rowH = Math.max(32, maxLines * lineStep + 14);
      return { cells: cellLines, height: rowH };
    });

    computedTables.push({
      title: tbl.title,
      headers: tbl.headers,
      colWidths,
      rows: rowLayouts,
      totals: tbl.totals?.map((t) => String(t ?? '')),
    });
  }

  // Page builder helper: records drawing commands onto virtual pages so we know totalPages upfront
  type DrawOp = (ctx: CanvasRenderingContext2D) => void;
  interface VirtualPage {
    ops: DrawOp[];
    contentBottomY: number;
  }

  const pages: VirtualPage[] = [];
  let curPage: VirtualPage = { ops: [], contentBottomY: 32 };
  let curY = 32;

  const startFirstPageHeader = () => {
    curPage.ops.push((ctx) => {
      ctx.direction = 'rtl';
      ctx.textAlign = 'center';
      ctx.fillStyle = '#0B192C';
      ctx.font = '800 24px "Cairo", "Segoe UI", Tahoma, sans-serif';
      ctx.fillText(company.nameAr || 'المنصور للأنظمة المالية', pageWidth / 2, 58);

      ctx.fillStyle = '#475569';
      ctx.font = '600 14px "Cairo", "Segoe UI", Tahoma, sans-serif';
      const subParts = [
        branch?.nameAr,
        company.address,
        company.phone ? `هاتف: ${company.phone}` : '',
      ].filter(Boolean);
      ctx.fillText(subParts.join(' · '), pageWidth / 2, 82);

      // Title banner
      ctx.fillStyle = '#FEF3C7';
      ctx.fillRect(padX, 96, innerW, 38);
      ctx.strokeStyle = '#D97706';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(padX, 96, innerW, 38);

      ctx.fillStyle = '#78350F';
      ctx.font = '800 16px "Cairo", "Segoe UI", Tahoma, sans-serif';
      ctx.textAlign = 'right';
      ctx.fillText(payload.title, pageWidth - padX - 14, 121);
      if (payload.periodText) {
        ctx.textAlign = 'left';
        ctx.font = '700 13px "Cairo", "Segoe UI", Tahoma, sans-serif';
        ctx.fillText(payload.periodText, padX + 14, 121);
      }
    });
    curY = 148;

    if (metaEntries.length > 0) {
      const metaRows = Math.ceil(metaEntries.length / 2);
      const boxH = metaRows * 30 + 12;
      const boxY = curY;
      curPage.ops.push((ctx) => {
        ctx.fillStyle = '#F8FAFC';
        ctx.fillRect(padX, boxY, innerW, boxH);
        ctx.strokeStyle = '#CBD5E1';
        ctx.lineWidth = 1;
        ctx.strokeRect(padX, boxY, innerW, boxH);

        metaEntries.forEach(([k, v], idx) => {
          const r = Math.floor(idx / 2);
          const isRightCol = idx % 2 === 0;
          const cellX = isRightCol ? pageWidth - padX - 14 : pageWidth / 2 - 14;
          const cellY = boxY + 24 + r * 30;
          ctx.textAlign = 'right';
          ctx.fillStyle = '#475569';
          ctx.font = '700 13px "Cairo", "Segoe UI", Tahoma, sans-serif';
          const labelTxt = `${k.replace(/_/g, ' ')}: `;
          ctx.fillText(labelTxt, cellX, cellY);
          const labelW = ctx.measureText(labelTxt).width;
          ctx.fillStyle = '#0F172A';
          ctx.font = '800 13px "Cairo", "Segoe UI", Tahoma, sans-serif';
          ctx.fillText(String(v), cellX - labelW - 4, cellY, innerW / 2 - labelW - 26);
        });
      });
      curY += boxH + 16;
    }
  };

  const pushNewPage = (continuationTitle?: string) => {
    curPage.contentBottomY = curY;
    pages.push(curPage);
    curPage = { ops: [], contentBottomY: 32 };
    const pageNumDisplay = pages.length + 1;
    curPage.ops.push((ctx) => {
      ctx.fillStyle = '#0F172A';
      ctx.fillRect(padX, 28, innerW, 38);
      ctx.fillStyle = '#F5C748';
      ctx.font = '800 15px "Cairo", "Segoe UI", Tahoma, sans-serif';
      ctx.textAlign = 'right';
      ctx.fillText(
        `${company.nameAr || 'المنصور للأنظمة المالية'} — ${continuationTitle || payload.title}`,
        pageWidth - padX - 14,
        52
      );
      ctx.fillStyle = '#CBD5E1';
      ctx.font = '700 12px "Cairo", "Segoe UI", Tahoma, sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText(`متابعة التقرير · صفحة ${pageNumDisplay}`, padX + 14, 52);
    });
    curY = 80;
  };

  const ensureSpace = (neededH: number, onNewPage?: () => void) => {
    if (curY + neededH > maxPageHeight - footerReserve) {
      pushNewPage();
      onNewPage?.();
      return true;
    }
    return false;
  };

  startFirstPageHeader();

  for (const tbl of computedTables) {
    const colCount = Math.max(tbl.headers.length, 1);
    const bodyFontSize = colCount >= 10 ? 12 : colCount >= 8 ? 13 : 14;
    const headerFontSize = colCount >= 10 ? 12 : 13;
    const lineStep = bodyFontSize + 6;

    const drawTableHeader = () => {
      const hy = curY;
      curPage.ops.push((ctx) => {
        ctx.fillStyle = '#0F172A';
        ctx.fillRect(padX, hy, innerW, 38);
        let curX = pageWidth - padX;
        ctx.font = `800 ${headerFontSize}px "Cairo", "Segoe UI", Tahoma, sans-serif`;
        tbl.headers.forEach((h, cIdx) => {
          const cw = tbl.colWidths[cIdx];
          curX -= cw;
          ctx.strokeStyle = '#334155';
          ctx.lineWidth = 1;
          ctx.strokeRect(curX, hy, cw, 38);
          ctx.fillStyle = '#F5C748';
          ctx.textAlign = 'center';
          ctx.fillText(String(h), curX + cw / 2, hy + 24, cw - 8);
        });
      });
      curY += 38;
    };

    if (tbl.title) {
      ensureSpace(74);
      const ty = curY;
      curPage.ops.push((ctx) => {
        ctx.textAlign = 'right';
        ctx.fillStyle = '#0B192C';
        ctx.font = '800 16px "Cairo", "Segoe UI", Tahoma, sans-serif';
        ctx.fillText(tbl.title!, pageWidth - padX, ty + 22);
      });
      curY += 32;
    } else {
      ensureSpace(74);
    }

    drawTableHeader();

    if (tbl.rows.length === 0) {
      ensureSpace(38, drawTableHeader);
      const ry = curY;
      curPage.ops.push((ctx) => {
        ctx.fillStyle = '#F8FAFC';
        ctx.fillRect(padX, ry, innerW, 36);
        ctx.strokeStyle = '#CBD5E1';
        ctx.strokeRect(padX, ry, innerW, 36);
        ctx.fillStyle = '#64748B';
        ctx.textAlign = 'center';
        ctx.font = '700 14px "Cairo", "Segoe UI", Tahoma, sans-serif';
        ctx.fillText('لا توجد بيانات في هذه الفترة', pageWidth / 2, ry + 23);
      });
      curY += 36;
    } else {
      tbl.rows.forEach((row, rIdx) => {
        ensureSpace(row.height, drawTableHeader);
        const ry = curY;
        curPage.ops.push((ctx) => {
          ctx.fillStyle = rIdx % 2 === 0 ? '#FFFFFF' : '#F8FAFC';
          ctx.fillRect(padX, ry, innerW, row.height);

          let rx = pageWidth - padX;
          ctx.font = `600 ${bodyFontSize}px "Cairo", "Segoe UI", Tahoma, sans-serif`;
          row.cells.forEach((lines, cIdx) => {
            const cw = tbl.colWidths[cIdx];
            rx -= cw;
            ctx.strokeStyle = '#CBD5E1';
            ctx.lineWidth = 1;
            ctx.strokeRect(rx, ry, cw, row.height);
            ctx.fillStyle = '#0F172A';
            ctx.textAlign = 'center';
            lines.forEach((ln, lIdx) => {
              ctx.fillText(ln, rx + cw / 2, ry + 22 + lIdx * lineStep, cw - 10);
            });
          });
        });
        curY += row.height;
      });
    }

    if (tbl.totals && tbl.totals.length > 0) {
      ensureSpace(38, drawTableHeader);
      const ty = curY;
      curPage.ops.push((ctx) => {
        ctx.fillStyle = '#FEF3C7';
        ctx.fillRect(padX, ty, innerW, 38);
        let tx = pageWidth - padX;
        ctx.font = `800 ${bodyFontSize}px "Cairo", "Segoe UI", Tahoma, sans-serif`;
        tbl.totals!.forEach((tot, cIdx) => {
          const cw = tbl.colWidths[cIdx] || 80;
          tx -= cw;
          ctx.strokeStyle = '#D97706';
          ctx.strokeRect(tx, ty, cw, 38);
          ctx.fillStyle = '#78350F';
          ctx.textAlign = 'center';
          ctx.fillText(tot, tx + cw / 2, ty + 24, cw - 8);
        });
      });
      curY += 38;
    }

    curY += 18;
  }

  // Summary cards (supports primary value + optional secondary subValue without BiDi swapping)
  if (summaryCards.length > 0) {
    const gap = 12;
    const cols = 3;
    const cardW = (innerW - gap * (cols - 1)) / cols;
    const hasAnySub = summaryCards.some((c) => Boolean(c.subValue) || (c.value || '').includes(' | '));
    const cardH = hasAnySub ? 76 : 58;
    const rowStepY = cardH + 10;
    const cardRows = Math.ceil(summaryCards.length / cols);
    const cardsTotalH = cardRows * rowStepY + 10;
    ensureSpace(cardsTotalH);
    const baseCardsY = curY;
    const isolateLtr = (txt: string) =>
      txt.replace(/[A-Za-z0-9#+-][A-Za-z0-9.,:/%\-_+#()]*/g, '\u200E$&\u200E');
    curPage.ops.push((ctx) => {
      summaryCards.forEach((card, idx) => {
        const r = Math.floor(idx / cols);
        const c = idx % cols;
        const cx = pageWidth - padX - (c + 1) * cardW - c * gap;
        const cy = baseCardsY + r * rowStepY;
        ctx.fillStyle = '#F8FAFC';
        ctx.fillRect(cx, cy, cardW, cardH);
        ctx.strokeStyle = '#94A3B8';
        ctx.lineWidth = 1;
        ctx.strokeRect(cx, cy, cardW, cardH);
        ctx.textAlign = 'right';
        ctx.fillStyle = '#475569';
        ctx.font = '700 12px "Cairo", "Segoe UI", Tahoma, sans-serif';
        ctx.fillText(card.label, cx + cardW - 12, cy + 20, cardW - 24);

        const parts =
          !card.subValue && (card.value || '').includes(' | ')
            ? card.value.split(' | ').map((x) => x.trim()).filter(Boolean)
            : [card.value, ...(card.subValue ? [card.subValue] : [])];

        ctx.fillStyle = '#0F172A';
        ctx.font = '900 14px "Cairo", "Segoe UI", Tahoma, sans-serif';
        ctx.fillText(isolateLtr(parts[0] || ''), cx + cardW - 12, cy + 43, cardW - 24);
        if (parts[1]) {
          ctx.fillStyle = '#334155';
          ctx.font = '700 12px "Cairo", "Segoe UI", Tahoma, sans-serif';
          ctx.fillText(isolateLtr(parts[1]), cx + cardW - 12, cy + 64, cardW - 24);
        }
      });
    });
    curY += cardsTotalH;
  }

  if (payload.notes) {
    ensureSpace(46);
    const ny = curY;
    curPage.ops.push((ctx) => {
      ctx.fillStyle = '#F0FDF4';
      ctx.fillRect(padX, ny, innerW, 38);
      ctx.strokeStyle = '#86EFAC';
      ctx.strokeRect(padX, ny, innerW, 38);
      ctx.textAlign = 'right';
      ctx.fillStyle = '#166534';
      ctx.font = '700 13px "Cairo", "Segoe UI", Tahoma, sans-serif';
      ctx.fillText(`ملاحظات: ${payload.notes}`, pageWidth - padX - 12, ny + 24, innerW - 24);
    });
    curY += 46;
  }

  curPage.contentBottomY = curY;
  pages.push(curPage);

  const totalPages = pages.length;
  const safeBaseTitle = payload.title.replace(/[^\u0600-\u06FFa-zA-Z0-9_-]+/g, '_').slice(0, 44) || 'document';
  const assets: PngPageAsset[] = [];

  for (let pIdx = 0; pIdx < totalPages; pIdx++) {
    const vp = pages[pIdx];
    // For single short pages, fit tightly to content; for multi-page reports, maintain crisp uniform A4 height
    const logicalH =
      totalPages === 1
        ? Math.max(520, Math.min(maxPageHeight, vp.contentBottomY + footerReserve + 16))
        : maxPageHeight;

    const canvas = document.createElement('canvas');
    canvas.width = pageWidth * scale;
    canvas.height = logicalH * scale;
    const ctx = canvas.getContext('2d')!;
    ctx.scale(scale, scale);

    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, pageWidth, logicalH);

    ctx.strokeStyle = '#0F172A';
    ctx.lineWidth = 2;
    ctx.strokeRect(14, 14, pageWidth - 28, logicalH - 28);

    for (const op of vp.ops) {
      op(ctx);
    }

    // Crisp page footer
    ctx.direction = 'rtl';
    ctx.fillStyle = '#64748B';
    ctx.font = '700 12px "Cairo", "Segoe UI", Tahoma, sans-serif';
    ctx.textAlign = 'right';
    ctx.fillText(
      `${company.invoiceFooterNote || 'شكراً لتعاملكم معنا - نظام المنصور للإدارة المالية الذكية'} · ${new Date().toLocaleDateString('ar-YE')}`,
      pageWidth - padX,
      logicalH - 24
    );
    ctx.textAlign = 'left';
    ctx.fillText(`صفحة ${pIdx + 1} من ${totalPages}`, padX, logicalH - 24);

    const dataUrl = canvas.toDataURL('image/png');
    const blob = await new Promise<Blob>((resolve, reject) => {
      canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('تعذر تحويل الصورة.'))), 'image/png', 1.0);
    });

    const fileName =
      totalPages === 1
        ? `${safeBaseTitle}.png`
        : `${safeBaseTitle}_صفحة_${pIdx + 1}_من_${totalPages}.png`;

    assets.push({
      pageNumber: pIdx + 1,
      totalPages,
      blob,
      dataUrl,
      fileName,
      widthPx: canvas.width,
      heightPx: canvas.height,
    });
  }

  return assets;
}

/**
 * Downloads all crisp PNG pages sequentially so long reports preserve full 2480px print-grade clarity.
 */
export function downloadPngPages(pages: PngPageAsset[]): void {
  pages.forEach((p, idx) => {
    setTimeout(() => {
      const a = document.createElement('a');
      a.href = p.dataUrl;
      a.download = p.fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }, idx * 240);
  });
}

/**
 * Renders any UniversalPreviewPayload onto crisp 2480px-wide paginated PNG(s) (returns page 1 + full pages list).
 */
export async function renderPayloadToPng(
  payload: UniversalPreviewPayload,
  company: Company,
  branch?: Branch
): Promise<RenderedPngResult> {
  const pages = await renderPayloadToPngPages(payload, company, branch);
  const first = pages[0];
  return {
    blob: first.blob,
    dataUrl: first.dataUrl,
    fileName: first.fileName,
    pages,
  };
}

/**
 * Generates an in-memory PDF Blob for any UniversalPreviewPayload (for WhatsApp Web Share / Download).
 */
export async function buildPayloadPdfBlob(
  payload: UniversalPreviewPayload,
  company: Company,
  branch?: Branch
): Promise<{ blob: Blob; fileName: string }> {
  let bytes: Uint8Array;
  let fileName: string;

  if (payload.invoiceObj) {
    bytes = await buildInvoicePdfBytes(payload.invoiceObj, company, branch, payload.warehouseName);
    fileName = `فاتورة_${payload.invoiceObj.invoiceNumber}.pdf`;
  } else if (payload.voucherObj) {
    bytes = await buildVoucherPdfBytes(payload.voucherObj, company, branch);
    const pfx = payload.voucherObj.type === 'قبض' ? 'سند_قبض' : 'سند_صرف';
    fileName = `${pfx}_${payload.voucherObj.voucherNumber}.pdf`;
  } else {
    const opts: ReportPDFOptions = {
      title: payload.title,
      subtitle: payload.subtitle,
      reportCode: payload.reportCode,
      periodText: payload.periodText,
      metadata: payload.metadata,
      tables: payload.tables,
      summaryCards: payload.summaryCards,
      company,
      branch,
      notes: payload.notes,
    };
    bytes = await buildReportPdfBytes(opts);
    const safeTitle = payload.title.replace(/[^\u0600-\u06FFa-zA-Z0-9_-]+/g, '_').slice(0, 48);
    fileName = `${safeTitle || 'report'}.pdf`;
  }

  const copy = new Uint8Array(bytes.byteLength);
  copy.set(bytes);
  return {
    blob: new Blob([copy.buffer], { type: 'application/pdf' }),
    fileName,
  };
}
