/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * ALMANSOOR SMART FINANCE ERP - Central Unified Export Service
 * Genuine binary PDF (Cairo TTF + Arabic Reshaper + BiDi), Excel (.xlsx), CSV (UTF-8 BOM), Print & WhatsApp
 */

import * as XLSX from 'xlsx';
import { Company, Branch, Invoice, PaymentVoucher } from '../types/erp';
import {
  buildReportPdfBytes,
  buildInvoicePdfBytes,
  buildVoucherPdfBytes,
} from './arabicPdfHelper';

export interface SummaryCardDef {
  label: string;
  value: string;
  subValue?: string;
  tone?: 'gold' | 'green' | 'red' | 'blue';
}

export interface ExportTableDef {
  title?: string;
  headers: string[];
  rows: (string | number)[][];
  totals?: (string | number)[];
  alignments?: ('right' | 'center' | 'left')[];
}

export interface ReportPDFOptions {
  title: string;
  subtitle?: string;
  reportCode?: string;
  periodText?: string;
  metadata?: Record<string, string>;
  tables: ExportTableDef[];
  summaryCards?: SummaryCardDef[];
  company?: Company;
  branch?: Branch;
  preparedBy?: string;
  notes?: string;
  fileName?: string;
  lang?: 'ar' | 'en';
}

function escapeHtml(value: unknown): string {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * Clean & format Arabic numbers or financial figures
 */
export function formatCurrencyValue(val: number, currency: string = 'YER'): string {
  return `${Number(val || 0).toLocaleString('ar-YE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${currency}`;
}

function triggerBinaryDownload(bytes: Uint8Array, mimeType: string, fileName: string): void {
  const copy = new Uint8Array(bytes.byteLength);
  copy.set(bytes);
  const blob = new Blob([copy.buffer], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/**
 * Verifies PDF binary signature (%PDF- ... %%EOF)
 */
export function verifyPdfSignature(bytes: Uint8Array): boolean {
  if (!bytes || bytes.length < 100) return false;
  const header = String.fromCharCode(bytes[0], bytes[1], bytes[2], bytes[3], bytes[4]);
  const tailSlice = bytes.slice(Math.max(0, bytes.length - 64));
  const tail = String.fromCharCode(...tailSlice);
  return header === '%PDF-' && tail.includes('%%EOF');
}

/**
 * Export structured data to a genuine Excel workbook (.xlsx)
 */
export function exportToExcel(options: {
  fileName: string;
  sheets: {
    name: string;
    data: (string | number)[][];
    columnWidths?: number[];
  }[];
}): void {
  const wb = XLSX.utils.book_new();

  options.sheets.forEach((sheetDef) => {
    const ws = XLSX.utils.aoa_to_sheet(sheetDef.data);

    if (sheetDef.columnWidths && sheetDef.columnWidths.length > 0) {
      ws['!cols'] = sheetDef.columnWidths.map((w) => ({ wch: w }));
    } else {
      const maxCols = Math.max(...sheetDef.data.map((row) => row.length), 1);
      ws['!cols'] = Array(maxCols).fill({ wch: 18 });
    }

    if (!ws['!views']) ws['!views'] = [];
    ws['!views'].push({ rightToLeft: true });

    const safeSheetName = (sheetDef.name || 'Sheet1').replace(/[*?:/\\[\]]/g, '').slice(0, 31);
    XLSX.utils.book_append_sheet(wb, ws, safeSheetName);
  });

  const fileBase = options.fileName.endsWith('.xlsx') ? options.fileName : `${options.fileName}.xlsx`;
  XLSX.writeFile(wb, fileBase);
}

/**
 * Export data to UTF-8 CSV with BOM & formula-injection protection for seamless opening in Excel
 */
export function exportToCSV(fileName: string, headers: string[], rows: (string | number)[][]): void {
  const sanitize = (cell: string | number | undefined | null) => {
    if (cell === undefined || cell === null) return '""';
    if (typeof cell === 'number') {
      return `"${Number.isFinite(cell) ? cell : 0}"`;
    }
    let raw = String(cell);
    const trimmed = raw.trimStart();
    if (
      /^[=+\-@\t\r]/.test(trimmed) &&
      !/^-\d+(\.\d+)?$/.test(trimmed)
    ) {
      raw = `'${raw}`;
    }
    const str = raw.replace(/"/g, '""');
    return `"${str}"`;
  };

  const headerLine = headers.map(sanitize).join(',');
  const rowLines = rows.map((row) => row.map(sanitize).join(','));
  const csvContent = '\uFEFF' + [headerLine, ...rowLines].join('\r\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  const safeName = fileName.endsWith('.csv') ? fileName : `${fileName}.csv`;
  link.setAttribute('download', safeName);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/**
 * Generate a standalone, XSS-safe print-ready HTML document for browser print preview
 */
export function generatePrintableHTML(options: ReportPDFOptions): string {
  const lang = options.lang === 'en' ? 'en' : 'ar';
  const dir = lang === 'en' ? 'ltr' : 'rtl';
  const isEn = lang === 'en';
  const compName = escapeHtml(options.company?.nameAr || 'المنصور للأنظمة المالية والإدارية الذكية');
  const branchName = escapeHtml(options.branch?.nameAr || (isEn ? 'Main Branch' : 'الفرع الرئيسي'));
  const cr = options.company?.commercialRecord
    ? `${isEn ? 'CR' : 'س.ت'}: ${escapeHtml(options.company.commercialRecord)}`
    : '';
  const tax = options.company?.taxNumber
    ? `${isEn ? 'Tax ID' : 'ر.ض'}: ${escapeHtml(options.company.taxNumber)}`
    : '';
  const phone = options.company?.phone
    ? `${isEn ? 'Tel' : 'هاتف'}: ${escapeHtml(options.company.phone)}`
    : '';
  const now = new Date();
  const locale = isEn ? 'en-US' : 'ar-YE';
  const printDate = escapeHtml(now.toLocaleDateString(locale, { year: 'numeric', month: 'long', day: 'numeric' }));
  const printTime = escapeHtml(now.toLocaleTimeString(locale, { hour: '2-digit', minute: '2-digit' }));

  const metadataHtml = options.metadata
    ? `<div class="metadata-grid">
        ${Object.entries(options.metadata)
          .map(
            ([key, val]) =>
              `<div class="meta-item"><span class="meta-label">${escapeHtml(key)}:</span> <span class="meta-val">${escapeHtml(val)}</span></div>`
          )
          .join('')}
       </div>`
    : '';

  const formatHtmlCell = (raw: string | number | undefined | null): string => {
    if (raw === undefined || raw === null || raw === '') return '-';
    const s = String(raw);
    if (s.includes(' | ')) {
      return s
        .split(' | ')
        .map((p) => p.trim())
        .filter(Boolean)
        .map((p) => `<div style="line-height:1.35;"><bdi dir="auto">${escapeHtml(p)}</bdi></div>`)
        .join('');
    }
    return `<bdi dir="auto">${escapeHtml(s)}</bdi>`;
  };

  const tablesHtml = options.tables
    .map((table) => {
      const tableTitle = table.title ? `<h3 class="table-title">${escapeHtml(table.title)}</h3>` : '';
      const headerRow = `<tr>${table.headers.map((h) => `<th>${escapeHtml(h)}</th>`).join('')}</tr>`;
      const bodyRows = table.rows
        .map(
          (row) =>
            `<tr>${row
              .map((cell, idx) => {
                const defaultAlign = isEn ? (typeof cell === 'number' ? 'right' : 'left') : (typeof cell === 'number' ? 'left' : 'right');
                const align = table.alignments?.[idx] || defaultAlign;
                return `<td style="text-align:${align};">${formatHtmlCell(cell)}</td>`;
              })
              .join('')}</tr>`
        )
        .join('');

      const totalsRow =
        table.totals && table.totals.length > 0
          ? `<tr class="totals-row">${table.totals
              .map((tot, idx) => {
                const align = table.alignments?.[idx] || (isEn ? 'right' : 'left');
                return `<td style="text-align:${align};font-weight:bold;">${formatHtmlCell(tot)}</td>`;
              })
              .join('')}</tr>`
          : '';

      return `
        <div class="table-container">
          ${tableTitle}
          <table class="report-table">
            <thead>${headerRow}</thead>
            <tbody>${bodyRows}</tbody>
            ${totalsRow ? `<tfoot>${totalsRow}</tfoot>` : ''}
          </table>
        </div>
      `;
    })
    .join('');

  const summaryCardsHtml =
    options.summaryCards && options.summaryCards.length > 0
      ? `<div class="summary-cards-grid">
          ${options.summaryCards
            .map((card) => {
              const legacyParts =
                !card.subValue && card.value.includes(' | ')
                  ? card.value.split(' | ').map((x) => x.trim()).filter(Boolean)
                  : null;
              const body =
                legacyParts && legacyParts.length > 1
                  ? legacyParts
                      .map((p, i) => `<div class="${i === 0 ? 'sc-val' : 'sc-sub'}"><bdi dir="auto">${escapeHtml(p)}</bdi></div>`)
                      .join('')
                  : `<div class="sc-val"><bdi dir="auto">${escapeHtml(card.value)}</bdi></div>${
                      card.subValue ? `<div class="sc-sub"><bdi dir="auto">${escapeHtml(card.subValue)}</bdi></div>` : ''
                    }`;
              return `<div class="summary-card-box"><div class="sc-label">${escapeHtml(card.label)}</div>${body}</div>`;
            })
            .join('')}
        </div>`
      : '';

  const borderSide = isEn ? 'left' : 'right';
  const badgeAlign = isEn ? 'right' : 'left';
  const thAlign = isEn ? 'left' : 'right';
  const preparedBySafe = escapeHtml(options.preparedBy || (isEn ? 'Financial Accountant' : 'المحاسب المالي'));

  return `
<!DOCTYPE html>
<html lang="${lang}" dir="${dir}">
<head>
  <meta charset="UTF-8">
  <title>${escapeHtml(options.title)}</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap');
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif; direction: ${dir}; background: #f8fafc; color: #0f172a; line-height: 1.5; padding: 24px; font-size: 13px; }
    .report-card { max-width: 1050px; margin: 0 auto; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 32px; }
    .header-section { display: flex; justify-content: space-between; align-items: center; border-bottom: 3px solid #d97706; padding-bottom: 18px; margin-bottom: 22px; }
    .company-info h1 { font-size: 20px; font-weight: 800; color: #0f172a; margin-bottom: 4px; }
    .company-info .sub { font-size: 12px; color: #475569; }
    .report-badge { text-align: ${badgeAlign}; }
    .report-badge h2 { font-size: 18px; font-weight: 800; color: #b45309; }
    .report-badge .code { font-size: 11px; color: #64748b; font-family: monospace; margin-top: 2px; }
    .metadata-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 12px 16px; margin-bottom: 20px; }
    .meta-item { display: flex; gap: 6px; font-size: 12px; }
    .meta-label { color: #64748b; font-weight: 600; }
    .meta-val { color: #0f172a; font-weight: 700; }
    .table-container { margin-bottom: 24px; }
    .table-title { font-size: 15px; font-weight: 700; color: #1e293b; margin-bottom: 10px; padding-${borderSide}: 8px; border-${borderSide}: 4px solid #d97706; }
    .report-table { width: 100%; border-collapse: collapse; font-size: 12px; margin-bottom: 12px; }
    .report-table th { background: #0f172a; color: #fbbf24; font-weight: 700; text-align: ${thAlign}; padding: 9px 11px; border: 1px solid #334155; }
    .report-table td { padding: 7px 11px; border: 1px solid #e2e8f0; color: #334155; }
    .report-table tbody tr:nth-child(even) { background: #f8fafc; }
    .totals-row td { background: #fef3c7; font-weight: 800; color: #78350f; border-top: 2px solid #d97706; border-bottom: 2px solid #d97706; font-size: 13px; }
    .summary-cards-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 10px; margin-top: 14px; padding-top: 14px; border-top: 2px solid #0f172a; }
    .summary-card-box { border: 1px solid #cbd5e1; border-radius: 6px; background: #f8fafc; padding: 10px 12px; }
    .sc-label { font-size: 11px; color: #475569; font-weight: 700; margin-bottom: 4px; }
    .sc-val { font-size: 13px; color: #0f172a; font-weight: 900; }
    .sc-sub { font-size: 11px; color: #334155; font-weight: 700; margin-top: 2px; border-top: 1px dashed #cbd5e1; padding-top: 2px; }
    .signatures-section { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-top: 32px; padding-top: 20px; border-top: 1px dashed #cbd5e1; text-align: center; }
    .sig-box { border: 1px solid #e2e8f0; border-radius: 6px; padding: 14px 10px; background: #fcfcfd; }
    .sig-role { font-size: 12px; font-weight: 700; color: #475569; margin-bottom: 30px; }
    .sig-line { border-top: 1px solid #94a3b8; width: 70%; margin: 0 auto; padding-top: 6px; font-size: 11px; color: #64748b; }
    .footer-bar { margin-top: 24px; display: flex; justify-content: space-between; align-items: center; font-size: 11px; color: #64748b; border-top: 1px solid #e2e8f0; padding-top: 12px; }
    @media print {
      body { background: white !important; padding: 0 !important; }
      .report-card { border: none !important; box-shadow: none !important; padding: 8px !important; max-width: 100% !important; }
      @page { size: A4; margin: 12mm; }
    }
  </style>
</head>
<body>
  <div class="report-card">
    <div class="header-section">
      <div class="company-info">
        <h1>${compName}</h1>
        <div class="sub">${branchName} ${cr ? '&bull; ' + cr : ''} ${tax ? '&bull; ' + tax : ''}</div>
        <div class="sub">${phone}</div>
      </div>
      <div class="report-badge">
        <h2>${escapeHtml(options.title)}</h2>
        ${options.subtitle ? `<div style="font-size:13px; color:#475569;">${escapeHtml(options.subtitle)}</div>` : ''}
        ${options.periodText ? `<div style="font-size:12px; color:#b45309; font-weight:600;">${isEn ? 'Period' : 'الفترة'}: ${escapeHtml(options.periodText)}</div>` : ''}
        ${options.reportCode ? `<div class="code">${escapeHtml(options.reportCode)}</div>` : ''}
      </div>
    </div>
    ${metadataHtml}
    ${tablesHtml}
    ${summaryCardsHtml}
    ${options.notes ? `<div style="margin-top:16px; padding:12px; background:#f0fdf4; border:1px solid #bbf7d0; border-radius:6px; font-size:12px; color:#166534;"><strong>${isEn ? 'Notes' : 'ملاحظات'}:</strong> ${escapeHtml(options.notes)}</div>` : ''}
    <div class="signatures-section">
      <div class="sig-box"><div class="sig-role">${isEn ? 'Prepared By' : 'إعداد / المحاسب'}</div><div class="sig-line">${preparedBySafe}</div></div>
      <div class="sig-box"><div class="sig-role">${isEn ? 'Reviewed & Audited' : 'مراجعة وتدقيق'}</div><div class="sig-line">${isEn ? 'Chief Accountant' : 'رئيس الحسابات'}</div></div>
      <div class="sig-box"><div class="sig-role">${isEn ? 'Executive Approval' : 'اعتماد الإدارة العامة'}</div><div class="sig-line">${isEn ? 'General Manager' : 'المدير العام / المفوض'}</div></div>
    </div>
    <div class="footer-bar">
      <div>ALMANSOOR SMART FINANCE ERP &bull; ${preparedBySafe}</div>
      <div>${printDate} ${printTime}</div>
    </div>
  </div>
</body>
</html>
  `;
}

/**
 * Open report in an isolated iframe print preview (iframe-safe, never calls window.open/popups).
 */
export function printReportPreview(options: ReportPDFOptions): void {
  const html = generatePrintableHTML(options);
  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  document.body.appendChild(iframe);
  const doc = iframe.contentWindow?.document;
  if (doc) {
    doc.open();
    doc.write(html);
    doc.close();
    setTimeout(() => {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
      setTimeout(() => {
        if (document.body.contains(iframe)) {
          document.body.removeChild(iframe);
        }
      }, 2500);
    }, 350);
  }
}

/**
 * Generates and downloads a REAL binary .pdf report embedded with Cairo TrueType font.
 */
export async function downloadReportAsPDF(options: ReportPDFOptions): Promise<Uint8Array> {
  const baseName = (options.fileName || `${options.title.replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}`).replace(/\.(pdf|html)$/i, '');
  const bytes = await buildReportPdfBytes(options);
  if (typeof document !== 'undefined') {
    triggerBinaryDownload(bytes, 'application/pdf', `${baseName}.pdf`);
  }
  return bytes;
}

/**
 * Generates and downloads a REAL binary .pdf invoice.
 */
export async function downloadInvoicePDF(
  invoice: Invoice,
  company?: Company,
  branch?: Branch,
  warehouseName?: string
): Promise<Uint8Array> {
  const bytes = await buildInvoicePdfBytes(invoice, company, branch, warehouseName);
  if (typeof document !== 'undefined') {
    triggerBinaryDownload(bytes, 'application/pdf', `فاتورة_${invoice.invoiceNumber}.pdf`);
  }
  return bytes;
}

/**
 * Generates and downloads a REAL binary .pdf voucher.
 */
export async function downloadVoucherPDF(
  voucher: PaymentVoucher,
  company?: Company,
  branch?: Branch
): Promise<Uint8Array> {
  const bytes = await buildVoucherPdfBytes(voucher, company, branch);
  if (typeof document !== 'undefined') {
    const prefix = voucher.type === 'قبض' ? 'سند_قبض' : 'سند_صرف';
    triggerBinaryDownload(bytes, 'application/pdf', `${prefix}_${voucher.voucherNumber}.pdf`);
  }
  return bytes;
}

/**
 * Triggers instant auto-download of the genuine binary invoice .pdf upon posting
 */
export function triggerAutoDownloadInvoice(
  invoice: Invoice,
  company?: Company,
  branch?: Branch,
  warehouseName?: string
): void {
  void downloadInvoicePDF(invoice, company, branch, warehouseName).catch((err) => {
    console.error('Auto PDF download failed:', err);
  });
}

/**
 * Validates & normalizes a WhatsApp phone number to digits-only international format (defaulting local Yemen 7xxxxxxxx numbers to 967).
 */
export function validateWhatsAppPhone(phone: string): { valid: boolean; normalized: string; error?: string } {
  let digits = (phone || '').replace(/[^0-9]/g, '');
  if (digits.startsWith('00')) {
    digits = digits.slice(2);
  }
  if (/^7[0-9]{8}$/.test(digits)) {
    digits = `967${digits}`;
  } else if (/^07[0-9]{8}$/.test(digits)) {
    digits = `967${digits.slice(1)}`;
  }
  if (digits.length < 9 || digits.length > 15) {
    return {
      valid: false,
      normalized: digits,
      error: 'رقم الهاتف غير صالح. يرجى إدخال رقم دولي صحيح (مثل 967770001111).',
    };
  }
  return { valid: true, normalized: digits };
}

/**
 * Replaces template variables cleanly in Arabic WhatsApp messages.
 */
export function renderWhatsAppTemplate(template: string, vars: Record<string, string | number | undefined>): string {
  let result = template || '';
  for (const [key, value] of Object.entries(vars)) {
    const safeVal = value === undefined || value === null ? '' : String(value);
    result = result.replace(new RegExp(`\\{${key}\\}`, 'g'), safeVal);
  }
  return result;
}

/**
 * Generate WhatsApp Web link with formatted message & normalized phone.
 */
export function buildWhatsAppLink(phone: string, text: string): string {
  const { normalized } = validateWhatsAppPhone(phone);
  return `https://wa.me/${normalized}?text=${encodeURIComponent(text)}`;
}
