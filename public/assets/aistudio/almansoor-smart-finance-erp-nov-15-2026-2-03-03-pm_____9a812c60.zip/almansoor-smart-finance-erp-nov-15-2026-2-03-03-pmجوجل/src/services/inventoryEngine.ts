/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * ALMANSOOR SMART FINANCE ERP - Inventory & Warehouse Engine
 */

import {
  ItemWarehouseStock,
  StockMovement,
  InventoryTransfer,
  PhysicalStocktaking,
} from '../types/erp';

export interface WarehouseItemStockSummary {
  warehouseId: string;
  warehouseName: string;
  quantityOnHand: number;
  averageCost: number;
  totalValuation: number;
}

/**
 * Returns quantity on hand for an item in a specific warehouse
 */
export function getItemStockInWarehouse(
  stocks: ItemWarehouseStock[],
  itemId: string,
  warehouseId: string
): number {
  const stock = stocks.find((s) => s.itemId === itemId && s.warehouseId === warehouseId);
  return stock ? stock.quantityOnHand : 0;
}

/**
 * Checks whether an item quantity can be fulfilled based on warehouse stock and settings
 */
export function canFulfillStock(
  stocks: ItemWarehouseStock[],
  itemId: string,
  warehouseId: string,
  requiredQty: number,
  allowNegativeStock: boolean
): { canFulfill: boolean; currentQty: number; message?: string } {
  const currentQty = getItemStockInWarehouse(stocks, itemId, warehouseId);
  if (allowNegativeStock) {
    return { canFulfill: true, currentQty };
  }
  if (currentQty >= requiredQty) {
    return { canFulfill: true, currentQty };
  }
  return {
    canFulfill: false,
    currentQty,
    message: `الكمية المطلوبة (${requiredQty}) غير متوفرة في المستودع المختار! الرصيد المتاح حالياً هو (${currentQty}). سياسة النظام تمنع البيع بالسالب.`,
  };
}

/**
 * Updates stock levels in warehouse
 */
export function updateWarehouseStock(
  stocks: ItemWarehouseStock[],
  itemId: string,
  warehouseId: string,
  quantityDelta: number,
  unitCost: number
): ItemWarehouseStock[] {
  const safeDelta = Number.isFinite(quantityDelta) ? quantityDelta : 0;
  const safeUnitCost = Number.isFinite(unitCost) && unitCost >= 0 ? unitCost : 0;
  const index = stocks.findIndex((s) => s.itemId === itemId && s.warehouseId === warehouseId);
  if (index >= 0) {
    const existing = stocks[index];
    const currentQty = Number.isFinite(existing.quantityOnHand) ? existing.quantityOnHand : 0;
    const currentAvgCost = Number.isFinite(existing.averageCost) && existing.averageCost >= 0 ? existing.averageCost : 0;
    const newQty = currentQty + safeDelta;

    let newCost = currentAvgCost;
    if (safeDelta > 0 && safeUnitCost > 0) {
      if (currentQty <= 0 || newQty <= 0) {
        // Recovering from zero or negative stock: reset average cost cleanly to incoming unit cost
        newCost = Math.round(safeUnitCost * 100) / 100;
      } else {
        const currentValuation = currentQty * currentAvgCost;
        const addedValuation = safeDelta * safeUnitCost;
        newCost = Math.round(((currentValuation + addedValuation) / newQty) * 100) / 100;
      }
    }

    const updated = [...stocks];
    updated[index] = {
      ...existing,
      quantityOnHand: newQty,
      averageCost: newCost,
    };
    return updated;
  }
  return [
    ...stocks,
    {
      itemId,
      warehouseId,
      quantityOnHand: safeDelta,
      averageCost: safeUnitCost,
    },
  ];
}

/**
 * Executes a warehouse-to-warehouse stock transfer with strict conservation of quantity and idempotency guards.
 */
export function executeInventoryTransfer(
  stocks: ItemWarehouseStock[],
  transfer: InventoryTransfer,
  userFullName: string
): { success: boolean; newStocks: ItemWarehouseStock[]; movements: StockMovement[]; error?: string } {
  if (transfer.status === 'completed' || transfer.status === 'cancelled') {
    return {
      success: false,
      newStocks: stocks,
      movements: [],
      error: 'هذا التحويل منفذ أو ملغى مسبقاً ولا يمكن إعادة تنفيذه.',
    };
  }

  if (transfer.fromWarehouseId === transfer.toWarehouseId) {
    return {
      success: false,
      newStocks: stocks,
      movements: [],
      error: 'لا يمكن التحويل لنفس المستودع المصدر!',
    };
  }

  if (!transfer.items || transfer.items.length === 0) {
    return {
      success: false,
      newStocks: stocks,
      movements: [],
      error: 'يجب تحديد صنف واحد على الأقل للتحويل المخزني.',
    };
  }

  // 1. Check validity & availability
  for (const item of transfer.items) {
    if (!Number.isFinite(item.quantity) || item.quantity <= 0) {
      return {
        success: false,
        newStocks: stocks,
        movements: [],
        error: `كمية الصنف "${item.itemName}" غير صالحة للتحويل (${item.quantity}).`,
      };
    }
    const available = getItemStockInWarehouse(stocks, item.itemId, transfer.fromWarehouseId);
    if (available < item.quantity) {
      return {
        success: false,
        newStocks: stocks,
        movements: [],
        error: `الرصيد المتاح من الصنف "${item.itemName}" في مستودع المصدر (${available}) أقل من كمية التحويل المطلوبة (${item.quantity}).`,
      };
    }
  }

  // 2. Perform transfer
  let currentStocks = [...stocks];
  const movements: StockMovement[] = [];
  const ts = Date.now();

  transfer.items.forEach((item, idx) => {
    currentStocks = updateWarehouseStock(
      currentStocks,
      item.itemId,
      transfer.fromWarehouseId,
      -item.quantity,
      item.unitCost
    );
    movements.push({
      id: `sm-tr-out-${ts}-${idx}-${item.itemId}`,
      itemId: item.itemId,
      warehouseId: transfer.fromWarehouseId,
      documentType: 'تحويل_مخزني_صرف',
      documentNumber: transfer.transferNumber,
      documentId: transfer.id,
      movementDate: transfer.date,
      quantityChange: -item.quantity,
      unitCost: item.unitCost,
      totalCost: item.quantity * item.unitCost,
      runningBalance: getItemStockInWarehouse(currentStocks, item.itemId, transfer.fromWarehouseId),
      notes: `تحويل صادر إلى مستودع ${transfer.toWarehouseId}`,
      performedBy: userFullName,
    });

    currentStocks = updateWarehouseStock(
      currentStocks,
      item.itemId,
      transfer.toWarehouseId,
      item.quantity,
      item.unitCost
    );
    movements.push({
      id: `sm-tr-in-${ts}-${idx}-${item.itemId}`,
      itemId: item.itemId,
      warehouseId: transfer.toWarehouseId,
      documentType: 'تحويل_مخزني_استلام',
      documentNumber: transfer.transferNumber,
      documentId: transfer.id,
      movementDate: transfer.date,
      quantityChange: item.quantity,
      unitCost: item.unitCost,
      totalCost: item.quantity * item.unitCost,
      runningBalance: getItemStockInWarehouse(currentStocks, item.itemId, transfer.toWarehouseId),
      notes: `استلام تحويل وارد من مستودع ${transfer.fromWarehouseId}`,
      performedBy: userFullName,
    });
  });

  return {
    success: true,
    newStocks: currentStocks,
    movements,
  };
}

/**
 * Reverses a completed warehouse-to-warehouse transfer back into source warehouse.
 */
export function reverseInventoryTransfer(
  stocks: ItemWarehouseStock[],
  transfer: InventoryTransfer,
  userFullName: string
): { success: boolean; newStocks: ItemWarehouseStock[]; movements: StockMovement[]; error?: string } {
  if (transfer.status !== 'completed') {
    return {
      success: false,
      newStocks: stocks,
      movements: [],
      error: 'يمكن عكس التحويلات المكتملة فقط.',
    };
  }

  for (const item of transfer.items) {
    const destAvailable = getItemStockInWarehouse(stocks, item.itemId, transfer.toWarehouseId);
    if (destAvailable < item.quantity) {
      return {
        success: false,
        newStocks: stocks,
        movements: [],
        error: `لا يمكن عكس التحويل لأن الكمية المتوفرة حالياً في المستودع المستلم من "${item.itemName}" هي (${destAvailable}) وأقل من الكمية المحولة (${item.quantity}).`,
      };
    }
  }

  let currentStocks = [...stocks];
  const movements: StockMovement[] = [];
  const ts = Date.now();
  const revDate = new Date().toISOString().split('T')[0];

  transfer.items.forEach((item, idx) => {
    currentStocks = updateWarehouseStock(
      currentStocks,
      item.itemId,
      transfer.toWarehouseId,
      -item.quantity,
      item.unitCost
    );
    movements.push({
      id: `sm-tr-rev-out-${ts}-${idx}-${item.itemId}`,
      itemId: item.itemId,
      warehouseId: transfer.toWarehouseId,
      documentType: 'تحويل_مخزني_صرف',
      documentNumber: `${transfer.transferNumber}-REV`,
      documentId: transfer.id,
      movementDate: revDate,
      quantityChange: -item.quantity,
      unitCost: item.unitCost,
      totalCost: item.quantity * item.unitCost,
      runningBalance: getItemStockInWarehouse(currentStocks, item.itemId, transfer.toWarehouseId),
      notes: `عكس وإلغاء تحويل مخزني ${transfer.transferNumber}`,
      performedBy: userFullName,
    });

    currentStocks = updateWarehouseStock(
      currentStocks,
      item.itemId,
      transfer.fromWarehouseId,
      item.quantity,
      item.unitCost
    );
    movements.push({
      id: `sm-tr-rev-in-${ts}-${idx}-${item.itemId}`,
      itemId: item.itemId,
      warehouseId: transfer.fromWarehouseId,
      documentType: 'تحويل_مخزني_استلام',
      documentNumber: `${transfer.transferNumber}-REV`,
      documentId: transfer.id,
      movementDate: revDate,
      quantityChange: item.quantity,
      unitCost: item.unitCost,
      totalCost: item.quantity * item.unitCost,
      runningBalance: getItemStockInWarehouse(currentStocks, item.itemId, transfer.fromWarehouseId),
      notes: `استرجاع مخزون من عكس التحويل ${transfer.transferNumber}`,
      performedBy: userFullName,
    });
  });

  return {
    success: true,
    newStocks: currentStocks,
    movements,
  };
}

/**
 * Applies physical stocktaking adjustments across single or multi-warehouse scopes with exact running balances.
 */
export function applyStocktakingAdjustments(
  stocks: ItemWarehouseStock[],
  stocktake: PhysicalStocktaking,
  userFullName: string
): { success: boolean; newStocks: ItemWarehouseStock[]; movements: StockMovement[]; error?: string } {
  if (stocktake.status === 'approved') {
    return {
      success: false,
      newStocks: stocks,
      movements: [],
      error: 'تم اعتماد محضر الجرد مسبقاً ولا يمكن ترحيله مرة أخرى.',
    };
  }
  if (stocktake.status === 'cancelled') {
    return {
      success: false,
      newStocks: stocks,
      movements: [],
      error: 'محضر الجرد ملغى ولا يمكن اعتماده.',
    };
  }

  let currentStocks = [...stocks];
  const movements: StockMovement[] = [];
  const ts = Date.now();

  stocktake.items.forEach((item, idx) => {
    const targetWarehouseId = item.warehouseId || stocktake.warehouseId;
    if (!targetWarehouseId) return;

    const currentQty = getItemStockInWarehouse(currentStocks, item.itemId, targetWarehouseId);
    const delta = Number(item.physicalQuantity) - currentQty;
    if (delta === 0) return;

    currentStocks = updateWarehouseStock(
      currentStocks,
      item.itemId,
      targetWarehouseId,
      delta,
      item.unitCost
    );

    const newBalance = getItemStockInWarehouse(currentStocks, item.itemId, targetWarehouseId);
    movements.push({
      id: `sm-st-${ts}-${idx}-${item.itemId}-${targetWarehouseId}`,
      itemId: item.itemId,
      warehouseId: targetWarehouseId,
      documentType: delta > 0 ? 'تسوية_زيادة' : 'تسوية_عجز',
      documentNumber: stocktake.stocktakeNumber,
      documentId: stocktake.id,
      movementDate: stocktake.date,
      quantityChange: delta,
      unitCost: item.unitCost,
      totalCost: Math.abs(delta) * (item.unitCost || 0),
      runningBalance: newBalance,
      notes: `تسوية جرد فعلي (${item.warehouseName || targetWarehouseId}): الدفتري ${currentQty} -> الفعلي ${item.physicalQuantity}`,
      performedBy: userFullName,
    });
  });

  return {
    success: true,
    newStocks: currentStocks,
    movements,
  };
}
