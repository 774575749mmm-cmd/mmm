/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * ALMANSOOR SMART FINANCE ERP - Data Models & Types
 */

export type CurrencyCode = 'YER' | 'USD' | 'SAR' | (string & {});

export interface Currency {
  code: CurrencyCode;
  nameAr: string;
  symbol: string;
  exchangeRate: number; // Against base currency (YER)
  isBase: boolean;
  decimalPlaces: number;
}

export interface Company {
  id: string;
  nameAr: string;
  nameEn: string;
  commercialRecord: string;
  taxNumber: string;
  phone: string;
  email: string;
  address: string;
  logoUrl?: string;
  bannerBase64?: string;
  useFullBanner?: boolean;
  invoiceFooterNote?: string;
  baseCurrency: CurrencyCode;
}

export interface Branch {
  id: string;
  companyId: string;
  code: string;
  nameAr: string;
  phone: string;
  address: string;
  managerName: string;
  isMain: boolean;
  status: 'active' | 'inactive';
}

export interface Warehouse {
  id: string;
  branchId: string;
  code: string;
  nameAr: string;
  location: string;
  keeperName: string;
  status: 'active' | 'inactive';
}

// Regional Hierarchy: الدولة -> المحافظة -> المديرية -> المنطقة -> الحي
export interface RegionalArea {
  id: string;
  country: string;
  governorate: string; // المحافظة
  district: string;    // المديرية
  area: string;        // المنطقة
  neighborhood?: string; // الحي أو الشارع
  code: string;
}

export interface Customer {
  id: string;
  branchId: string;
  code: string;
  nameAr: string;
  commercialName?: string;
  phone: string;
  whatsapp?: string;
  email?: string;
  taxNumber?: string;
  commercialRecord?: string;
  // Regional linking
  regionalAreaId: string;
  addressDetails: string;
  category: 'تجاري' | 'جملة' | 'تجزئة' | 'VIP' | 'حكومي';
  creditLimit: number;
  paymentTermDays: number;
  salesRepId?: string;
  salesRepName?: string;
  openingBalance: number; // positive = debit (مدين لنا), negative = credit (دائن له)
  currentBalance: number;
  currency?: CurrencyCode;
  linkedAccountId?: string;
  linkedAccountCode?: string;
  status: 'active' | 'inactive' | 'blocked';
  notes?: string;
  createdAt: string;
}

export interface Vendor {
  id: string;
  branchId: string;
  code: string;
  nameAr: string;
  commercialName?: string;
  phone: string;
  whatsapp?: string;
  email?: string;
  taxNumber?: string;
  address: string;
  category: 'مورد رئيسي' | 'محلي' | 'خارجي' | 'خدمات';
  openingBalance: number; // positive = credit (دائن علينا), negative = debit
  currentBalance: number;
  currency?: CurrencyCode;
  linkedAccountId?: string;
  linkedAccountCode?: string;
  paymentTermDays: number;
  status: 'active' | 'inactive';
  notes?: string;
  createdAt: string;
}

export interface UnitOfMeasure {
  id: string;
  nameAr: string;
  symbolAr: string;
  isBase: boolean;
  factorToBase: number; // e.g. Box = 24 Pieces -> factor = 24
}

export interface InventoryItem {
  id: string;
  code: string;
  barcode: string;
  nameAr: string;
  nameEn?: string;
  category: string;
  baseUnit: string; // e.g. 'حبة'
  secondaryUnit?: string; // e.g. 'كرتون'
  unitConversionFactor?: number; // secondary to base, e.g. 12
  purchasePrice: number;
  salePrice: number;
  wholesalePrice: number;
  minSalePrice: number;
  minQuantityAlert: number;
  maxQuantity: number;
  valuationMethod: 'FIFO' | 'WEIGHTED_AVERAGE';
  taxRate: number; // e.g. 0.05 or 0.15 or 0
  status: 'active' | 'inactive';
  description?: string;
  createdAt: string;
}

export interface ItemWarehouseStock {
  itemId: string;
  warehouseId: string;
  quantityOnHand: number;
  averageCost: number;
}

export interface StockMovement {
  id: string;
  itemId: string;
  warehouseId: string;
  documentType: 'فاتورة_مبيعات' | 'فاتورة_مشتريات' | 'مرتجع_مبيعات' | 'مرتجع_مشتريات' | 'تحويل_مخزني_صرف' | 'تحويل_مخزني_استلام' | 'تسوية_زيادة' | 'تسوية_عجز' | 'رصيد_افتتاحي';
  documentNumber: string;
  documentId: string;
  movementDate: string;
  quantityChange: number; // positive or negative
  unitCost: number;
  totalCost: number;
  runningBalance: number;
  notes?: string;
  performedBy: string;
}

export type TransferStatus = 
  | 'draft' 
  | 'pending_approval' 
  | 'dispatched' 
  | 'in_transit' 
  | 'received' 
  | 'completed' 
  | 'cancelled';

export interface InventoryTransferItem {
  itemId: string;
  itemName: string;
  unit: string;
  quantity: number;
  unitCost: number;
}

export interface InventoryTransfer {
  id: string;
  transferNumber: string;
  date: string;
  fromWarehouseId: string;
  toWarehouseId: string;
  items: InventoryTransferItem[];
  status: TransferStatus;
  notes?: string;
  performedBy: string;
  dispatchedAt?: string;
  dispatchedBy?: string;
  receivedAt?: string;
  receivedBy?: string;
}

export interface StocktakingItem {
  itemId: string;
  itemName: string;
  barcode?: string;
  category?: string;
  unit: string;
  warehouseId?: string;
  warehouseName?: string;
  bookQuantity: number;
  physicalQuantity: number;
  difference: number; // physical - book
  unitCost: number;
  totalDifferenceValue: number;
  notes?: string;
}

export type StocktakingScope = 'single_item' | 'category' | 'warehouse' | 'multi_warehouse';
export type StocktakingStatus = 'draft' | 'counting' | 'review' | 'approved' | 'cancelled';

export interface PhysicalStocktaking {
  id: string;
  stocktakeNumber: string;
  warehouseId: string;
  warehouseIds?: string[];
  scope: StocktakingScope;
  targetCategory?: string;
  targetItemId?: string;
  date: string;
  items: StocktakingItem[];
  status: StocktakingStatus;
  notes?: string;
  conductedBy: string;
  approvedBy?: string;
  approvedAt?: string;
  adjustmentJournalEntryId?: string;
  createdAt?: string;
  updatedAt?: string;
}

// Warehouse Documents
export type WarehouseDocType =
  | 'إذن_توريد'
  | 'إذن_صرف'
  | 'إذن_استلام'
  | 'إذن_تحويل'
  | 'طلب_مناقلة'
  | 'إذن_مرتجع_مخزني'
  | 'إذن_تسوية_زيادة'
  | 'إذن_تسوية_عجز'
  | 'محضر_جرد'
  | 'محضر_تلف';

export interface WarehouseDocItem {
  id: string;
  itemId: string;
  itemName: string;
  unit: string;
  quantity: number;
  unitCost: number;
  totalCost: number;
  notes?: string;
}

export interface WarehouseDocument {
  id: string;
  documentNumber: string;
  type: WarehouseDocType;
  date: string;
  warehouseId: string;
  destWarehouseId?: string;
  beneficiaryOrSupplier: string;
  referenceNumber?: string;
  reason?: string;
  items: WarehouseDocItem[];
  totalQuantity: number;
  totalCost: number;
  status: 'draft' | 'posted' | 'cancelled';
  performedBy: string;
  approvedBy?: string;
  notes?: string;
  createdAt: string;
}

// Batch Voucher Row
export interface BatchVoucherRow {
  rowId: string;
  type: 'قبض' | 'صرف';
  entityType: 'عميل' | 'مورد' | 'موظف' | 'مصروف' | 'إيراد' | 'أخرى';
  entityId?: string;
  entityName: string;
  statement: string;
  treasuryAccountId: string;
  amount: number;
  currency: CurrencyCode;
  date: string;
  paymentMethod: 'نقداً' | 'شيك' | 'تحويل_بنكي' | 'دفع_إلكتروني';
  checkOrTransferRef?: string;
  linkedInvoiceIds?: string[];
  allocationNotes?: string;
}

// Scheduled Dispatch & Daily Management Models
export interface DispatchLogEntry {
  id: string;
  timestamp: string;
  recipientType: 'customer' | 'management' | 'vendor';
  recipientName: string;
  recipientPhone: string;
  channel: 'whatsapp' | 'email' | 'direct_download';
  reportType: 'daily_management' | 'customer_eod_statement' | 'invoice_immediate' | 'daily_sales';
  status: 'sent' | 'pending' | 'failed';
  details: string;
  errorMessage?: string;
  retryCount: number;
}

// Accounting
export type AccountCategory = 'أصول' | 'خصوم' | 'حقوق_ملكية' | 'إيرادات' | 'مصروفات';
export type AccountNature = 'debit' | 'credit';

export interface Account {
  id: string;
  code: string;
  nameAr: string;
  category: AccountCategory;
  nature: AccountNature;
  currency?: CurrencyCode;
  parentCode?: string;
  level: number;
  isLeaf: boolean; // Only leaf accounts can accept journal entries
  currentBalance: number;
  importedDebit?: number;
  importedCredit?: number;
  isSystemAccount?: boolean;
}

export interface CostCenter {
  id: string;
  code: string;
  nameAr: string;
  status: 'active' | 'inactive';
}

export interface JournalEntryLine {
  id: string;
  accountId: string;
  accountCode: string;
  accountName: string;
  debit: number;
  credit: number;
  currency: CurrencyCode;
  exchangeRate: number;
  costCenterId?: string;
  costCenterName?: string;
  memo: string;
}

export interface JournalEntry {
  id: string;
  entryNumber: string;
  date: string;
  branchId: string;
  referenceType: 'دليل_يدوي' | 'فاتورة_مبيعات' | 'فاتورة_مشتريات' | 'سند_قبض' | 'سند_صرف' | 'تحويل_نقدية' | 'رواتب' | 'إهلاك' | 'تسوية_مخزنية' | 'مرتجع';
  referenceNumber: string;
  referenceId?: string;
  description: string;
  lines: JournalEntryLine[];
  totalDebit: number;
  totalCredit: number;
  status: 'posted' | 'reversed';
  reversedEntryId?: string;
  createdBy: string;
  createdAt: string;
}

// Invoices (Sales & Purchases)
export interface InvoiceItem {
  id: string;
  itemId: string;
  itemName: string;
  itemBarcode: string;
  unit: string;
  quantity: number;
  bonusQuantity?: number;
  unitPrice: number;
  discountPercentage: number;
  discountAmount: number;
  subtotal: number;
  taxPercentage: number;
  taxAmount: number;
  total: number;
  unitCost: number; // for COGS calculation in sales
  notes?: string;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  type: 'مبيعات' | 'مشتريات' | 'مرتجع_مبيعات' | 'مرتجع_مشتريات';
  paymentType: 'نقدي' | 'آجل' | 'جزئي';
  date: string;
  dueDate?: string;
  branchId: string;
  warehouseId: string;
  entityId: string; // customerId or vendorId
  entityName: string;
  currency: CurrencyCode;
  exchangeRate: number;
  items: InvoiceItem[];
  subtotal: number;
  discountTotal: number;
  taxTotal: number;
  grandTotal: number;
  paidAmount: number;
  remainingAmount: number;
  previousBalanceSnapshot?: number;
  newBalanceSnapshot?: number;
  paymentMethod?: 'صندوق' | 'بنك' | 'محفظة' | 'متعدد';
  treasuryAccountId?: string;
  status: 'draft' | 'posted' | 'paid' | 'partial' | 'cancelled';
  bookId?: string;
  journalEntryId?: string;
  salesRepId?: string;
  salesRepName?: string;
  notes?: string;
  createdBy: string;
  createdAt: string;
}

// Treasury: Cash, Bank, Wallet
export type TreasuryType = 'صندوق' | 'بنك' | 'محفظة';

export interface TreasuryAccount {
  id: string;
  code: string;
  nameAr: string;
  type: TreasuryType;
  categoryGroup?: 'CASH_BOX' | 'EXCHANGE';
  currency: CurrencyCode;
  accountNumber?: string;
  branchId: string;
  generalLedgerAccountId: string; // linked to COA
  balance: number;
  status: 'active' | 'inactive';
}

export interface PaymentVoucher {
  id: string;
  voucherNumber: string;
  batchId?: string;
  bookId?: string;
  type: 'قبض' | 'صرف'; // Receipt (قبض) or Disbursement (صرف)
  date: string;
  branchId: string;
  treasuryAccountId: string;
  treasuryAccountName: string;
  entityType: 'عميل' | 'مورد' | 'موظف' | 'مصروف' | 'إيراد' | 'أخرى';
  entityId?: string;
  entityName: string;
  amount: number;
  currency: CurrencyCode;
  exchangeRate: number;
  baseAmount: number; // amount * exchangeRate
  linkedInvoiceId?: string;
  linkedInvoiceNumber?: string;
  costCenterId?: string;
  paymentMethod: 'نقداً' | 'شيك' | 'تحويل_بنكي' | 'دفع_إلكتروني';
  checkNumber?: string;
  transferReference?: string;
  statement: string; // البيان
  journalEntryId?: string;
  status: 'posted' | 'cancelled';
  receivedOrPaidBy: string;
  createdBy: string;
  createdAt: string;
}

export interface TreasuryTransfer {
  id: string;
  transferNumber: string;
  date: string;
  fromTreasuryId: string;
  toTreasuryId: string;
  amount: number;
  currency: CurrencyCode;
  feeAmount: number;
  notes?: string;
  journalEntryId?: string;
  createdBy: string;
}

// Expenses
export interface ExpenseCategory {
  id: string;
  nameAr: string;
  ledgerAccountId: string; // linked to 5x expenses in COA
}

export interface ExpenseRecord {
  id: string;
  expenseNumber: string;
  date: string;
  branchId: string;
  categoryId: string;
  categoryName: string;
  treasuryAccountId: string;
  treasuryAccountName: string;
  costCenterId?: string;
  costCenterName?: string;
  amount: number;
  currency: CurrencyCode;
  taxAmount: number;
  total: number;
  beneficiary: string;
  statement: string;
  journalEntryId?: string;
  createdBy: string;
}

// HR & Payroll
export interface Employee {
  id: string;
  code: string;
  nameAr: string;
  jobTitle: string;
  department: string;
  phone: string;
  nationalId: string;
  hireDate: string;
  basicSalary: number;
  housingAllowance: number;
  transportAllowance: number;
  otherAllowances: number;
  bankAccountNumber?: string;
  status: 'active' | 'on_leave' | 'terminated';
  currentLoanBalance: number;
}

export interface PayrollRunItem {
  employeeId: string;
  employeeName: string;
  basicSalary: number;
  totalAllowances: number;
  grossSalary: number;
  loanDeduction: number;
  taxOrSocialDeductions: number;
  otherDeductions: number;
  netSalary: number;
}

export interface PayrollRun {
  id: string;
  payrollNumber: string;
  month: string; // e.g. '2026-03'
  branchId: string;
  disbursementTreasuryId: string;
  items: PayrollRunItem[];
  totalGross: number;
  totalDeductions: number;
  totalNet: number;
  status: 'draft' | 'approved' | 'disbursed';
  disbursedDate?: string;
  journalEntryId?: string;
  createdBy: string;
}

// Fixed Assets
export interface FixedAsset {
  id: string;
  code: string;
  nameAr: string;
  category: 'مباني' | 'أجهزة_إلكترونية' | 'سيارات_ونقليات' | 'أثاث_ومفروشات' | 'معدات';
  purchaseDate: string;
  purchaseCost: number;
  salvageValue: number; // القيمة التخريدية
  usefulLifeMonths: number; // العمر الإنتاجي بالأشهر
  depreciationMethod: 'STRAIGHT_LINE';
  assetAccountId: string; // in COA (12x)
  accumulatedDepreciationAccountId: string; // in COA (123)
  depreciationExpenseAccountId: string; // in COA (55)
  currentBookValue: number;
  totalAccumulatedDepreciation: number;
  status: 'active' | 'disposed' | 'maintenance';
}

// Security, RBAC & Audit
export type UserRoleType = 
  | 'مالك المؤسسة' 
  | 'مدير النظام' 
  | 'المدير المالي' 
  | 'محاسب' 
  | 'أمين الصندوق' 
  | 'مسؤول المخزون' 
  | 'مسؤول المبيعات' 
  | 'مسؤول المشتريات'
  | 'مستخدم محدود';

export interface User {
  id: string;
  username: string;
  fullName: string;
  role: UserRoleType;
  branchId: string;
  email: string;
  active: boolean;
  canViewReports: boolean;
  canPostEntries: boolean;
  canAdjustInventory: boolean;
  canViewCostsAndProfits: boolean;
  canManageSettings: boolean;
  canEditInvoices?: boolean;
  canDeleteInvoices?: boolean;
  canEditVouchers?: boolean;
  canDeleteVouchers?: boolean;
  canEditExchangeRates?: boolean;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  action: 'إنشاء' | 'تعديل' | 'ترحيل' | 'إلغاء' | 'حذف' | 'تسجيل_دخول' | 'تصدير' | 'طباعة' | 'إعادة_ضبط';
  module: 'المبيعات' | 'المشتريات' | 'المخزون' | 'العملاء' | 'الموردين' | 'المحاسبة' | 'الخزينة' | 'المصروفات' | 'الرواتب' | 'الأصول' | 'الإعدادات';
  details: string;
  entityId?: string;
  ipAddress?: string;
}

export interface TaskAlert {
  id: string;
  title: string;
  type: 'مديونية_متأخرة' | 'مخزون_منخفض' | 'فاتورة_مستحقة' | 'مهمة_عمل' | 'إشعار_نظام';
  severity: 'low' | 'medium' | 'high' | 'critical';
  dueDate?: string;
  assignedTo?: string;
  isRead: boolean;
  isCompleted: boolean;
  linkModule?: string;
  linkId?: string;
  createdAt: string;
}

export interface WhatsAppTemplates {
  invoice: string;
  voucher: string;
  statement: string;
  overdueReminder: string;
  paymentConfirmation: string;
  dailySummary: string;
}

export interface TableColumnPref {
  key: string;
  label: string;
  visible: boolean;
  order: number;
  width?: number;
}

export interface TabVisibilityConfig {
  id: string;
  label: string;
  visible: boolean;
}

export interface UIPreferences {
  fontSize: number; // 11 - 22
  accentPreset: 'amber' | 'gold_classic' | 'bronze_gold';
  goldColor?: string;
  cardColor?: string;
  hiddenModules: string[];
  tabsConfig?: TabVisibilityConfig[];
  tableColumnPrefs: Record<string, TableColumnPref[]>;
}

export interface DocumentBook {
  id: string;
  code: string;
  nameAr: string;
  category: 'sales' | 'purchases' | 'warehouse' | 'vouchers' | 'ledgers';
  prefix: string;
  nextSequence: number;
  padLength: number;
  isActive: boolean;
  isDefault?: boolean;
  description?: string;
}

export interface DepartmentItem {
  id: string;
  nameAr: string;
}

export interface CustomLedgerRow {
  id: string;
  partyName: string;
  statement: string;
  debit: number;
  credit: number;
  currency: CurrencyCode;
  notes?: string;
}

export interface CustomLedgerEntry {
  id: string;
  bookId: string;
  entryNumber: string;
  date: string;
  treasuryAccountId?: string;
  treasuryAccountName?: string;
  direction?: 'IN' | 'OUT';
  rows: CustomLedgerRow[];
  totalDebit: number;
  totalCredit: number;
  notes?: string;
  createdBy: string;
  createdAt: string;
}

export interface CustomLedgerBook {
  id: string;
  code: string;
  nameAr: string;
  description?: string;
  createdAt: string;
}

export interface SystemSettings {
  allowNegativeStock: boolean;
  enforceBalancedJournalEntries: boolean;
  defaultTaxRate: number; // e.g. 0.05
  enableTax: boolean;
  autoPostInvoices: boolean;
  autoDownloadInvoices: boolean; // التنزيل التلقائي للفواتير بعد الإصدار
  scheduledDispatchHour: string; // وقت الإرسال المجدول اليومي (e.g. "18:00")
  enableWhatsAppAPI: boolean;
  whatsappApiEndpoint?: string;
  whatsappPhoneNumberId?: string;
  whatsappApiToken?: string;
  notificationPhone?: string;
  whatsappTemplates?: WhatsAppTemplates;
  stocktakeSurplusAccountCode?: string;
  stocktakeShortageAccountCode?: string;
  paymentMethods?: string[];
  invoicePrefix: string;
  purchasePrefix: string;
  paymentVoucherPrefix: string;
  receiptVoucherPrefix: string;
  journalPrefix: string;
  fiscalYear: string;
  fiscalYearStatus: 'open' | 'closed';
  companyPhone: string;
  companyAddress: string;
  companyTaxNumber: string;
  companyCommercialRecord: string;
  language?: 'ar' | 'en';
  uiPreferences?: UIPreferences;
}
